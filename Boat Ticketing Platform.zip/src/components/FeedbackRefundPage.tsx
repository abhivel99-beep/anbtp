import { useState } from 'react';
import { MessageSquare, RefreshCw, CheckCircle, X } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { api } from '../utils/api';

interface FeedbackRefundPageProps {
  onClose: () => void;
  type: 'feedback' | 'refund';
}

export function FeedbackRefundPage({ onClose, type }: FeedbackRefundPageProps) {
  const [formData, setFormData] = useState({
    // Common fields
    bookingId: '',
    email: '',
    phone: '',
    
    // Feedback fields
    rating: '',
    feedbackCategory: '',
    feedbackMessage: '',
    
    // Refund fields
    passengerName: '',
    travelDate: '',
    refundReason: '',
    refundDetails: '',
    accountNumber: '',
    ifscCode: '',
  });
  
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  const updateField = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmitFeedback = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!formData.bookingId || !formData.email || !formData.rating || !formData.feedbackMessage) {
      setError('Please fill all required fields');
      return;
    }
    
    setLoading(true);
    try {
      // In production, this would call the backend API
      console.log('Feedback submitted:', formData);
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setSuccess(true);
    } catch (err: any) {
      setError(err.message || 'Failed to submit feedback');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitRefund = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!formData.bookingId || !formData.email || !formData.passengerName || !formData.refundReason) {
      setError('Please fill all required fields');
      return;
    }
    
    setLoading(true);
    try {
      await api.requestRefund(formData.bookingId, formData.refundReason);
      setSuccess(true);
    } catch (err: any) {
      setError(err.message || 'Failed to submit refund request');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6 text-center">
            <div className="mx-auto mb-4 w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
              <CheckCircle className="h-10 w-10 text-green-600" />
            </div>
            <h3 className="mb-2">
              {type === 'feedback' ? 'Feedback Submitted!' : 'Refund Request Submitted!'}
            </h3>
            <p className="text-muted-foreground mb-6">
              {type === 'feedback' 
                ? 'Thank you for your valuable feedback. We appreciate your input and will use it to improve our services.'
                : 'Your refund request has been received and will be processed within 3-7 business days. You will receive updates via email and SMS.'}
            </p>
            <Button onClick={onClose} className="w-full">
              Close
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-y-auto">
      <Card className="w-full max-w-2xl my-8">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {type === 'feedback' ? (
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <MessageSquare className="h-6 w-6 text-green-600" />
                </div>
              ) : (
                <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                  <RefreshCw className="h-6 w-6 text-orange-600" />
                </div>
              )}
              <div>
                <CardTitle>
                  {type === 'feedback' ? 'Submit Feedback' : 'Apply for Refund'}
                </CardTitle>
                <CardDescription>
                  {type === 'feedback' 
                    ? 'Share your travel experience to help us improve'
                    : 'Request a refund within 24 hours of cancellation'}
                </CardDescription>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-5 w-5" />
            </Button>
          </div>
        </CardHeader>

        <CardContent>
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-4">
              {error}
            </div>
          )}

          {type === 'feedback' ? (
            <form onSubmit={handleSubmitFeedback} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="bookingId">Booking ID *</Label>
                  <Input
                    id="bookingId"
                    value={formData.bookingId}
                    onChange={(e) => updateField('bookingId', e.target.value)}
                    placeholder="e.g., BKG123456"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email Address *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => updateField('email', e.target.value)}
                    placeholder="your@email.com"
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  value={formData.phone}
                  onChange={(e) => updateField('phone', e.target.value)}
                  placeholder="+91 XXXXX XXXXX"
                />
              </div>

              <div>
                <Label htmlFor="rating">Overall Rating *</Label>
                <Select value={formData.rating} onValueChange={(value) => updateField('rating', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select rating" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="5">⭐⭐⭐⭐⭐ Excellent</SelectItem>
                    <SelectItem value="4">⭐⭐⭐⭐ Good</SelectItem>
                    <SelectItem value="3">⭐⭐⭐ Average</SelectItem>
                    <SelectItem value="2">⭐⭐ Poor</SelectItem>
                    <SelectItem value="1">⭐ Very Poor</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="feedbackCategory">Feedback Category</Label>
                <Select value={formData.feedbackCategory} onValueChange={(value) => updateField('feedbackCategory', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="service">Service Quality</SelectItem>
                    <SelectItem value="boat">Boat Condition</SelectItem>
                    <SelectItem value="staff">Staff Behavior</SelectItem>
                    <SelectItem value="punctuality">Punctuality</SelectItem>
                    <SelectItem value="cleanliness">Cleanliness</SelectItem>
                    <SelectItem value="booking">Booking Process</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="feedbackMessage">Your Feedback *</Label>
                <Textarea
                  id="feedbackMessage"
                  value={formData.feedbackMessage}
                  onChange={(e) => updateField('feedbackMessage', e.target.value)}
                  placeholder="Please share your experience with us..."
                  rows={5}
                  required
                />
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="text-sm text-blue-800">
                  <strong>Thank you for your feedback!</strong> Your input helps us improve our services and provide a better experience for all passengers.
                </p>
              </div>

              <div className="flex gap-4 justify-end">
                <Button type="button" variant="outline" onClick={onClose}>
                  Cancel
                </Button>
                <Button type="submit" disabled={loading}>
                  {loading ? 'Submitting...' : 'Submit Feedback'}
                </Button>
              </div>
            </form>
          ) : (
            <form onSubmit={handleSubmitRefund} className="space-y-4">
              <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg mb-4">
                <p className="text-sm text-yellow-800">
                  <strong>Refund Policy:</strong> Refund requests must be submitted within 24 hours of cancellation. 
                  The refund amount will be calculated based on the cancellation time and applicable charges.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="bookingId">Booking ID *</Label>
                  <Input
                    id="bookingId"
                    value={formData.bookingId}
                    onChange={(e) => updateField('bookingId', e.target.value)}
                    placeholder="e.g., BKG123456"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="passengerName">Passenger Name *</Label>
                  <Input
                    id="passengerName"
                    value={formData.passengerName}
                    onChange={(e) => updateField('passengerName', e.target.value)}
                    placeholder="Full name as per booking"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="email">Email Address *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => updateField('email', e.target.value)}
                    placeholder="your@email.com"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Phone Number *</Label>
                  <Input
                    id="phone"
                    value={formData.phone}
                    onChange={(e) => updateField('phone', e.target.value)}
                    placeholder="+91 XXXXX XXXXX"
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="travelDate">Travel Date *</Label>
                <Input
                  id="travelDate"
                  type="date"
                  value={formData.travelDate}
                  onChange={(e) => updateField('travelDate', e.target.value)}
                  required
                />
              </div>

              <div>
                <Label htmlFor="refundReason">Reason for Refund *</Label>
                <Select value={formData.refundReason} onValueChange={(value) => updateField('refundReason', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select reason" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="trip_cancelled">Trip Cancelled</SelectItem>
                    <SelectItem value="personal_emergency">Personal Emergency</SelectItem>
                    <SelectItem value="weather_conditions">Weather Conditions</SelectItem>
                    <SelectItem value="health_issues">Health Issues</SelectItem>
                    <SelectItem value="change_of_plans">Change of Plans</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="refundDetails">Additional Details</Label>
                <Textarea
                  id="refundDetails"
                  value={formData.refundDetails}
                  onChange={(e) => updateField('refundDetails', e.target.value)}
                  placeholder="Please provide additional details about your refund request..."
                  rows={4}
                />
              </div>

              <div className="border-t pt-4">
                <h4 className="mb-4">Bank Account Details (For Refund Transfer)</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="accountNumber">Account Number</Label>
                    <Input
                      id="accountNumber"
                      value={formData.accountNumber}
                      onChange={(e) => updateField('accountNumber', e.target.value)}
                      placeholder="Bank account number"
                    />
                  </div>
                  <div>
                    <Label htmlFor="ifscCode">IFSC Code</Label>
                    <Input
                      id="ifscCode"
                      value={formData.ifscCode}
                      onChange={(e) => updateField('ifscCode', e.target.value)}
                      placeholder="e.g., SBIN0001234"
                    />
                  </div>
                </div>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="text-sm text-blue-800">
                  <strong>Processing Time:</strong> Refund requests are typically processed within 3-7 business days. 
                  You will receive email and SMS notifications about the status of your request.
                </p>
              </div>

              <div className="flex gap-4 justify-end">
                <Button type="button" variant="outline" onClick={onClose}>
                  Cancel
                </Button>
                <Button type="submit" disabled={loading}>
                  {loading ? 'Submitting...' : 'Submit Refund Request'}
                </Button>
              </div>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
