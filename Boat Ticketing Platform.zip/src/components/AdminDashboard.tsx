import { useState, useEffect } from 'react';
import { BarChart3, Users, Ship, Calendar, DollarSign, RefreshCw, Plus, AlertTriangle, CheckCircle, Download, User, Send } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Checkbox } from './ui/checkbox';
import { api } from '../utils/api';
import { ApprovalPanel } from './ApprovalPanel';

export function AdminDashboard() {
  const [stats, setStats] = useState<any>(null);
  const [dailyStats, setDailyStats] = useState<any>(null);
  const [monthlyStats, setMonthlyStats] = useState<any>(null);
  const [boats, setBoats] = useState<any[]>([]);
  const [schedules, setSchedules] = useState<any[]>([]);
  const [bookings, setBookings] = useState<any[]>([]);
  const [refunds, setRefunds] = useState<any[]>([]);
  const [emergencies, setEmergencies] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState<any>(null);
  const [isEditingProfile, setIsEditingProfile] = useState(false);

  // Schedule form state
  const [showScheduleForm, setShowScheduleForm] = useState(false);
  const [scheduleDate, setScheduleDate] = useState('');
  const [viewScheduleDate, setViewScheduleDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedBoats, setSelectedBoats] = useState<string[]>([]);
  const [emergencyBoat, setEmergencyBoat] = useState('');
  const [scheduleRoute, setScheduleRoute] = useState('');
  const [savedSchedules, setSavedSchedules] = useState<any[]>([]);

  // SOS form state
  const [showSOSForm, setShowSOSForm] = useState(false);
  const [sosData, setSOSData] = useState({
    boatId: '',
    description: '',
    location: '',
    severity: 'high',
  });

  // Profile data
  const [profileData, setProfileData] = useState({
    name: 'Admin User',
    email: 'admin@andamanboats.com',
    phone: '+91 98765 43210',
    role: 'System Administrator',
  });

  useEffect(() => {
    loadData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [statsData, boatsData, schedulesData, bookingsData, refundsData] = await Promise.all([
        api.getDashboardStats(),
        api.getBoats(),
        api.getSchedules(),
        api.searchBookings({}),
        api.getRefunds(),
      ]);

      setStats(statsData);
      
      // Calculate daily stats (current day)
      const today = new Date().toISOString().split('T')[0];
      const todayBookings = bookingsData.bookings.filter((b: any) => b.date === today);
      const dailyEarnings = todayBookings.reduce((sum: number, b: any) => sum + (b.totalAmount || 0), 0);
      const dailyPassengers = todayBookings.reduce((sum: number, b: any) => sum + (b.totalPassengers || 0), 0);
      
      setDailyStats({
        earnings: dailyEarnings,
        passengers: dailyPassengers,
        bookings: todayBookings.length,
      });

      // Calculate monthly stats (current month)
      const currentMonth = new Date().toISOString().slice(0, 7);
      const monthBookings = bookingsData.bookings.filter((b: any) => b.date?.startsWith(currentMonth));
      const monthlyEarnings = monthBookings.reduce((sum: number, b: any) => sum + (b.totalAmount || 0), 0);
      const monthlyPassengers = monthBookings.reduce((sum: number, b: any) => sum + (b.totalPassengers || 0), 0);
      
      setMonthlyStats({
        earnings: monthlyEarnings,
        passengers: monthlyPassengers,
        bookings: monthBookings.length,
      });

      // Filter only active/approved boats
      setBoats(boatsData.boats.filter((b: any) => b.status === 'active' || b.status === 'approved'));
      setSchedules(schedulesData.schedules);
      setBookings(bookingsData.bookings);
      setRefunds(refundsData.refunds);

      // Load profile
      setProfile(profileData);
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateDailySchedule = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!scheduleDate || selectedBoats.length === 0 || !emergencyBoat || !scheduleRoute) {
      alert('Please fill all required fields');
      return;
    }

    if (selectedBoats.includes(emergencyBoat)) {
      alert('Emergency boat cannot be a scheduled boat');
      return;
    }

    try {
      // Create schedules for each selected boat in sequence
      for (let i = 0; i < selectedBoats.length; i++) {
        const boatId = selectedBoats[i];
        // Each boat gets a sequential time slot (e.g., 9:00, 11:00, 13:00, 15:00)
        const baseHour = 9;
        const timeSlot = baseHour + (i * 2);
        const departureTime = `${timeSlot.toString().padStart(2, '0')}:00`;
        const returnHour = timeSlot + 1;
        const returnTime = `${returnHour.toString().padStart(2, '0')}:30`;
        
        await api.createSchedule({
          boatId,
          date: scheduleDate,
          route: scheduleRoute,
          departureTime,
          returnTime
        });
      }

      alert('Daily schedule created successfully!');
      setShowScheduleForm(false);
      setScheduleDate('');
      setSelectedBoats([]);
      setEmergencyBoat('');
      setScheduleRoute('');
      loadData();
    } catch (error) {
      console.error('Failed to create schedule:', error);
      alert('Failed to create schedule');
    }
  };

  const handleToggleBoatSelection = (boatId: string) => {
    setSelectedBoats(prev => 
      prev.includes(boatId) 
        ? prev.filter(id => id !== boatId)
        : [...prev, boatId]
    );
  };

  const handleSendSOSRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      // Find the boat and its assigned rescue boat
      const boat = boats.find(b => b.id === sosData.boatId);
      
      if (!boat) {
        alert('Boat not found');
        return;
      }

      // Send SOS notification (in production, this would trigger actual notifications)
      alert(`SOS request sent!\n\nBoat: ${boat.name}\nSeverity: ${sosData.severity.toUpperCase()}\nLocation: ${sosData.location}\n\nRescue team and emergency boat have been notified.`);
      
      setShowSOSForm(false);
      setSOSData({
        boatId: '',
        description: '',
        location: '',
        severity: 'high',
      });
    } catch (error) {
      console.error('Failed to send SOS:', error);
      alert('Failed to send SOS request');
    }
  };

  const handleProcessRefund = async (refundId: string, status: string) => {
    try {
      await api.processRefund(refundId, status);
      loadData();
    } catch (error) {
      console.error('Failed to process refund:', error);
      alert('Failed to process refund');
    }
  };

  const handleGenerateSchedulePDF = () => {
    // In production, this would generate an actual PDF
    window.print();
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setProfile(profileData);
      setIsEditingProfile(false);
      alert('Profile updated successfully!');
    } catch (error) {
      console.error('Failed to update profile:', error);
      alert('Failed to update profile');
    }
  };

  const activeBoats = boats.filter(b => b.status === 'active' || b.status === 'approved');

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-4" />
          <p>Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1>Admin Dashboard</h1>
          <p className="text-muted-foreground">Complete system oversight and management</p>
        </div>

        {/* Daily & Monthly Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <Card className="border-blue-200 bg-blue-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-blue-600" />
                Today's Analytics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Earnings</p>
                  <p className="text-2xl text-blue-600">₹{(dailyStats?.earnings || 0).toFixed(2)}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Passengers</p>
                  <p className="text-2xl text-blue-600">{dailyStats?.passengers || 0}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Bookings</p>
                  <p className="text-2xl text-blue-600">{dailyStats?.bookings || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-green-200 bg-green-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-green-600" />
                This Month's Analytics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Earnings</p>
                  <p className="text-2xl text-green-600">₹{(monthlyStats?.earnings || 0).toFixed(2)}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Passengers</p>
                  <p className="text-2xl text-green-600">{monthlyStats?.passengers || 0}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Bookings</p>
                  <p className="text-2xl text-green-600">{monthlyStats?.bookings || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Fleet Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Ship className="h-5 w-5 text-green-600" />
                Active Boats
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl text-green-600">{activeBoats.length}</div>
              <p className="text-sm text-muted-foreground mt-2">Currently operational</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-blue-600" />
                Scheduled Trips
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl text-blue-600">{schedules.length}</div>
              <p className="text-sm text-muted-foreground mt-2">Total schedules</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="schedules" className="space-y-4">
          <TabsList>
            <TabsTrigger value="schedules">Trip Scheduling</TabsTrigger>
            <TabsTrigger value="boats">Boat Fleet</TabsTrigger>
            <TabsTrigger value="approvals">Approvals</TabsTrigger>
            <TabsTrigger value="payments">Payment Dispatch</TabsTrigger>
            <TabsTrigger value="sos">SOS & Emergency</TabsTrigger>
            <TabsTrigger value="bookings">All Bookings</TabsTrigger>
            <TabsTrigger value="refunds">Refunds</TabsTrigger>
            <TabsTrigger value="profile">Profile</TabsTrigger>
          </TabsList>

          {/* Trip Scheduling Tab */}
          <TabsContent value="schedules" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3>Date-wise Trip Scheduling</h3>
              <Button onClick={() => setShowScheduleForm(!showScheduleForm)}>
                <Plus className="h-4 w-4 mr-2" />
                Create Daily Schedule
              </Button>
            </div>

            {showScheduleForm && (
              <Card>
                <CardHeader>
                  <CardTitle>Create Daily Schedule</CardTitle>
                  <CardDescription>
                    Select date, boats, emergency boat, and route to create the day's schedule
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleCreateDailySchedule} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label>Date *</Label>
                        <Input
                          type="date"
                          value={scheduleDate}
                          onChange={(e) => setScheduleDate(e.target.value)}
                          min={new Date().toISOString().split('T')[0]}
                          required
                        />
                      </div>
                      <div>
                        <Label>Route *</Label>
                        <Select value={scheduleRoute} onValueChange={setScheduleRoute}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select route" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="ross">Ross Island</SelectItem>
                            <SelectItem value="northbay">North Bay</SelectItem>
                            <SelectItem value="combined">Ross Island & North Bay</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <Label className="mb-3 block">Select Boats for Schedule (in sequence) *</Label>
                      <div className="overflow-x-auto">
                        <table className="w-full border-collapse">
                          <thead>
                            <tr className="bg-gray-50 border-b">
                              <th className="px-4 py-3 text-left text-xs">Select</th>
                              <th className="px-4 py-3 text-left text-xs">Sequence</th>
                              <th className="px-4 py-3 text-left text-xs">Boat Name</th>
                              <th className="px-4 py-3 text-left text-xs">Registration</th>
                              <th className="px-4 py-3 text-left text-xs">Capacity</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y">
                            {activeBoats.filter(b => b.id !== emergencyBoat).map((boat) => {
                              const sequenceNumber = selectedBoats.indexOf(boat.id) + 1;
                              const isSelected = selectedBoats.includes(boat.id);
                              return (
                                <tr 
                                  key={boat.id}
                                  className={`cursor-pointer hover:bg-gray-50 ${isSelected ? 'bg-blue-50' : ''}`}
                                  onClick={() => handleToggleBoatSelection(boat.id)}
                                >
                                  <td className="px-4 py-3">
                                    <Checkbox checked={isSelected} />
                                  </td>
                                  <td className="px-4 py-3">
                                    {isSelected ? (
                                      <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-blue-600 text-white text-sm">
                                        {sequenceNumber}
                                      </span>
                                    ) : (
                                      <span className="text-muted-foreground text-sm">-</span>
                                    )}
                                  </td>
                                  <td className="px-4 py-3 text-sm">{boat.name}</td>
                                  <td className="px-4 py-3 text-sm text-muted-foreground">{boat.registrationNumber}</td>
                                  <td className="px-4 py-3 text-sm">{boat.capacity} pax</td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                      {selectedBoats.length > 0 && (
                        <p className="text-sm text-muted-foreground mt-2">
                          ✓ Selected {selectedBoats.length} boat(s) in sequence
                        </p>
                      )}
                    </div>

                    <div>
                      <Label>Emergency/Rescue Boat *</Label>
                      <Select value={emergencyBoat} onValueChange={setEmergencyBoat}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select emergency boat" />
                        </SelectTrigger>
                        <SelectContent>
                          {activeBoats.filter(b => !selectedBoats.includes(b.id)).map(boat => (
                            <SelectItem key={boat.id} value={boat.id}>
                              {boat.name} ({boat.capacity} pax)
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <p className="text-xs text-muted-foreground mt-1">
                        Emergency boat will be on standby for the entire day
                      </p>
                    </div>

                    <div className="bg-blue-50 p-4 rounded-lg">
                      <p className="text-sm text-blue-800">
                        <strong>Note:</strong> Boats will be scheduled in sequence throughout the day. 
                        Emergency boat cannot be used for regular schedules.
                      </p>
                    </div>

                    <div className="flex gap-2">
                      <Button type="submit">Create Schedule</Button>
                      <Button type="button" variant="outline" onClick={() => setShowScheduleForm(false)}>
                        Cancel
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>View Scheduled Trips</CardTitle>
                  <div className="flex gap-2">
                    <Input
                      type="date"
                      value={viewScheduleDate}
                      onChange={(e) => setViewScheduleDate(e.target.value)}
                      className="w-48"
                    />
                    <Button variant="outline" size="sm" onClick={handleGenerateSchedulePDF}>
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                  </div>
                </div>
                <CardDescription>
                  View and download boat schedule for selected date
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs">Sequence</th>
                        <th className="px-4 py-3 text-left text-xs">Boat Name</th>
                        <th className="px-4 py-3 text-left text-xs">Registration</th>
                        <th className="px-4 py-3 text-left text-xs">Capacity</th>
                        <th className="px-4 py-3 text-left text-xs">Route</th>
                        <th className="px-4 py-3 text-left text-xs">Departure</th>
                        <th className="px-4 py-3 text-left text-xs">Return</th>
                        <th className="px-4 py-3 text-left text-xs">Booked</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {(() => {
                        const dateSchedules = schedules.filter(s => s.date === viewScheduleDate);
                        if (dateSchedules.length === 0) {
                          return (
                            <tr>
                              <td colSpan={8} className="px-4 py-8 text-center text-muted-foreground">
                                No schedule found for {viewScheduleDate}
                              </td>
                            </tr>
                          );
                        }
                        return dateSchedules.map((schedule, index) => {
                          const boat = boats.find(b => b.id === schedule.boatId);
                          return (
                            <tr key={schedule.id}>
                              <td className="px-4 py-3">
                                <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-blue-600 text-white text-sm">
                                  {index + 1}
                                </span>
                              </td>
                              <td className="px-4 py-3 text-sm">{boat?.name || '-'}</td>
                              <td className="px-4 py-3 text-sm text-muted-foreground">{boat?.registrationNumber || '-'}</td>
                              <td className="px-4 py-3 text-sm">{boat?.capacity || 0} pax</td>
                              <td className="px-4 py-3 text-sm capitalize">{schedule.route}</td>
                              <td className="px-4 py-3 text-sm">{schedule.departureTime}</td>
                              <td className="px-4 py-3 text-sm">{schedule.returnTime}</td>
                              <td className="px-4 py-3 text-sm">
                                <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-full text-xs">
                                  {schedule.bookedSeats || 0} / {boat?.capacity || 0}
                                </span>
                              </td>
                            </tr>
                          );
                        });
                      })()}
                    </tbody>
                  </table>
                </div>
                
                {schedules.filter(s => s.date === viewScheduleDate).length > 0 && (
                  <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                    <p className="text-sm text-green-800">
                      <strong>✓ Schedule Finalized</strong> - This schedule is visible to operators and boarding teams
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Boat Fleet Tab */}
          <TabsContent value="boats" className="space-y-4">
            <h3>Registered Boat Fleet</h3>
            <p className="text-sm text-muted-foreground">
              Boats registered by operators (approved boats only)
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {activeBoats.length === 0 ? (
                <Card className="col-span-full">
                  <CardContent className="p-8 text-center text-muted-foreground">
                    <Ship className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                    <p>No approved boats yet</p>
                    <p className="text-sm mt-2">Boats will appear here after operator registration and approval</p>
                  </CardContent>
                </Card>
              ) : (
                activeBoats.map((boat) => (
                  <Card key={boat.id}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="flex items-center gap-2">
                          <Ship className="h-5 w-5" />
                          {boat.name}
                        </CardTitle>
                        <span className="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs">
                          Active
                        </span>
                      </div>
                      <CardDescription>Reg: {boat.registrationNumber}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Capacity:</span>
                          <span>{boat.capacity} passengers</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Type:</span>
                          <span className="capitalize">{boat.type || 'Ferry'}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          {/* Approvals Tab */}
          <TabsContent value="approvals" className="space-y-4">
            <ApprovalPanel onApprovalComplete={loadData} />
          </TabsContent>

          {/* Payment Approval & Dispatch Tab */}
          <TabsContent value="payments" className="space-y-4">
            <h3>Payment Approval & Dispatch</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Approve and dispatch payments to agents and boat operators
            </p>

            <Card>
              <CardHeader>
                <CardTitle>Pending Payment Approvals</CardTitle>
                <CardDescription>Review and approve payments for commission and services</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Agent Commission Payments */}
                  <div>
                    <h4 className="mb-3">Agent Commission Payments</h4>
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-4 py-3 text-left text-xs">Agent</th>
                            <th className="px-4 py-3 text-left text-xs">Bookings</th>
                            <th className="px-4 py-3 text-left text-xs">Commission</th>
                            <th className="px-4 py-3 text-left text-xs">Status</th>
                            <th className="px-4 py-3 text-left text-xs">Action</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y">
                          {bookings
                            .filter(b => b.bookedBy && b.paymentStatus === 'paid' && !b.commissionPaid)
                            .reduce((acc: any[], booking) => {
                              const agentId = booking.bookedBy;
                              const existing = acc.find(a => a.agentId === agentId);
                              const commission = booking.agentCommission || 0;
                              
                              if (existing) {
                                existing.bookings += 1;
                                existing.commission += commission;
                                existing.bookingIds.push(booking.id);
                              } else {
                                acc.push({
                                  agentId,
                                  agentName: booking.agentName || `Agent ${agentId}`,
                                  bookings: 1,
                                  commission: commission,
                                  bookingIds: [booking.id],
                                });
                              }
                              return acc;
                            }, [])
                            .map((agent: any) => (
                              <tr key={agent.agentId}>
                                <td className="px-4 py-3 text-sm">{agent.agentName}</td>
                                <td className="px-4 py-3 text-sm">{agent.bookings}</td>
                                <td className="px-4 py-3 text-sm">₹{agent.commission.toFixed(2)}</td>
                                <td className="px-4 py-3 text-sm">
                                  <span className="px-2 py-1 bg-yellow-100 text-yellow-700 rounded-full text-xs">
                                    Pending
                                  </span>
                                </td>
                                <td className="px-4 py-3 text-sm">
                                  <Button 
                                    size="sm" 
                                    onClick={async () => {
                                      try {
                                        await api.approveAgentCommission(agent.bookingIds);
                                        alert(`Commission of ₹${agent.commission.toFixed(2)} approved for ${agent.agentName}`);
                                        loadData();
                                      } catch (error) {
                                        console.error('Failed to approve commission:', error);
                                        alert('Failed to approve commission');
                                      }
                                    }}
                                  >
                                    <CheckCircle className="h-4 w-4 mr-1" />
                                    Approve & Dispatch
                                  </Button>
                                </td>
                              </tr>
                            ))}
                        </tbody>
                      </table>
                      {bookings.filter(b => b.bookedBy && b.paymentStatus === 'paid' && !b.commissionPaid).length === 0 && (
                        <p className="text-center text-muted-foreground py-8">No pending agent commission payments</p>
                      )}
                    </div>
                  </div>

                  {/* Boat Operator Payments */}
                  <div className="mt-8">
                    <h4 className="mb-3">Boat Operator Payments</h4>
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-4 py-3 text-left text-xs">Boat</th>
                            <th className="px-4 py-3 text-left text-xs">Operator</th>
                            <th className="px-4 py-3 text-left text-xs">Trips</th>
                            <th className="px-4 py-3 text-left text-xs">Amount</th>
                            <th className="px-4 py-3 text-left text-xs">Status</th>
                            <th className="px-4 py-3 text-left text-xs">Action</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y">
                          {boats
                            .filter(boat => {
                              const boatBookings = bookings.filter(
                                b => b.assignedBoat === boat.id && b.paymentStatus === 'paid' && !b.operatorPaid
                              );
                              return boatBookings.length > 0;
                            })
                            .map((boat) => {
                              const boatBookings = bookings.filter(
                                b => b.assignedBoat === boat.id && b.paymentStatus === 'paid' && !b.operatorPaid
                              );
                              const totalAmount = boatBookings.reduce((sum, b) => sum + (b.totalAmount || 0) * 0.7, 0); // 70% to operator
                              
                              return (
                                <tr key={boat.id}>
                                  <td className="px-4 py-3 text-sm">{boat.name}</td>
                                  <td className="px-4 py-3 text-sm">{boat.ownerName || '-'}</td>
                                  <td className="px-4 py-3 text-sm">{boatBookings.length}</td>
                                  <td className="px-4 py-3 text-sm">₹{totalAmount.toFixed(2)}</td>
                                  <td className="px-4 py-3 text-sm">
                                    <span className="px-2 py-1 bg-yellow-100 text-yellow-700 rounded-full text-xs">
                                      Pending
                                    </span>
                                  </td>
                                  <td className="px-4 py-3 text-sm">
                                    <Button 
                                      size="sm" 
                                      onClick={async () => {
                                        try {
                                          const bookingIds = boatBookings.map(b => b.id);
                                          await api.approveOperatorPayment(bookingIds, boat.id);
                                          alert(`Payment of ₹${totalAmount.toFixed(2)} approved for ${boat.name}`);
                                          loadData();
                                        } catch (error) {
                                          console.error('Failed to approve payment:', error);
                                          alert('Failed to approve payment');
                                        }
                                      }}
                                    >
                                      <CheckCircle className="h-4 w-4 mr-1" />
                                      Approve & Dispatch
                                    </Button>
                                  </td>
                                </tr>
                              );
                            })}
                        </tbody>
                      </table>
                      {boats.filter(boat => {
                        const boatBookings = bookings.filter(
                          b => b.assignedBoat === boat.id && b.paymentStatus === 'paid' && !b.operatorPaid
                        );
                        return boatBookings.length > 0;
                      }).length === 0 && (
                        <p className="text-center text-muted-foreground py-8">No pending operator payments</p>
                      )}
                    </div>
                  </div>

                  {/* Payment History */}
                  <div className="mt-8">
                    <h4 className="mb-3">Payment History (Last 30 Days)</h4>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <p className="text-sm text-muted-foreground">Total Agent Commission Paid</p>
                          <p className="text-2xl text-green-600">
                            ₹{bookings
                              .filter(b => b.commissionPaid)
                              .reduce((sum, b) => sum + (b.agentCommission || 0), 0)
                              .toFixed(2)}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Total Operator Payments</p>
                          <p className="text-2xl text-green-600">
                            ₹{bookings
                              .filter(b => b.operatorPaid)
                              .reduce((sum, b) => sum + (b.totalAmount || 0) * 0.7, 0)
                              .toFixed(2)}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Platform Revenue</p>
                          <p className="text-2xl text-blue-600">
                            ₹{bookings
                              .filter(b => b.paymentStatus === 'paid')
                              .reduce((sum, b) => sum + (b.totalAmount || 0) * 0.3 - (b.agentCommission || 0), 0)
                              .toFixed(2)}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* SOS & Emergency Tab */}
          <TabsContent value="sos" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3>SOS & Emergency Management</h3>
              <Button variant="destructive" onClick={() => setShowSOSForm(!showSOSForm)}>
                <AlertTriangle className="h-4 w-4 mr-2" />
                Send Emergency Request
              </Button>
            </div>

            {showSOSForm && (
              <Card className="border-red-200">
                <CardHeader>
                  <CardTitle className="text-red-600">Emergency SOS Request</CardTitle>
                  <CardDescription>
                    Send emergency notification to response team and rescue boat
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSendSOSRequest} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label>Boat in Distress *</Label>
                        <Select value={sosData.boatId} onValueChange={(value) => setSOSData({...sosData, boatId: value})}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select boat" />
                          </SelectTrigger>
                          <SelectContent>
                            {boats.map(boat => (
                              <SelectItem key={boat.id} value={boat.id}>
                                {boat.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label>Severity Level *</Label>
                        <Select value={sosData.severity} onValueChange={(value) => setSOSData({...sosData, severity: value})}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="critical">Critical</SelectItem>
                            <SelectItem value="high">High</SelectItem>
                            <SelectItem value="medium">Medium</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <Label>Location *</Label>
                      <Input
                        value={sosData.location}
                        onChange={(e) => setSOSData({...sosData, location: e.target.value})}
                        placeholder="e.g., Coordinates or landmark"
                        required
                      />
                    </div>

                    <div>
                      <Label>Description *</Label>
                      <Textarea
                        value={sosData.description}
                        onChange={(e) => setSOSData({...sosData, description: e.target.value})}
                        placeholder="Describe the emergency situation..."
                        rows={3}
                        required
                      />
                    </div>

                    <div className="flex gap-2">
                      <Button type="submit" variant="destructive">
                        <Send className="h-4 w-4 mr-2" />
                        Send SOS Request
                      </Button>
                      <Button type="button" variant="outline" onClick={() => setShowSOSForm(false)}>
                        Cancel
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-red-600" />
                  Active Emergency Requests
                </CardTitle>
              </CardHeader>
              <CardContent>
                {emergencies.length === 0 ? (
                  <div className="text-center py-12">
                    <CheckCircle className="h-16 w-16 text-green-600 mx-auto mb-4" />
                    <h4>No Active Emergencies</h4>
                    <p className="text-muted-foreground">All systems operational</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {emergencies.map((emergency) => (
                      <div key={emergency.id} className="border-l-4 border-red-500 bg-red-50 p-4 rounded">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="text-red-800">{emergency.title}</h4>
                            <p className="text-sm text-red-600">{emergency.description}</p>
                            <p className="text-xs text-muted-foreground mt-2">{emergency.timestamp}</p>
                          </div>
                          <Button size="sm" variant="destructive">
                            Respond
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* All Bookings Tab */}
          <TabsContent value="bookings" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>All Bookings</CardTitle>
                <CardDescription>
                  Complete passenger details for all bookings
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {bookings.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      No bookings yet
                    </div>
                  ) : (
                    bookings.slice(0, 10).map((booking) => (
                      <div key={booking.id} className="border rounded-lg p-4">
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <h4>Booking #{booking.id}</h4>
                            <p className="text-sm text-muted-foreground">
                              {booking.date} • {booking.route}
                            </p>
                          </div>
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            booking.status === 'confirmed' ? 'bg-green-100 text-green-700' :
                            booking.status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                            'bg-gray-100 text-gray-700'
                          }`}>
                            {booking.status}
                          </span>
                        </div>

                        <div className="border-t pt-4">
                          <h4 className="text-sm mb-3">Passenger Details</h4>
                          {booking.passengers && booking.passengers.length > 0 ? (
                            <div className="overflow-x-auto">
                              <table className="w-full text-sm">
                                <thead className="bg-gray-50">
                                  <tr>
                                    <th className="px-3 py-2 text-left">Name</th>
                                    <th className="px-3 py-2 text-left">Age</th>
                                    <th className="px-3 py-2 text-left">Gender</th>
                                    <th className="px-3 py-2 text-left">Phone</th>
                                    <th className="px-3 py-2 text-left">Email</th>
                                    <th className="px-3 py-2 text-left">ID Type</th>
                                    <th className="px-3 py-2 text-left">ID Number</th>
                                    <th className="px-3 py-2 text-left">Address</th>
                                  </tr>
                                </thead>
                                <tbody className="divide-y">
                                  {booking.passengers.map((passenger: any, idx: number) => (
                                    <tr key={idx}>
                                      <td className="px-3 py-2">
                                        {passenger.name}
                                        {passenger.isInfant && <span className="ml-2 text-xs text-green-600">(Infant)</span>}
                                      </td>
                                      <td className="px-3 py-2">{passenger.age}</td>
                                      <td className="px-3 py-2">{passenger.isInfant ? 'Infant' : (passenger.gender || '-')}</td>
                                      <td className="px-3 py-2">{passenger.phone || booking.contactPhone}</td>
                                      <td className="px-3 py-2">{passenger.email || booking.contactEmail || '-'}</td>
                                      <td className="px-3 py-2">{passenger.isInfant ? '-' : (passenger.idType || '-')}</td>
                                      <td className="px-3 py-2">{passenger.isInfant ? '-' : (passenger.idNumber || '-')}</td>
                                      <td className="px-3 py-2">{passenger.address || '-'}</td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          ) : (
                            <p className="text-sm text-muted-foreground">No passenger details available</p>
                          )}
                        </div>

                        <div className="border-t pt-4 mt-4">
                          <div className="grid grid-cols-3 gap-4 text-sm">
                            <div>
                              <p className="text-muted-foreground">Total Passengers</p>
                              <p>{booking.totalPassengers}</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground">Contact Phone</p>
                              <p>{booking.contactPhone}</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground">Amount</p>
                              <p>₹{booking.totalAmount}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Refunds Tab */}
          <TabsContent value="refunds" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Refund Requests</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {refunds.filter(r => r.status === 'pending').length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      No pending refund requests
                    </div>
                  ) : (
                    refunds.filter(r => r.status === 'pending').map((refund) => (
                      <div key={refund.id} className="border rounded-lg p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4>Booking #{refund.bookingId}</h4>
                            <p className="text-sm text-muted-foreground">Reason: {refund.reason}</p>
                            <p className="text-sm">Amount: ₹{refund.amount}</p>
                          </div>
                          <div className="flex gap-2">
                            <Button 
                              size="sm" 
                              onClick={() => handleProcessRefund(refund.id, 'approved')}
                            >
                              Approve
                            </Button>
                            <Button 
                              size="sm" 
                              variant="destructive"
                              onClick={() => handleProcessRefund(refund.id, 'rejected')}
                            >
                              Reject
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <User className="h-5 w-5" />
                      Admin Profile
                    </CardTitle>
                    <CardDescription>
                      View and update your profile information
                    </CardDescription>
                  </div>
                  {!isEditingProfile && (
                    <Button onClick={() => setIsEditingProfile(true)}>
                      Edit Profile
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {isEditingProfile ? (
                  <form onSubmit={handleUpdateProfile} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label>Full Name *</Label>
                        <Input
                          value={profileData.name}
                          onChange={(e) => setProfileData({...profileData, name: e.target.value})}
                          required
                        />
                      </div>
                      <div>
                        <Label>Email *</Label>
                        <Input
                          type="email"
                          value={profileData.email}
                          onChange={(e) => setProfileData({...profileData, email: e.target.value})}
                          required
                        />
                      </div>
                      <div>
                        <Label>Phone *</Label>
                        <Input
                          value={profileData.phone}
                          onChange={(e) => setProfileData({...profileData, phone: e.target.value})}
                          required
                        />
                      </div>
                      <div>
                        <Label>Role</Label>
                        <Input
                          value={profileData.role}
                          disabled
                        />
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button type="submit">Save Changes</Button>
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => {
                          setIsEditingProfile(false);
                          setProfileData(profile);
                        }}
                      >
                        Cancel
                      </Button>
                    </div>
                  </form>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Full Name</p>
                      <p>{profile?.name || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Email</p>
                      <p>{profile?.email || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Phone</p>
                      <p>{profile?.phone || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Role</p>
                      <p>{profile?.role || 'N/A'}</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
