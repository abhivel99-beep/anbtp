import { useState, useEffect } from 'react';
import { CheckCircle, XCircle, Clock, Eye } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Textarea } from './ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from './ui/dialog';
import { api } from '../utils/api';

export function ApprovalPanel() {
  const [registrations, setRegistrations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedReg, setSelectedReg] = useState<any>(null);
  const [showDialog, setShowDialog] = useState(false);
  const [comments, setComments] = useState('');
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    loadRegistrations();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadRegistrations = async () => {
    setLoading(true);
    try {
      const { registrations: data } = await api.getPendingRegistrations();
      setRegistrations(data || []);
    } catch (error) {
      console.error('Failed to load pending registrations:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleView = (reg: any) => {
    setSelectedReg(reg);
    setShowDialog(true);
    setComments('');
  };

  const handleApprove = async (approved: boolean) => {
    if (!selectedReg) return;
    
    setProcessing(true);
    try {
      await api.approveRegistration(selectedReg.id, approved, comments);
      alert(`Registration ${approved ? 'approved' : 'rejected'} successfully!`);
      setShowDialog(false);
      setSelectedReg(null);
      setComments('');
      loadRegistrations();
    } catch (error) {
      console.error('Failed to process registration:', error);
      alert('Failed to process registration');
    } finally {
      setProcessing(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-center">
          <div className="h-8 w-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p>Loading registrations...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h3>Registration Approvals</h3>
          <p className="text-sm text-muted-foreground">
            Review and approve operator/agent registrations
          </p>
        </div>
        <Button variant="outline" onClick={loadRegistrations}>
          Refresh
        </Button>
      </div>

      {registrations.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center text-muted-foreground">
            <Clock className="h-12 w-12 mx-auto mb-4 text-gray-400" />
            <p>No pending registrations</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {registrations.map((reg) => (
            <Card key={reg.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg">{reg.name}</CardTitle>
                    <CardDescription>
                      {reg.email} • {reg.role}
                    </CardDescription>
                  </div>
                  <span className="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-xs">
                    Pending
                  </span>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                  <div>
                    <p className="text-muted-foreground">Phone</p>
                    <p>{reg.phone || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Registered</p>
                    <p>{new Date(reg.createdAt).toLocaleDateString()}</p>
                  </div>
                  
                  {reg.role === 'operator' && (
                    <>
                      <div>
                        <p className="text-muted-foreground">Company</p>
                        <p>{reg.companyName || 'N/A'}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Reg. Number</p>
                        <p>{reg.registrationNumber || 'N/A'}</p>
                      </div>
                    </>
                  )}
                  
                  {reg.role === 'agent' && (
                    <>
                      <div>
                        <p className="text-muted-foreground">Agency</p>
                        <p>{reg.agencyName || 'N/A'}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">License</p>
                        <p>{reg.agencyLicense || 'N/A'}</p>
                      </div>
                    </>
                  )}
                </div>
                
                <Button 
                  onClick={() => handleView(reg)}
                  variant="outline"
                  className="w-full"
                >
                  <Eye className="h-4 w-4 mr-2" />
                  Review & Approve
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Review Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Review Registration</DialogTitle>
            <DialogDescription>
              Review the details and approve or reject this registration
            </DialogDescription>
          </DialogHeader>

          {selectedReg && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Name</p>
                  <p>{selectedReg.name}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Email</p>
                  <p>{selectedReg.email}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Role</p>
                  <p className="capitalize">{selectedReg.role}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Phone</p>
                  <p>{selectedReg.phone || 'N/A'}</p>
                </div>
                <div className="col-span-2">
                  <p className="text-muted-foreground">Address</p>
                  <p>{selectedReg.address || 'N/A'}</p>
                </div>
              </div>

              {selectedReg.role === 'operator' && (
                <div className="border-t pt-4">
                  <h4 className="mb-3">Operator Details</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Operator Name</p>
                      <p>{selectedReg.operatorName || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Boat Name</p>
                      <p>{selectedReg.boatName || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Boat Type</p>
                      <p>{selectedReg.boatType || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Registration Number</p>
                      <p>{selectedReg.boatRegistrationNumber || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Expiry Date</p>
                      <p>{selectedReg.boatExpiryDate || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Passenger Capacity</p>
                      <p>{selectedReg.passengerCapacity || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Master/Captain</p>
                      <p>{selectedReg.masterName || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Master License</p>
                      <p>{selectedReg.masterLicense || 'N/A'}</p>
                    </div>
                    <div className="col-span-2">
                      <p className="text-muted-foreground">Specified Routes</p>
                      <p>{selectedReg.routes || 'N/A'}</p>
                    </div>
                  </div>
                  
                  <div className="mt-4">
                    <h4 className="mb-2 text-sm">Uploaded Documents</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
                        <span>Passenger Insurance Certificate</span>
                        <span className="text-green-600">✓ Uploaded</span>
                      </div>
                      <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
                        <span>Hull & Machinery Certificate</span>
                        <span className="text-green-600">✓ Uploaded</span>
                      </div>
                      <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
                        <span>Survey Report Form 2</span>
                        <span className="text-green-600">✓ Uploaded</span>
                      </div>
                      <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
                        <span>Survey Report Form 6</span>
                        <span className="text-green-600">✓ Uploaded</span>
                      </div>
                      <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
                        <span>Boat Registration Certificate (Form 8)</span>
                        <span className="text-green-600">✓ Uploaded</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {selectedReg.role === 'agent' && (
                <div className="border-t pt-4">
                  <h4 className="mb-3">Travel Agent Details</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Agency Name</p>
                      <p>{selectedReg.agencyName || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Contact Person</p>
                      <p>{selectedReg.contactPerson || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">GSTIN / Company Reg. No.</p>
                      <p>{selectedReg.gstin || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">PAN Card</p>
                      <p>{selectedReg.panCard || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Bank Account Number</p>
                      <p>{selectedReg.bankAccountNumber || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">IFSC Code</p>
                      <p>{selectedReg.bankIfsc || 'N/A'}</p>
                    </div>
                    <div className="col-span-2">
                      <p className="text-muted-foreground">Bank Name</p>
                      <p>{selectedReg.bankName || 'N/A'}</p>
                    </div>
                  </div>
                  
                  <div className="mt-4">
                    <h4 className="mb-2 text-sm">Uploaded Documents</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
                        <span>Business Registration Certificate</span>
                        <span className="text-green-600">✓ Uploaded</span>
                      </div>
                      <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
                        <span>Address Proof</span>
                        <span className="text-green-600">✓ Uploaded</span>
                      </div>
                      <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
                        <span>Identity Proof</span>
                        <span className="text-green-600">✓ Uploaded</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="border-t pt-4">
                <label className="block text-sm mb-2">Admin Comments (Optional)</label>
                <Textarea
                  value={comments}
                  onChange={(e) => setComments(e.target.value)}
                  placeholder="Add any comments or notes..."
                  rows={3}
                />
              </div>
            </div>
          )}

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowDialog(false)}
              disabled={processing}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => handleApprove(false)}
              disabled={processing}
            >
              <XCircle className="h-4 w-4 mr-2" />
              Reject
            </Button>
            <Button
              onClick={() => handleApprove(true)}
              disabled={processing}
            >
              <CheckCircle className="h-4 w-4 mr-2" />
              Approve
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
