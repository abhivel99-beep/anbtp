import { useState } from 'react';
import { seedDemoData } from '../utils/seedData';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Loader2, CheckCircle, AlertCircle } from 'lucide-react';

interface InitializeDataProps {
  onComplete: () => void;
}

export function InitializeData({ onComplete }: InitializeDataProps) {
  const [status, setStatus] = useState<'idle' | 'seeding' | 'success' | 'error'>('idle');

  const handleInitialize = async () => {
    setStatus('seeding');
    try {
      await seedDemoData();
      localStorage.setItem('andaman_initialized', 'true');
      setStatus('success');
      setTimeout(() => {
        onComplete();
      }, 2000);
    } catch (error) {
      console.error('Initialization failed:', error);
      setStatus('error');
    }
  };

  const handleSkip = () => {
    localStorage.setItem('andaman_initialized', 'true');
    onComplete();
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          {status === 'idle' && (
            <>
              <CardTitle>Welcome to Andaman Boat Ticketing</CardTitle>
              <CardDescription>
                Initialize the system with demo data to get started
              </CardDescription>
            </>
          )}
          {status === 'seeding' && (
            <>
              <Loader2 className="h-12 w-12 animate-spin mx-auto mb-4 text-blue-600" />
              <CardTitle>Setting Up Your System</CardTitle>
              <CardDescription>
                Creating demo accounts, 2 operational boats, and 7-day schedules...
              </CardDescription>
            </>
          )}
          {status === 'success' && (
            <>
              <CheckCircle className="h-12 w-12 mx-auto mb-4 text-green-600" />
              <CardTitle>System Ready!</CardTitle>
              <CardDescription>
                Demo data created successfully. Redirecting...
              </CardDescription>
            </>
          )}
          {status === 'error' && (
            <>
              <AlertCircle className="h-12 w-12 mx-auto mb-4 text-red-600" />
              <CardTitle>Initialization Failed</CardTitle>
              <CardDescription>
                Please check the console and try again
              </CardDescription>
            </>
          )}
        </CardHeader>
        <CardContent>
          {status === 'idle' && (
            <div className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg text-sm">
                <p className="mb-2">This will create:</p>
                <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                  <li>5 demo user accounts (Admin, Operator, Agent, Boarding, PCU)</li>
                  <li>2 operational boats with different capacities</li>
                  <li>Schedules for the next 7 days</li>
                  <li>All routes: Ross Island, North Bay, Combined</li>
                </ul>
              </div>
              <Button onClick={handleInitialize} className="w-full">
                Initialize System
              </Button>
              <Button
                variant="outline"
                onClick={handleSkip}
                className="w-full"
              >
                Skip (Use Existing Data)
              </Button>
            </div>
          )}
          {status === 'error' && (
            <Button onClick={handleInitialize} className="w-full">
              Try Again
            </Button>
          )}
          {status === 'success' && (
            <div className="space-y-2 text-sm text-center text-muted-foreground">
              <p>Demo login credentials:</p>
              <p>admin@andaman.com / demo123</p>
              <p>operator@andaman.com / demo123</p>
              <p>agent@andaman.com / demo123</p>
              <p>boarding@andaman.com / demo123</p>
              <p>pcu@andaman.com / demo123</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
