import { useState, useEffect } from 'react';
import { Ship, Calendar, Users, User, Upload, FileText, CheckCircle, Clock, AlertCircle, DollarSign } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { api } from '../utils/api';

export function OperatorDashboard() {
  const [myBoat, setMyBoat] = useState<any>(null);
  const [schedules, setSchedules] = useState<any[]>([]);
  const [passengers, setPassengers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState<any>(null);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);

  // Boat registration form (for new operators)
  const [showRegistrationForm, setShowRegistrationForm] = useState(false);
  const [boatData, setBoatData] = useState({
    name: '',
    type: 'ferry',
    registrationNumber: '',
    capacity: '',
    ownerName: '',
    ownerPhone: '',
    ownerEmail: '',
    ownerAddress: '',
    insuranceNumber: '',
    insuranceExpiry: '',
    fitnessExpiry: '',
  });

  useEffect(() => {
    loadData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedDate]);

  const loadData = async () => {
    setLoading(true);
    try {
      // Get current user profile
      const userData = await api.getMe();
      const currentUserId = userData.user?.id || userData.id;
      
      // Load operator's boat information
      const boatsData = await api.getBoats();
      
      // Filter for current operator's boats only
      const myBoats = boatsData.boats.filter((b: any) => 
        b.createdBy === currentUserId && (b.status === 'active' || b.status === 'approved')
      );
      
      const operatorBoat = myBoats[0]; // Get first boat
      
      setMyBoat(operatorBoat);

      if (operatorBoat) {
        // Load schedules assigned to this boat
        const schedulesData = await api.getSchedules();
        const mySchedules = schedulesData.schedules.filter(
          (s: any) => s.boatId === operatorBoat.id && s.date === selectedDate
        );
        setSchedules(mySchedules);

        // Load passengers assigned to this boat
        const { bookings } = await api.searchBookings({ date: selectedDate });
        const myBookings = bookings.filter((b: any) => 
          b.assignedBoat === operatorBoat.id || 
          mySchedules.some((s: any) => s.id === b.scheduleId)
        );
        
        // Extract all passengers from bookings
        const allPassengers: any[] = [];
        myBookings.forEach((booking: any) => {
          if (booking.passengers && Array.isArray(booking.passengers)) {
            booking.passengers.forEach((p: any) => {
              allPassengers.push({
                ...p,
                bookingId: booking.id,
                contactPhone: booking.contactPhone,
                contactEmail: booking.contactEmail,
                date: booking.date,
                route: booking.route,
              });
            });
          }
        });
        setPassengers(allPassengers);
      } else {
        // No boat registered yet
        setShowRegistrationForm(true);
      }

    } catch (error) {
      console.error('Failed to load dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleRegisterBoat = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.createBoat({
        name: boatData.name,
        capacity: parseInt(boatData.capacity),
        registrationNumber: boatData.registrationNumber,
        type: boatData.type,
        status: 'active'
      });
      alert('Boat registered successfully! Awaiting admin approval.');
      setShowRegistrationForm(false);
      setBoatData({
        name: '',
        type: 'ferry',
        registrationNumber: '',
        capacity: '',
        ownerName: '',
        ownerPhone: '',
        ownerEmail: '',
        ownerAddress: '',
        insuranceNumber: '',
        insuranceExpiry: '',
        fitnessExpiry: '',
      });
      loadData();
    } catch (error) {
      console.error('Failed to register boat:', error);
      alert('Failed to register boat');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <Clock className="h-8 w-8 animate-spin mx-auto mb-4" />
          <p>Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  // If no boat registered yet, show registration form
  if (!myBoat || showRegistrationForm) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4">
          <div className="mb-8 text-center">
            <h1>Boat Operator Registration</h1>
            <p className="text-muted-foreground">Register your boat to start operating tours</p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Ship className="h-5 w-5" />
                Register Your Boat
              </CardTitle>
              <CardDescription>
                Fill in all details accurately. Your registration will be reviewed and approved by the admin.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleRegisterBoat} className="space-y-6">
                <div className="space-y-4">
                  <h4 className="text-blue-900">Boat Information</h4>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Boat Name *</Label>
                      <Input
                        value={boatData.name}
                        onChange={(e) => setBoatData({ ...boatData, name: e.target.value })}
                        placeholder="e.g., Sea Hawk"
                        required
                      />
                    </div>
                    <div>
                      <Label>Boat Type *</Label>
                      <Select value={boatData.type} onValueChange={(value) => setBoatData({ ...boatData, type: value })}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="ferry">Ferry</SelectItem>
                          <SelectItem value="speedboat">Speed Boat</SelectItem>
                          <SelectItem value="yacht">Yacht</SelectItem>
                          <SelectItem value="cruise">Cruise</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Registration Number *</Label>
                      <Input
                        value={boatData.registrationNumber}
                        onChange={(e) => setBoatData({ ...boatData, registrationNumber: e.target.value })}
                        placeholder="e.g., AN-2024-001"
                        required
                      />
                    </div>
                    <div>
                      <Label>Passenger Capacity *</Label>
                      <Input
                        type="number"
                        value={boatData.capacity}
                        onChange={(e) => setBoatData({ ...boatData, capacity: e.target.value })}
                        placeholder="e.g., 50"
                        min="1"
                        required
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-4 pt-4 border-t">
                  <h4 className="text-blue-900">Owner Information</h4>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Owner Name *</Label>
                      <Input
                        value={boatData.ownerName}
                        onChange={(e) => setBoatData({ ...boatData, ownerName: e.target.value })}
                        required
                      />
                    </div>
                    <div>
                      <Label>Contact Phone *</Label>
                      <Input
                        value={boatData.ownerPhone}
                        onChange={(e) => setBoatData({ ...boatData, ownerPhone: e.target.value })}
                        placeholder="+91 XXXXX XXXXX"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Email *</Label>
                      <Input
                        type="email"
                        value={boatData.ownerEmail}
                        onChange={(e) => setBoatData({ ...boatData, ownerEmail: e.target.value })}
                        required
                      />
                    </div>
                    <div>
                      <Label>Address *</Label>
                      <Input
                        value={boatData.ownerAddress}
                        onChange={(e) => setBoatData({ ...boatData, ownerAddress: e.target.value })}
                        required
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-4 pt-4 border-t">
                  <h4 className="text-blue-900">Compliance Documents</h4>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Insurance Number *</Label>
                      <Input
                        value={boatData.insuranceNumber}
                        onChange={(e) => setBoatData({ ...boatData, insuranceNumber: e.target.value })}
                        required
                      />
                    </div>
                    <div>
                      <Label>Insurance Expiry Date *</Label>
                      <Input
                        type="date"
                        value={boatData.insuranceExpiry}
                        onChange={(e) => setBoatData({ ...boatData, insuranceExpiry: e.target.value })}
                        min={new Date().toISOString().split('T')[0]}
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Fitness Certificate Expiry *</Label>
                      <Input
                        type="date"
                        value={boatData.fitnessExpiry}
                        onChange={(e) => setBoatData({ ...boatData, fitnessExpiry: e.target.value })}
                        min={new Date().toISOString().split('T')[0]}
                        required
                      />
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-sm text-blue-800">
                    <strong>Note:</strong> After submission, your boat registration will be reviewed by the admin. 
                    You will be notified once approved. Please ensure all information is accurate.
                  </p>
                </div>

                <div className="flex gap-2">
                  <Button type="submit">Submit for Approval</Button>
                  {myBoat && (
                    <Button type="button" variant="outline" onClick={() => setShowRegistrationForm(false)}>
                      Cancel
                    </Button>
                  )}
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Main dashboard for approved operators
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1>Boat Operator Dashboard</h1>
          <p className="text-muted-foreground">Manage your boat operations and view assigned passengers</p>
        </div>

        {/* Boat Status Card */}
        <Card className="mb-6 border-green-200 bg-green-50">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Ship className="h-6 w-6 text-green-600" />
                  {myBoat.name}
                </CardTitle>
                <CardDescription>Registration: {myBoat.registrationNumber}</CardDescription>
              </div>
              <div className="flex items-center gap-2 px-3 py-1 bg-green-100 text-green-700 rounded-full">
                <CheckCircle className="h-4 w-4" />
                <span className="text-sm">Active & Approved</span>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Capacity</p>
                <p className="text-xl text-green-600">{myBoat.capacity} pax</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Type</p>
                <p className="text-xl capitalize">{myBoat.type || 'Ferry'}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Today's Schedules</p>
                <p className="text-xl text-green-600">{schedules.length}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Assigned Passengers</p>
                <p className="text-xl text-green-600">{passengers.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="schedule" className="space-y-4">
          <TabsList>
            <TabsTrigger value="schedule">My Schedule</TabsTrigger>
            <TabsTrigger value="passengers">Assigned Passengers</TabsTrigger>
            <TabsTrigger value="payments">Payments</TabsTrigger>
            <TabsTrigger value="profile">Boat Profile</TabsTrigger>
          </TabsList>

          {/* Schedule Tab */}
          <TabsContent value="schedule" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5" />
                    Schedule Assigned to {myBoat.name}
                  </CardTitle>
                  <Input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="w-auto"
                  />
                </div>
                <CardDescription>
                  View schedules assigned to your boat by the admin
                </CardDescription>
              </CardHeader>
              <CardContent>
                {schedules.length === 0 ? (
                  <div className="text-center py-12">
                    <Calendar className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                    <p className="text-muted-foreground">No schedules assigned for {selectedDate}</p>
                    <p className="text-sm text-muted-foreground mt-2">
                      Admin will assign schedules to your boat. Check back later.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {schedules.map((schedule) => (
                      <div key={schedule.id} className="border rounded-lg p-4 bg-blue-50">
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="capitalize">{schedule.route}</h4>
                            <p className="text-sm text-muted-foreground">
                              Departure: {schedule.departureTime} | Return: {schedule.returnTime}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="text-sm">Booked: {schedule.bookedSeats || 0} / {myBoat.capacity}</p>
                            <p className="text-xs text-muted-foreground">
                              {myBoat.capacity - (schedule.bookedSeats || 0)} seats available
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Passengers Tab */}
          <TabsContent value="passengers" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Passengers Assigned to Your Boat
                </CardTitle>
                <CardDescription>
                  List of passengers assigned to {myBoat.name} by the boarding team for {selectedDate}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {passengers.length === 0 ? (
                  <div className="text-center py-12">
                    <Users className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                    <p className="text-muted-foreground">No passengers assigned yet for {selectedDate}</p>
                    <p className="text-sm text-muted-foreground mt-2">
                      Boarding team will assign passengers to your boat at the boarding point.
                    </p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-gray-50 border-b">
                        <tr>
                          <th className="px-4 py-3 text-left text-xs">#</th>
                          <th className="px-4 py-3 text-left text-xs">Name</th>
                          <th className="px-4 py-3 text-left text-xs">Age</th>
                          <th className="px-4 py-3 text-left text-xs">Gender</th>
                          <th className="px-4 py-3 text-left text-xs">Booking ID</th>
                          <th className="px-4 py-3 text-left text-xs">Route</th>
                          <th className="px-4 py-3 text-left text-xs">Contact</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y">
                        {passengers.map((passenger, index) => (
                          <tr key={index} className="hover:bg-gray-50">
                            <td className="px-4 py-3 text-sm">{index + 1}</td>
                            <td className="px-4 py-3 text-sm">
                              {passenger.name}
                              {passenger.isInfant && <span className="ml-2 text-xs text-green-600">(Infant)</span>}
                            </td>
                            <td className="px-4 py-3 text-sm">{passenger.age}</td>
                            <td className="px-4 py-3 text-sm capitalize">{passenger.isInfant ? '-' : (passenger.gender || '-')}</td>
                            <td className="px-4 py-3 text-sm text-blue-600">{passenger.bookingId}</td>
                            <td className="px-4 py-3 text-sm capitalize">{passenger.route}</td>
                            <td className="px-4 py-3 text-sm">{passenger.contactPhone}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Payment Dashboard Tab */}
          <TabsContent value="payments" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5" />
                  Payment Dashboard
                </CardTitle>
                <CardDescription>Track your earnings and trip history</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                      <p className="text-sm text-muted-foreground">Total Passengers</p>
                      <p className="text-3xl text-green-600 mt-2">{passengers.length}</p>
                      <p className="text-xs text-muted-foreground mt-1">Lifetime count</p>
                    </div>
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <p className="text-sm text-muted-foreground">Active Schedules</p>
                      <p className="text-3xl text-blue-600 mt-2">{schedules.length}</p>
                      <p className="text-xs text-muted-foreground mt-1">For {selectedDate}</p>
                    </div>
                    <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                      <p className="text-sm text-muted-foreground">Trips Today</p>
                      <p className="text-3xl text-yellow-600 mt-2">{schedules.filter(s => s.date === new Date().toISOString().split('T')[0]).length}</p>
                      <p className="text-xs text-muted-foreground mt-1">Scheduled</p>
                    </div>
                  </div>
                  <div>
                    <h4 className="mb-4">Recent Trips</h4>
                    <div className="border rounded-lg">
                      <table className="w-full">
                        <thead className="bg-gray-50 border-b">
                          <tr>
                            <th className="px-4 py-3 text-left text-xs">Date</th>
                            <th className="px-4 py-3 text-left text-xs">Route</th>
                            <th className="px-4 py-3 text-left text-xs">Time</th>
                            <th className="px-4 py-3 text-left text-xs">Passengers</th>
                            <th className="px-4 py-3 text-left text-xs">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y">
                          {schedules.map((schedule: any, idx: number) => (
                            <tr key={idx}>
                              <td className="px-4 py-3 text-sm">{schedule.date || selectedDate}</td>
                              <td className="px-4 py-3 text-sm capitalize">{schedule.route}</td>
                              <td className="px-4 py-3 text-sm">{schedule.departureTime || '-'}</td>
                              <td className="px-4 py-3 text-sm">{schedule.bookedSeats || 0}</td>
                              <td className="px-4 py-3 text-sm">
                                <span className="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs">Active</span>
                              </td>
                            </tr>
                          ))}
                          {schedules.length === 0 && (
                            <tr>
                              <td colSpan={5} className="px-4 py-8 text-center text-muted-foreground">No schedules for selected date</td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h4 className="text-blue-900 mb-2">Payment Information</h4>
                    <div className="space-y-2 text-sm text-blue-800">
                      <p>• Payments are processed after trip completion and admin approval</p>
                      <p>• Payment details are managed in the Admin Payment Dispatch dashboard</p>
                      <p>• For payment queries, contact: payments@andamanboats.com</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Boat Profile
                </CardTitle>
                <CardDescription>Complete details of your registered boat</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label className="text-muted-foreground">Boat Name</Label>
                      <p className="text-lg">{myBoat.name}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Registration Number</Label>
                      <p className="text-lg">{myBoat.registrationNumber}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Boat Type</Label>
                      <p className="text-lg capitalize">{myBoat.type || 'Ferry'}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Capacity</Label>
                      <p className="text-lg">{myBoat.capacity} passengers</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Status</Label>
                      <div className="flex items-center gap-2 mt-1">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span className="text-green-600">Active & Approved</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-blue-50 p-4 rounded-lg">
                    <p className="text-sm text-blue-800">
                      <strong>Note:</strong> To update boat information, please contact the admin at admin@andamanboats.com
                    </p>
                  </div>

                  <Button variant="outline" onClick={() => setShowRegistrationForm(true)}>
                    Register Another Boat
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
