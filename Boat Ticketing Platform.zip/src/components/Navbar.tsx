import { Ship, LogOut, User } from 'lucide-react';
import { Button } from './ui/button';

interface NavbarProps {
  user?: any;
  onSignOut?: () => void;
}

export function Navbar({ user, onSignOut }: NavbarProps) {
  return (
    <nav className="border-b bg-white sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center gap-3">
            <Ship className="h-8 w-8 text-blue-600" />
            <div>
              <h1 className="text-xl">Andaman Boat Ticketing</h1>
              <p className="text-xs text-muted-foreground">Seamless Island Travel</p>
            </div>
          </div>
          
          {user && (
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <User className="h-5 w-5" />
                <div className="hidden sm:block">
                  <p className="text-sm">{user.profile?.name || user.user?.email}</p>
                  <p className="text-xs text-muted-foreground capitalize">{user.profile?.role}</p>
                </div>
              </div>
              <Button variant="outline" size="sm" onClick={onSignOut}>
                <LogOut className="h-4 w-4 mr-2" />
                Sign Out
              </Button>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}
