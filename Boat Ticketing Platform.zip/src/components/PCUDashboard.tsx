import { useState, useEffect } from 'react';
import { Users, CheckCircle, AlertCircle, Search, QrCode, Ship, Calendar, MapPin } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { api } from '../utils/api';

const STATUS_COLORS: Record<string, string> = {
  assigned: 'bg-blue-100 text-blue-800',
  boarded: 'bg-green-100 text-green-800',
  pending: 'bg-yellow-100 text-yellow-800',
  flagged: 'bg-red-100 text-red-800',
};

export function PCUDashboard() {
  const [manifest, setManifest] = useState<any[]>([]);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedRoute, setSelectedRoute] = useState('all');
  const [selectedBoat, setSelectedBoat] = useState('all');
  const [boats, setBoats] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [qrInput, setQrInput] = useState('');
  const [verifiedPassenger, setVerifiedPassenger] = useState<any>(null);
  const [stats, setStats] = useState({
    total: 0,
    assigned: 0,
    boarded: 0,
    pending: 0,
    flagged: 0,
  });

  useEffect(() => {
    loadData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedDate, selectedRoute, selectedBoat]);

  const loadData = async () => {
    setLoading(true);
    try {
      // Load boats
      const boatsData = await api.getBoats();
      setBoats(boatsData.boats.filter((b: any) => b.status === 'active' || b.status === 'approved'));

      // Load bookings for the selected date
      const { bookings } = await api.searchBookings({ date: selectedDate });
      
      // Filter by route and boat if selected, AND only show bookings with assigned boats
      let filteredBookings = bookings.filter((b: any) => b.assignedBoat);
      
      if (selectedRoute && selectedRoute !== 'all') {
        filteredBookings = filteredBookings.filter((b: any) => b.route === selectedRoute);
      }
      if (selectedBoat && selectedBoat !== 'all') {
        filteredBookings = filteredBookings.filter((b: any) => b.assignedBoat === selectedBoat);
      }

      // Extract all passengers with their booking info
      const passengers: any[] = [];
      filteredBookings.forEach((booking: any) => {
        if (booking.passengers && Array.isArray(booking.passengers)) {
          booking.passengers.forEach((p: any) => {
            passengers.push({
              ...p,
              bookingId: booking.id,
              contactPhone: booking.contactPhone,
              contactEmail: booking.contactEmail,
              date: booking.date,
              route: booking.route,
              boatId: booking.assignedBoat,
              boatName: boats.find((b: any) => b.id === booking.assignedBoat)?.name || 'Not Assigned',
              boardingStatus: booking.boardingStatus || 'pending',
              departureTime: booking.departureTime,
            });
          });
        }
      });

      setManifest(passengers);

      // Calculate stats
      const stats = {
        total: passengers.length,
        assigned: passengers.filter((p: any) => p.boardingStatus === 'assigned').length,
        boarded: passengers.filter((p: any) => p.boardingStatus === 'boarded').length,
        pending: passengers.filter((p: any) => !p.boardingStatus || p.boardingStatus === 'pending').length,
        flagged: passengers.filter((p: any) => p.boardingStatus === 'flagged').length,
      };
      setStats(stats);
    } catch (error) {
      console.error('Failed to load manifest:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyPassenger = async () => {
    if (!qrInput) {
      alert('Please enter Booking ID or scan QR code');
      return;
    }

    setLoading(true);
    try {
      const searchId = qrInput.replace('BOOKING-', '');
      const { bookings } = await api.searchBookings({ bookingId: searchId });
      
      if (bookings && bookings.length > 0) {
        const booking = bookings[0];
        setVerifiedPassenger(booking);
        alert('✓ Passenger verified successfully!');
      } else {
        alert('❌ Booking not found. Please check the Booking ID.');
        setVerifiedPassenger(null);
      }
    } catch (error) {
      console.error('Failed to verify passenger:', error);
      alert('❌ Verification failed. Please try again.');
      setVerifiedPassenger(null);
    } finally {
      setLoading(false);
    }
  };

  const handleMarkBoarded = async (bookingId: string) => {
    if (!confirm('Mark this passenger as boarded?')) return;

    setLoading(true);
    try {
      await api.updateBoardingStatus(bookingId, 'boarded');
      alert('✓ Passenger marked as boarded!');
      loadData();
      setVerifiedPassenger(null);
      setQrInput('');
    } catch (error) {
      console.error('Failed to mark as boarded:', error);
      alert('Failed to update boarding status');
    } finally {
      setLoading(false);
    }
  };

  const handleFlagIssue = async (bookingId: string) => {
    const reason = prompt('Enter reason for flagging:');
    if (!reason) return;

    setLoading(true);
    try {
      await api.updateBoardingStatus(bookingId, 'flagged', reason);
      alert('⚠️ Passenger flagged for review');
      loadData();
    } catch (error) {
      console.error('Failed to flag passenger:', error);
      alert('Failed to flag passenger');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1>Passenger Coordination Unit (PCU)</h1>
          <p className="text-muted-foreground">
            On-ground operational interface for passenger verification and boarding coordination
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-sm text-muted-foreground">Total</p>
                <p className="text-2xl">{stats.total}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-sm text-muted-foreground">Assigned</p>
                <p className="text-2xl text-blue-600">{stats.assigned}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-sm text-muted-foreground">Boarded</p>
                <p className="text-2xl text-green-600">{stats.boarded}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-sm text-muted-foreground">Pending</p>
                <p className="text-2xl text-yellow-600">{stats.pending}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-sm text-muted-foreground">Flagged</p>
                <p className="text-2xl text-red-600">{stats.flagged}</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Passenger Manifest
            </CardTitle>
            <CardDescription>
              Filter and view all assigned passengers
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <Label htmlFor="date">Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="route">Route</Label>
                <Select value={selectedRoute} onValueChange={setSelectedRoute}>
                  <SelectTrigger>
                    <SelectValue placeholder="All routes" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Routes</SelectItem>
                    <SelectItem value="ross">Ross Island</SelectItem>
                    <SelectItem value="northbay">North Bay</SelectItem>
                    <SelectItem value="combined">Combined</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="boat">Boat</Label>
                <Select value={selectedBoat} onValueChange={setSelectedBoat}>
                  <SelectTrigger>
                    <SelectValue placeholder="All boats" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Boats</SelectItem>
                    {boats.map((boat) => (
                      <SelectItem key={boat.id} value={boat.id}>
                        {boat.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-end">
                <Button onClick={loadData} variant="outline" className="w-full">
                  <Search className="h-4 w-4 mr-2" />
                  Refresh
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Manifest Table */}
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs">#</th>
                    <th className="px-6 py-3 text-left text-xs">Booking ID</th>
                    <th className="px-6 py-3 text-left text-xs">Passenger Name</th>
                    <th className="px-6 py-3 text-left text-xs">Age</th>
                    <th className="px-6 py-3 text-left text-xs">Contact</th>
                    <th className="px-6 py-3 text-left text-xs">Boat</th>
                    <th className="px-6 py-3 text-left text-xs">Route</th>
                    <th className="px-6 py-3 text-left text-xs">Departure</th>
                    <th className="px-6 py-3 text-left text-xs">Status</th>
                    <th className="px-6 py-3 text-left text-xs">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {loading ? (
                    <tr>
                      <td colSpan={10} className="px-6 py-8 text-center text-muted-foreground">
                        Loading manifest...
                      </td>
                    </tr>
                  ) : manifest.length === 0 ? (
                    <tr>
                      <td colSpan={10} className="px-6 py-8 text-center text-muted-foreground">
                        <Ship className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                        <p>No passengers found for selected filters</p>
                        <p className="text-sm mt-2">Adjust date, route, or boat filters</p>
                      </td>
                    </tr>
                  ) : (
                    manifest.map((passenger, index) => (
                      <tr key={index} className="hover:bg-gray-50">
                        <td className="px-6 py-4 text-sm">{index + 1}</td>
                        <td className="px-6 py-4 text-sm text-blue-600">{passenger.bookingId}</td>
                        <td className="px-6 py-4 text-sm">{passenger.name}</td>
                        <td className="px-6 py-4 text-sm">{passenger.age}</td>
                        <td className="px-6 py-4 text-sm">{passenger.contactPhone}</td>
                        <td className="px-6 py-4 text-sm">{passenger.boatName}</td>
                        <td className="px-6 py-4 text-sm capitalize">{passenger.route}</td>
                        <td className="px-6 py-4 text-sm">{passenger.departureTime || 'N/A'}</td>
                        <td className="px-6 py-4 text-sm">
                          <span className={`px-2 py-1 rounded-full text-xs ${STATUS_COLORS[passenger.boardingStatus] || STATUS_COLORS.pending}`}>
                            {passenger.boardingStatus || 'pending'}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex gap-1">
                            {passenger.boardingStatus !== 'boarded' && (
                              <>
                                <Button
                                  size="sm"
                                  variant="default"
                                  onClick={() => handleMarkBoarded(passenger.bookingId)}
                                  disabled={loading}
                                  title="Mark as Boarded"
                                >
                                  <CheckCircle className="h-3 w-3" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  onClick={() => handleFlagIssue(passenger.bookingId)}
                                  disabled={loading}
                                  title="Flag Issue"
                                >
                                  <AlertCircle className="h-3 w-3" />
                                </Button>
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
