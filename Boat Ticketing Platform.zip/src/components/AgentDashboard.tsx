import { useState, useEffect } from 'react';
import { Users, Calendar, DollarSign, FileText, User } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { BookingFlow } from './BookingFlow';
import { api } from '../utils/api';

export function AgentDashboard() {
  const [stats, setStats] = useState({
    totalBookings: 0,
    totalRevenue: 0,
    todayBookings: 0,
    totalCommission: 0,
  });
  const [bookings, setBookings] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [profile, setProfile] = useState<any>(null);
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [profileData, setProfileData] = useState({
    name: '',
    email: '',
    phone: '',
    agencyName: '',
    address: '',
    gstin: '',
  });

  useEffect(() => {
    loadData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      // Get current agent user
      const userData = await api.getMe();
      const currentUserId = userData.user?.id || userData.id;
      
      // Load only bookings made by this agent
      const { bookings: allBookings } = await api.searchBookings({});
      const data = allBookings.filter((b: any) => b.agentId === currentUserId);
      setBookings(data);

      // Calculate commission based on route
      // Ross Island: ₹50, North Bay: ₹50, Combined: ₹100
      const calculateCommission = (booking: any) => {
        if (booking.route === 'combined') return 100 * booking.payingPassengers;
        return 50 * booking.payingPassengers; // Ross or North Bay
      };

      const totalCommission = data.reduce((sum: number, b: any) => sum + calculateCommission(b), 0);

      // Calculate stats
      const today = new Date().toISOString().split('T')[0];
      const todayBookings = data.filter((b: any) => b.date === today);
      
      setStats({
        totalBookings: data.length,
        totalRevenue: data.reduce((sum: number, b: any) => sum + (b.totalAmount || 0), 0),
        todayBookings: todayBookings.length,
        totalCommission: totalCommission,
      });

      // Load profile (mock data for now)
      setProfile({
        name: 'Agent Name',
        email: 'agent@example.com',
        phone: '+91 98765 43210',
        agencyName: 'Island Tours & Travels',
        address: 'Port Blair, Andaman',
        gstin: 'GST123456789',
      });
      setProfileData({
        name: 'Agent Name',
        email: 'agent@example.com',
        phone: '+91 98765 43210',
        agencyName: 'Island Tours & Travels',
        address: 'Port Blair, Andaman',
        gstin: 'GST123456789',
      });
    } catch (error) {
      console.error('Failed to load data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      // Update profile API call would go here
      setProfile(profileData);
      setIsEditingProfile(false);
      alert('Profile updated successfully!');
    } catch (error) {
      console.error('Failed to update profile:', error);
      alert('Failed to update profile');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1>Agent Dashboard</h1>
          <p className="text-muted-foreground">Manage bookings for your customers</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-blue-600" />
                Total Bookings
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl">{stats.totalBookings}</div>
              <p className="text-sm text-muted-foreground mt-2">All time bookings</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-green-600" />
                Today's Bookings
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl">{stats.todayBookings}</div>
              <p className="text-sm text-muted-foreground mt-2">Bookings today</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-purple-600" />
                Total Revenue
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl">₹{stats.totalRevenue.toFixed(2)}</div>
              <p className="text-sm text-muted-foreground mt-2">All time revenue</p>
            </CardContent>
          </Card>

          <Card className="border-orange-200 bg-orange-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-orange-600" />
                Commission Earned
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl text-orange-600">₹{stats.totalCommission.toFixed(2)}</div>
              <p className="text-sm text-muted-foreground mt-2">Total earnings</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Tabs */}
        <Tabs defaultValue="bookings" className="space-y-4">
          <TabsList>
            <TabsTrigger value="bookings">New Booking</TabsTrigger>
            <TabsTrigger value="history">Booking History</TabsTrigger>
            <TabsTrigger value="profile">Profile</TabsTrigger>
          </TabsList>

          {/* New Booking Tab */}
          <TabsContent value="bookings" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Create New Booking</CardTitle>
                <CardDescription>
                  Book ferry tickets on behalf of your customers
                </CardDescription>
              </CardHeader>
              <CardContent>
                <BookingFlow />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Booking History Tab */}
          <TabsContent value="history" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Booking History</CardTitle>
                <CardDescription>
                  View all bookings made through your agency
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs">Booking ID</th>
                        <th className="px-4 py-3 text-left text-xs">Date</th>
                        <th className="px-4 py-3 text-left text-xs">Route</th>
                        <th className="px-4 py-3 text-left text-xs">Passengers</th>
                        <th className="px-4 py-3 text-left text-xs">Amount</th>
                        <th className="px-4 py-3 text-left text-xs">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {loading ? (
                        <tr>
                          <td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">
                            Loading bookings...
                          </td>
                        </tr>
                      ) : bookings.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">
                            No bookings yet
                          </td>
                        </tr>
                      ) : (
                        bookings.map((booking) => (
                          <tr key={booking.id}>
                            <td className="px-4 py-3 text-sm">{booking.id}</td>
                            <td className="px-4 py-3 text-sm">{booking.date}</td>
                            <td className="px-4 py-3 text-sm capitalize">{booking.route}</td>
                            <td className="px-4 py-3 text-sm">{booking.totalPassengers}</td>
                            <td className="px-4 py-3 text-sm">₹{booking.totalAmount}</td>
                            <td className="px-4 py-3 text-sm">
                              <span className={`px-2 py-1 rounded-full text-xs ${
                                booking.status === 'confirmed' ? 'bg-green-100 text-green-700' :
                                booking.status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                                'bg-gray-100 text-gray-700'
                              }`}>
                                {booking.status}
                              </span>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <User className="h-5 w-5" />
                      Agent Profile
                    </CardTitle>
                    <CardDescription>
                      View and update your profile information
                    </CardDescription>
                  </div>
                  {!isEditingProfile && (
                    <Button onClick={() => setIsEditingProfile(true)}>
                      Edit Profile
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {isEditingProfile ? (
                  <form onSubmit={handleUpdateProfile} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label>Full Name *</Label>
                        <Input
                          value={profileData.name}
                          onChange={(e) => setProfileData({...profileData, name: e.target.value})}
                          required
                        />
                      </div>
                      <div>
                        <Label>Email *</Label>
                        <Input
                          type="email"
                          value={profileData.email}
                          onChange={(e) => setProfileData({...profileData, email: e.target.value})}
                          required
                        />
                      </div>
                      <div>
                        <Label>Phone *</Label>
                        <Input
                          value={profileData.phone}
                          onChange={(e) => setProfileData({...profileData, phone: e.target.value})}
                          required
                        />
                      </div>
                      <div>
                        <Label>Agency Name *</Label>
                        <Input
                          value={profileData.agencyName}
                          onChange={(e) => setProfileData({...profileData, agencyName: e.target.value})}
                          required
                        />
                      </div>
                      <div className="md:col-span-2">
                        <Label>Address</Label>
                        <Input
                          value={profileData.address}
                          onChange={(e) => setProfileData({...profileData, address: e.target.value})}
                        />
                      </div>
                      <div>
                        <Label>GSTIN / Company Reg. No.</Label>
                        <Input
                          value={profileData.gstin}
                          onChange={(e) => setProfileData({...profileData, gstin: e.target.value})}
                        />
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button type="submit">Save Changes</Button>
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => {
                          setIsEditingProfile(false);
                          setProfileData(profile);
                        }}
                      >
                        Cancel
                      </Button>
                    </div>
                  </form>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Full Name</p>
                      <p>{profile?.name || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Email</p>
                      <p>{profile?.email || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Phone</p>
                      <p>{profile?.phone || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Agency Name</p>
                      <p>{profile?.agencyName || 'N/A'}</p>
                    </div>
                    <div className="md:col-span-2">
                      <p className="text-sm text-muted-foreground mb-1">Address</p>
                      <p>{profile?.address || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">GSTIN / Company Reg. No.</p>
                      <p>{profile?.gstin || 'N/A'}</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
