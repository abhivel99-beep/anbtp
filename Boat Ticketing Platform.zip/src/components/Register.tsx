import { useState } from 'react';
import { Ship, UserPlus, Building, Briefcase, Upload, CheckCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Textarea } from './ui/textarea';
import { api } from '../utils/api';

interface RegisterProps {
  onSuccess: () => void;
  onBackToSignIn: () => void;
}

export function Register({ onSuccess, onBackToSignIn }: RegisterProps) {
  const [step, setStep] = useState(1);
  const [role, setRole] = useState('');
  const [formData, setFormData] = useState({
    // Basic Info
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    phone: '',
    address: '',
    
    // Agent specific
    agencyName: '',
    contactPerson: '',
    gstin: '',
    panCard: '',
    bankAccountNumber: '',
    bankIfsc: '',
    bankName: '',
    
    // Operator specific
    operatorName: '',
    boatName: '',
    boatType: '',
    boatRegistrationNumber: '',
    boatExpiryDate: '',
    passengerCapacity: '',
    masterName: '',
    masterLicense: '',
    routes: '',
    
    // OTP
    emailOtp: '',
    mobileOtp: '',
  });
  
  const [documents, setDocuments] = useState({
    // Agent documents
    businessRegistrationCert: null as File | null,
    addressProof: null as File | null,
    identityProof: null as File | null,
    
    // Operator documents
    passengerInsuranceCert: null as File | null,
    hullMachineryCert: null as File | null,
    surveyReportForm2: null as File | null,
    surveyReportForm6: null as File | null,
    boatRegistrationForm8: null as File | null,
  });
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [otpSent, setOtpSent] = useState(false);

  const roleOptions = [
    { value: 'tourist', label: 'Tourist', icon: UserPlus, description: 'Book ferry tickets for personal travel' },
    { value: 'agent', label: 'Travel Agent', icon: Briefcase, description: 'Register as a certified travel agent' },
    { value: 'operator', label: 'Boat Operator', icon: Ship, description: 'Register to operate ferry services' },
  ];

  const updateField = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleFileChange = (field: string, file: File | null) => {
    setDocuments(prev => ({ ...prev, [field]: file }));
  };

  const validateStep1 = () => {
    if (!role) {
      setError('Please select a role');
      return false;
    }
    return true;
  };

  const validateStep2 = () => {
    if (!formData.name || !formData.email || !formData.password || !formData.phone) {
      setError('Please fill all required fields');
      return false;
    }
    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      return false;
    }
    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters');
      return false;
    }
    if (!/^\+?[1-9]\d{9,14}$/.test(formData.phone.replace(/[\s-]/g, ''))) {
      setError('Please enter a valid phone number');
      return false;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      setError('Please enter a valid email address');
      return false;
    }
    return true;
  };

  const validateStep3 = () => {
    if (role === 'agent') {
      if (!formData.agencyName || !formData.contactPerson || !formData.gstin || !formData.panCard || !formData.bankAccountNumber) {
        setError('Please fill all required agent details');
        return false;
      }
    }
    if (role === 'operator') {
      if (!formData.operatorName || !formData.boatName || !formData.boatRegistrationNumber || !formData.passengerCapacity || !formData.masterName) {
        setError('Please fill all required operator details');
        return false;
      }
    }
    return true;
  };

  const validateStep4 = () => {
    if (role === 'agent') {
      if (!documents.businessRegistrationCert || !documents.addressProof || !documents.identityProof) {
        setError('Please upload all required documents');
        return false;
      }
    }
    if (role === 'operator') {
      if (!documents.passengerInsuranceCert || !documents.hullMachineryCert || 
          !documents.surveyReportForm2 || !documents.surveyReportForm6 || !documents.boatRegistrationForm8) {
        setError('Please upload all required documents');
        return false;
      }
    }
    return true;
  };

  const handleSendOTP = async () => {
    setError('');
    try {
      // Mock OTP sending - in production, this would call the backend
      setOtpSent(true);
      alert(`OTP sent to ${formData.email} and ${formData.phone}`);
    } catch (err: any) {
      setError(err.message || 'Failed to send OTP');
    }
  };

  const handleNext = () => {
    setError('');
    
    if (step === 1 && !validateStep1()) return;
    if (step === 2 && !validateStep2()) return;
    if (step === 3 && role !== 'tourist' && !validateStep3()) return;
    if (step === 4 && role !== 'tourist' && !validateStep4()) return;
    
    // For tourist, submit after step 2
    if (role === 'tourist' && step === 2) {
      handleSubmit();
      return;
    }
    
    // For agent/operator, move through all steps
    if (step === 5 || (role === 'tourist' && step === 2)) {
      handleSubmit();
    } else {
      setStep(step + 1);
    }
  };

  const handleSubmit = async () => {
    setError('');
    setLoading(true);
    
    try {
      // In production, documents would be uploaded to storage and URLs saved
      const registrationData = {
        email: formData.email,
        password: formData.password,
        name: formData.name,
        role: role,
        phone: formData.phone,
        address: formData.address,
        status: (role === 'operator' || role === 'agent') ? 'pending' : 'approved',
        
        // Agent-specific data
        ...(role === 'agent' && {
          agencyName: formData.agencyName,
          contactPerson: formData.contactPerson,
          gstin: formData.gstin,
          panCard: formData.panCard,
          bankAccountNumber: formData.bankAccountNumber,
          bankIfsc: formData.bankIfsc,
          bankName: formData.bankName,
          documents: {
            businessRegistrationCert: 'uploaded',
            addressProof: 'uploaded',
            identityProof: 'uploaded',
          }
        }),
        
        // Operator-specific data
        ...(role === 'operator' && {
          operatorName: formData.operatorName,
          boatName: formData.boatName,
          boatType: formData.boatType,
          boatRegistrationNumber: formData.boatRegistrationNumber,
          boatExpiryDate: formData.boatExpiryDate,
          passengerCapacity: formData.passengerCapacity,
          masterName: formData.masterName,
          masterLicense: formData.masterLicense,
          routes: formData.routes,
          documents: {
            passengerInsuranceCert: 'uploaded',
            hullMachineryCert: 'uploaded',
            surveyReportForm2: 'uploaded',
            surveyReportForm6: 'uploaded',
            boatRegistrationForm8: 'uploaded',
          }
        }),
      };

      await api.register(registrationData);
      
      if (role === 'tourist') {
        alert('Registration successful! You can now sign in.');
        onSuccess();
      } else {
        alert(`Registration submitted successfully!\n\nYour ${role} account will be reviewed by our admin team within 3-7 business days.\n\nYou will receive email and SMS notifications about the verification outcome (Approved, Rejected, or Requires More Information).`);
        onSuccess();
      }
    } catch (err: any) {
      setError(err.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  const maxSteps = role === 'tourist' ? 2 : 5;

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white flex items-center justify-center py-12 px-4">
      <Card className="w-full max-w-3xl">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
            <Ship className="h-10 w-10 text-blue-600" />
          </div>
          <CardTitle>Create Account</CardTitle>
          <CardDescription>
            {step === 1 && 'Choose your account type'}
            {step === 2 && 'Enter your basic information'}
            {step === 3 && `${role === 'agent' ? 'Agency' : 'Operator'} Details`}
            {step === 4 && 'Upload Required Documents'}
            {step === 5 && 'OTP Verification'}
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          {/* Progress Indicator */}
          <div className="flex items-center justify-center mb-8">
            {Array.from({ length: maxSteps }, (_, i) => i + 1).map((s, i) => (
              <div key={i} className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${ 
                  step >= s ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'
                }`}>
                  {step > s ? <CheckCircle className="h-5 w-5" /> : s}
                </div>
                {i < maxSteps - 1 && (
                  <div className={`w-12 h-1 mx-2 transition-all ${step > s ? 'bg-blue-600' : 'bg-gray-200'}`} />
                )}
              </div>
            ))}
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-4">
              {error}
            </div>
          )}

          {/* Step 1: Role Selection */}
          {step === 1 && (
            <div className="space-y-4">
              <Label>Select Account Type *</Label>
              <div className="grid gap-4">
                {roleOptions.map((opt) => (
                  <div
                    key={opt.value}
                    onClick={() => setRole(opt.value)}
                    className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                      role === opt.value 
                        ? 'border-blue-600 bg-blue-50' 
                        : 'border-gray-200 hover:border-blue-300'
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                        <opt.icon className="h-6 w-6 text-blue-600" />
                      </div>
                      <div>
                        <h4>{opt.label}</h4>
                        <p className="text-sm text-muted-foreground">{opt.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Step 2: Basic Information */}
          {step === 2 && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="name">Full Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => updateField('name', e.target.value)}
                  placeholder="Enter your full name"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="email">Email Address *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => updateField('email', e.target.value)}
                    placeholder="your@email.com"
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Phone Number *</Label>
                  <Input
                    id="phone"
                    value={formData.phone}
                    onChange={(e) => updateField('phone', e.target.value)}
                    placeholder="+91 XXXXX XXXXX"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="password">Password *</Label>
                  <Input
                    id="password"
                    type="password"
                    value={formData.password}
                    onChange={(e) => updateField('password', e.target.value)}
                    placeholder="Min 6 characters"
                  />
                </div>
                <div>
                  <Label htmlFor="confirmPassword">Confirm Password *</Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    value={formData.confirmPassword}
                    onChange={(e) => updateField('confirmPassword', e.target.value)}
                    placeholder="Re-enter password"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="address">Address *</Label>
                <Textarea
                  id="address"
                  value={formData.address}
                  onChange={(e) => updateField('address', e.target.value)}
                  placeholder="Your complete address"
                  rows={3}
                />
              </div>
            </div>
          )}

          {/* Step 3: Role-specific Details */}
          {step === 3 && role === 'agent' && (
            <div className="space-y-4">
              <div className="bg-blue-50 p-4 rounded-lg mb-4">
                <h4 className="mb-2">Travel Agent Application Form</h4>
                <p className="text-sm text-muted-foreground">
                  Please provide accurate agency and business details. All information will be verified.
                </p>
              </div>

              <div>
                <Label htmlFor="agencyName">Agency Name *</Label>
                <Input
                  id="agencyName"
                  value={formData.agencyName}
                  onChange={(e) => updateField('agencyName', e.target.value)}
                  placeholder="Your travel agency name"
                />
              </div>

              <div>
                <Label htmlFor="contactPerson">Contact Person Details *</Label>
                <Input
                  id="contactPerson"
                  value={formData.contactPerson}
                  onChange={(e) => updateField('contactPerson', e.target.value)}
                  placeholder="Primary contact person name and designation"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="gstin">GSTIN / Company Registration Number *</Label>
                  <Input
                    id="gstin"
                    value={formData.gstin}
                    onChange={(e) => updateField('gstin', e.target.value)}
                    placeholder="e.g., 22AAAAA0000A1Z5"
                  />
                </div>
                <div>
                  <Label htmlFor="panCard">PAN Card of Proprietor/Partners/Directors *</Label>
                  <Input
                    id="panCard"
                    value={formData.panCard}
                    onChange={(e) => updateField('panCard', e.target.value)}
                    placeholder="e.g., ABCDE1234F"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="bankAccountNumber">Bank Account Number *</Label>
                  <Input
                    id="bankAccountNumber"
                    value={formData.bankAccountNumber}
                    onChange={(e) => updateField('bankAccountNumber', e.target.value)}
                    placeholder="Account number"
                  />
                </div>
                <div>
                  <Label htmlFor="bankIfsc">IFSC Code *</Label>
                  <Input
                    id="bankIfsc"
                    value={formData.bankIfsc}
                    onChange={(e) => updateField('bankIfsc', e.target.value)}
                    placeholder="e.g., SBIN0001234"
                  />
                </div>
                <div>
                  <Label htmlFor="bankName">Bank Name *</Label>
                  <Input
                    id="bankName"
                    value={formData.bankName}
                    onChange={(e) => updateField('bankName', e.target.value)}
                    placeholder="Bank name"
                  />
                </div>
              </div>
            </div>
          )}

          {step === 3 && role === 'operator' && (
            <div className="space-y-4">
              <div className="bg-blue-50 p-4 rounded-lg mb-4">
                <h4 className="mb-2">Boat Operator Application Form</h4>
                <p className="text-sm text-muted-foreground">
                  Please provide accurate operator and boat details as per A&N Administration guidelines.
                </p>
              </div>

              <div>
                <Label htmlFor="operatorName">Operator Name and Address *</Label>
                <Input
                  id="operatorName"
                  value={formData.operatorName}
                  onChange={(e) => updateField('operatorName', e.target.value)}
                  placeholder="Operator/Company name"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="boatName">Boat Name *</Label>
                  <Input
                    id="boatName"
                    value={formData.boatName}
                    onChange={(e) => updateField('boatName', e.target.value)}
                    placeholder="Boat name"
                  />
                </div>
                <div>
                  <Label htmlFor="boatType">Boat Type *</Label>
                  <Input
                    id="boatType"
                    value={formData.boatType}
                    onChange={(e) => updateField('boatType', e.target.value)}
                    placeholder="e.g., Ferry, Speed Boat"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="boatRegistrationNumber">Boat Registration Number *</Label>
                  <Input
                    id="boatRegistrationNumber"
                    value={formData.boatRegistrationNumber}
                    onChange={(e) => updateField('boatRegistrationNumber', e.target.value)}
                    placeholder="Registration number"
                  />
                </div>
                <div>
                  <Label htmlFor="boatExpiryDate">Registration Expiry Date *</Label>
                  <Input
                    id="boatExpiryDate"
                    type="date"
                    value={formData.boatExpiryDate}
                    onChange={(e) => updateField('boatExpiryDate', e.target.value)}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="passengerCapacity">Passenger Capacity *</Label>
                <Input
                  id="passengerCapacity"
                  type="number"
                  value={formData.passengerCapacity}
                  onChange={(e) => updateField('passengerCapacity', e.target.value)}
                  placeholder="Maximum passenger capacity"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="masterName">Master/Captain Name *</Label>
                  <Input
                    id="masterName"
                    value={formData.masterName}
                    onChange={(e) => updateField('masterName', e.target.value)}
                    placeholder="Captain name"
                  />
                </div>
                <div>
                  <Label htmlFor="masterLicense">Master License Number</Label>
                  <Input
                    id="masterLicense"
                    value={formData.masterLicense}
                    onChange={(e) => updateField('masterLicense', e.target.value)}
                    placeholder="License number"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="routes">Specified Routes *</Label>
                <Textarea
                  id="routes"
                  value={formData.routes}
                  onChange={(e) => updateField('routes', e.target.value)}
                  placeholder="e.g., Ross Island - North Bay - Viper Island"
                  rows={3}
                />
              </div>
            </div>
          )}

          {/* Step 4: Document Upload */}
          {step === 4 && role === 'agent' && (
            <div className="space-y-4">
              <div className="bg-yellow-50 p-4 rounded-lg mb-4">
                <h4 className="mb-2">Document Upload</h4>
                <p className="text-sm text-yellow-800">
                  Please upload clear, digital copies of the following mandatory documents. All documents will be manually reviewed for authenticity.
                </p>
              </div>

              <DocumentUpload
                label="Business Registration Certificate (GST, Shop & Establishment) *"
                file={documents.businessRegistrationCert}
                onChange={(file) => handleFileChange('businessRegistrationCert', file)}
              />

              <DocumentUpload
                label="Address Proof (Utility Bill, Rent Agreement) *"
                file={documents.addressProof}
                onChange={(file) => handleFileChange('addressProof', file)}
              />

              <DocumentUpload
                label="Identity Proof (PAN Card, Aadhaar Card) of Authorized Signatory *"
                file={documents.identityProof}
                onChange={(file) => handleFileChange('identityProof', file)}
              />
            </div>
          )}

          {step === 4 && role === 'operator' && (
            <div className="space-y-4">
              <div className="bg-yellow-50 p-4 rounded-lg mb-4">
                <h4 className="mb-2">Document Upload</h4>
                <p className="text-sm text-yellow-800">
                  Please upload clear, digital copies as per A&N Administration guidelines. All documents will be manually reviewed.
                </p>
              </div>

              <div className="space-y-4">
                <h4 className="text-sm">Insurance Certificates *</h4>
                <DocumentUpload
                  label="Certificate of Insurance of Passenger"
                  file={documents.passengerInsuranceCert}
                  onChange={(file) => handleFileChange('passengerInsuranceCert', file)}
                />
                <DocumentUpload
                  label="Hull and Machinery Certificate"
                  file={documents.hullMachineryCert}
                  onChange={(file) => handleFileChange('hullMachineryCert', file)}
                />
              </div>

              <div className="space-y-4 pt-4">
                <h4 className="text-sm">Survey Reports *</h4>
                <DocumentUpload
                  label="Form 2"
                  file={documents.surveyReportForm2}
                  onChange={(file) => handleFileChange('surveyReportForm2', file)}
                />
                <DocumentUpload
                  label="Form 6"
                  file={documents.surveyReportForm6}
                  onChange={(file) => handleFileChange('surveyReportForm6', file)}
                />
              </div>

              <div className="pt-4">
                <DocumentUpload
                  label="Valid Boat Registration Certificate (Form 8) *"
                  file={documents.boatRegistrationForm8}
                  onChange={(file) => handleFileChange('boatRegistrationForm8', file)}
                />
              </div>
            </div>
          )}

          {/* Step 5: OTP Verification */}
          {step === 5 && (
            <div className="space-y-4">
              <div className="bg-blue-50 p-4 rounded-lg mb-4">
                <h4 className="mb-2">OTP Verification</h4>
                <p className="text-sm text-muted-foreground">
                  We'll send verification codes to your email ({formData.email}) and mobile number ({formData.phone}) to verify your identity.
                </p>
              </div>

              {!otpSent ? (
                <div className="text-center py-8">
                  <Button onClick={handleSendOTP} size="lg">
                    Send OTP Codes
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="emailOtp">Email OTP *</Label>
                    <Input
                      id="emailOtp"
                      value={formData.emailOtp}
                      onChange={(e) => updateField('emailOtp', e.target.value)}
                      placeholder="Enter 6-digit code from email"
                      maxLength={6}
                    />
                  </div>

                  <div>
                    <Label htmlFor="mobileOtp">Mobile OTP *</Label>
                    <Input
                      id="mobileOtp"
                      value={formData.mobileOtp}
                      onChange={(e) => updateField('mobileOtp', e.target.value)}
                      placeholder="Enter 6-digit code from SMS"
                      maxLength={6}
                    />
                  </div>

                  <Button variant="outline" onClick={handleSendOTP} className="w-full">
                    Resend OTP Codes
                  </Button>
                </div>
              )}
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex justify-between mt-8">
            <Button
              variant="outline"
              onClick={() => step === 1 ? onBackToSignIn() : setStep(step - 1)}
              disabled={loading}
            >
              {step === 1 ? 'Back to Sign In' : 'Back'}
            </Button>
            
            <Button
              onClick={handleNext}
              disabled={loading}
            >
              {loading ? 'Processing...' : 
               (step === maxSteps) ? 'Complete Registration' : 'Next'}
            </Button>
          </div>

          {step === 3 && (role === 'agent' || role === 'operator') && (
            <div className="mt-6 bg-yellow-50 border border-yellow-200 p-4 rounded-lg">
              <p className="text-sm text-yellow-800">
                <strong>Verification Timeline:</strong> Upon successful submission, your application will enter the verification queue. 
                The system will automatically cross-reference details (like GSTIN) with government databases, and the Verification Team 
                will manually review all documents. You'll receive email and SMS notifications about the outcome (Approved, Rejected, or 
                Requires More Information) within 3-7 business days.
              </p>
            </div>
          )}

          <div className="mt-6 text-center">
            <p className="text-sm text-muted-foreground">
              Already have an account?{' '}
              <button
                onClick={onBackToSignIn}
                className="text-blue-600 hover:underline"
              >
                Sign in here
              </button>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function DocumentUpload({ label, file, onChange }: { label: string; file: File | null; onChange: (file: File | null) => void }) {
  return (
    <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 hover:border-blue-400 transition-colors">
      <Label className="block mb-2">{label}</Label>
      <div className="flex items-center gap-4">
        <label className="cursor-pointer">
          <div className="flex items-center gap-2 px-4 py-2 bg-blue-50 text-blue-600 rounded-md hover:bg-blue-100">
            <Upload className="h-4 w-4" />
            <span className="text-sm">Choose File</span>
          </div>
          <input
            type="file"
            className="hidden"
            onChange={(e) => onChange(e.target.files?.[0] || null)}
            accept=".pdf,.jpg,.jpeg,.png"
          />
        </label>
        {file && (
          <div className="flex items-center gap-2 text-sm text-green-600">
            <CheckCircle className="h-4 w-4" />
            <span>{file.name}</span>
          </div>
        )}
        {!file && (
          <span className="text-sm text-muted-foreground">No file chosen</span>
        )}
      </div>
      <p className="text-xs text-muted-foreground mt-2">
        Accepted formats: PDF, JPG, PNG (Max 5MB)
      </p>
    </div>
  );
}
