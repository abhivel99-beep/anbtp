import { useState, useEffect } from 'react';
import { AlertTriangle, Phone, MapPin, Clock, User, CheckCircle, XCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { api } from '../utils/api';

export function EmergencyDashboard() {
  const [emergencies, setEmergencies] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [showNewSOS, setShowNewSOS] = useState(false);
  const [sosForm, setSosForm] = useState({
    callerName: '',
    callerPhone: '',
    bookingId: '',
    location: '',
    emergencyType: '',
    description: '',
  });

  useEffect(() => {
    loadEmergencies();
    // Refresh every 30 seconds
    const interval = setInterval(loadEmergencies, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadEmergencies = async () => {
    try {
      const data = await api.getEmergencies();
      setEmergencies(data.emergencies || []);
    } catch (error) {
      console.error('Failed to load emergencies:', error);
    }
  };

  const handleCreateSOS = async () => {
    if (!sosForm.callerName || !sosForm.callerPhone || !sosForm.emergencyType) {
      alert('Please fill in all required fields');
      return;
    }

    setLoading(true);
    try {
      await api.createEmergency(sosForm);
      setSosForm({
        callerName: '',
        callerPhone: '',
        bookingId: '',
        location: '',
        emergencyType: '',
        description: '',
      });
      setShowNewSOS(false);
      await loadEmergencies();
      alert('Emergency SOS logged successfully!');
    } catch (error) {
      console.error('Failed to create SOS:', error);
      alert('Failed to log emergency. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateStatus = async (emergencyId: string, newStatus: string) => {
    setLoading(true);
    try {
      await api.updateEmergencyStatus(emergencyId, newStatus);
      await loadEmergencies();
    } catch (error) {
      console.error('Failed to update status:', error);
      alert('Failed to update status');
    } finally {
      setLoading(false);
    }
  };

  const activeEmergencies = emergencies.filter(e => e.status === 'active');
  const resolvedEmergencies = emergencies.filter(e => e.status === 'resolved');
  const closedEmergencies = emergencies.filter(e => e.status === 'closed');

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8 flex justify-between items-center">
          <div>
            <h1 className="flex items-center gap-2">
              <AlertTriangle className="h-8 w-8 text-red-600" />
              Emergency SOS & Response Center
            </h1>
            <p className="text-muted-foreground">Monitor and manage emergency calls</p>
          </div>
          <Button onClick={() => setShowNewSOS(!showNewSOS)} className="bg-red-600 hover:bg-red-700">
            + Log New Emergency
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="border-red-200 bg-red-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-red-700">
                <AlertTriangle className="h-5 w-5" />
                Active Emergencies
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl text-red-700">{activeEmergencies.length}</div>
              <p className="text-sm text-muted-foreground mt-2">Require immediate attention</p>
            </CardContent>
          </Card>

          <Card className="border-green-200 bg-green-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-green-700">
                <CheckCircle className="h-5 w-5" />
                Resolved Today
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl text-green-700">{resolvedEmergencies.length}</div>
              <p className="text-sm text-muted-foreground mt-2">Successfully handled</p>
            </CardContent>
          </Card>

          <Card className="border-gray-200 bg-gray-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-gray-700">
                <XCircle className="h-5 w-5" />
                Closed Cases
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl text-gray-700">{closedEmergencies.length}</div>
              <p className="text-sm text-muted-foreground mt-2">Historical records</p>
            </CardContent>
          </Card>
        </div>

        {/* New SOS Form */}
        {showNewSOS && (
          <Card className="mb-8 border-red-300">
            <CardHeader>
              <CardTitle className="text-red-700">Log New Emergency</CardTitle>
              <CardDescription>Fill in details for immediate response</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <Label>Caller Name *</Label>
                  <Input
                    value={sosForm.callerName}
                    onChange={(e) => setSosForm({ ...sosForm, callerName: e.target.value })}
                    placeholder="Full name"
                  />
                </div>
                <div>
                  <Label>Caller Phone *</Label>
                  <Input
                    value={sosForm.callerPhone}
                    onChange={(e) => setSosForm({ ...sosForm, callerPhone: e.target.value })}
                    placeholder="+91 XXXXX XXXXX"
                  />
                </div>
                <div>
                  <Label>Booking ID (if available)</Label>
                  <Input
                    value={sosForm.bookingId}
                    onChange={(e) => setSosForm({ ...sosForm, bookingId: e.target.value })}
                    placeholder="Booking reference"
                  />
                </div>
                <div>
                  <Label>Emergency Type *</Label>
                  <Select
                    value={sosForm.emergencyType}
                    onValueChange={(value) => setSosForm({ ...sosForm, emergencyType: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="medical">Medical Emergency</SelectItem>
                      <SelectItem value="mechanical">Mechanical Failure</SelectItem>
                      <SelectItem value="weather">Weather Related</SelectItem>
                      <SelectItem value="accident">Accident</SelectItem>
                      <SelectItem value="lost">Lost/Missing Passenger</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="mb-4">
                <Label>Current Location</Label>
                <Input
                  value={sosForm.location}
                  onChange={(e) => setSosForm({ ...sosForm, location: e.target.value })}
                  placeholder="Approximate location or coordinates"
                />
              </div>
              <div className="mb-4">
                <Label>Description *</Label>
                <Textarea
                  value={sosForm.description}
                  onChange={(e) => setSosForm({ ...sosForm, description: e.target.value })}
                  placeholder="Detailed description of the emergency"
                  rows={3}
                />
              </div>
              <div className="flex gap-4">
                <Button onClick={handleCreateSOS} disabled={loading} className="bg-red-600 hover:bg-red-700">
                  {loading ? 'Logging...' : 'Log Emergency'}
                </Button>
                <Button variant="outline" onClick={() => setShowNewSOS(false)}>
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Active Emergencies */}
        {activeEmergencies.length > 0 && (
          <div className="mb-8">
            <h2 className="mb-4 text-red-700">⚠️ Active Emergencies</h2>
            <div className="space-y-4">
              {activeEmergencies.map((emergency) => (
                <Card key={emergency.id} className="border-red-300 bg-red-50">
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="text-red-900">Emergency #{emergency.id}</h3>
                        <Badge className="bg-red-600 mt-2">{emergency.emergencyType}</Badge>
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" onClick={() => handleUpdateStatus(emergency.id, 'resolved')}>
                          Mark Resolved
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => handleUpdateStatus(emergency.id, 'closed')}>
                          Close
                        </Button>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4 text-muted-foreground" />
                        <span>{emergency.callerName}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Phone className="h-4 w-4 text-muted-foreground" />
                        <span>{emergency.callerPhone}</span>
                      </div>
                      {emergency.location && (
                        <div className="flex items-center gap-2">
                          <MapPin className="h-4 w-4 text-muted-foreground" />
                          <span>{emergency.location}</span>
                        </div>
                      )}
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span>{new Date(emergency.createdAt).toLocaleString()}</span>
                      </div>
                    </div>
                    {emergency.description && (
                      <div className="mt-3 p-3 bg-white rounded border">
                        <p className="text-sm">{emergency.description}</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Emergency History */}
        <Card>
          <CardHeader>
            <CardTitle>Emergency History</CardTitle>
            <CardDescription>Past and resolved emergencies</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {[...resolvedEmergencies, ...closedEmergencies].map((emergency) => (
                <div key={emergency.id} className="flex justify-between items-center p-3 bg-gray-50 rounded">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <strong className="text-sm">#{emergency.id}</strong>
                      <Badge variant={emergency.status === 'resolved' ? 'default' : 'secondary'}>
                        {emergency.status}
                      </Badge>
                      <span className="text-sm text-muted-foreground">{emergency.emergencyType}</span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      {emergency.callerName} • {emergency.callerPhone} • {new Date(emergency.createdAt).toLocaleString()}
                    </p>
                  </div>
                </div>
              ))}
              {emergencies.length === 0 && (
                <p className="text-center text-muted-foreground py-8">No emergency records found</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
