import { useState } from 'react';
import { Ship, Shield, Smartphone, Clock, CheckCircle, MapPin, MessageSquare, RefreshCw } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { FeedbackRefundPage } from './FeedbackRefundPage';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface PublicHomePageProps {
  onBookNow: () => void;
  onSignIn: () => void;
  onRegister: () => void;
}

export function PublicHomePage({ onBookNow, onSignIn, onRegister }: PublicHomePageProps) {
  const [showFeedback, setShowFeedback] = useState(false);
  const [showRefund, setShowRefund] = useState(false);

  return (
    <div className="min-h-screen bg-white">
      {/* Top Navigation */}
      <nav className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Ship className="h-8 w-8 text-blue-600" />
              <span className="text-xl">Andaman Boat Booking</span>
            </div>
            <div className="flex gap-4">
              <Button variant="ghost" onClick={onSignIn}>
                Sign In
              </Button>
              <Button onClick={onRegister}>
                Register
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <ImageWithFallback 
            src="https://images.unsplash.com/photo-1586359716568-3e1907e4cf9f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbmRhbWFuJTIwaXNsYW5kcyUyMGJlYWNoJTIwdHJvcGljYWx8ZW58MXx8fHwxNzYwMzY3OTY3fDA&ixlib=rb-4.1.0&q=80&w=1080"
            alt="Andaman Islands Beach"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-blue-900/90 to-cyan-800/80"></div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center space-y-6 text-white">
            <h1 className="text-5xl md:text-6xl">
              Book Your Island Adventure
            </h1>
            <p className="text-xl text-blue-50 max-w-2xl mx-auto">
              Your Seamless Journey Across the Andaman Islands
            </p>
            <p className="text-lg text-blue-100 max-w-3xl mx-auto">
              Experience the elegance of maritime travel with <strong>Andaman Boat Booking</strong>. Book ferry tickets online, track schedules in real time, and enjoy a seamless journey across paradise.
            </p>
            
            <div className="flex flex-wrap gap-4 justify-center pt-6">
              <Button 
                size="lg" 
                onClick={onBookNow} 
                className="bg-white text-blue-600 hover:bg-blue-50"
              >
                Book Your Journey →
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Our Service */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl mb-4">
              Why Choose Our Service?
            </h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Experience the perfect blend of tradition and modernity with our premium maritime services — <strong>Safe, Reliable, and Comfortable</strong>.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: Shield,
                title: 'Verified Boats',
                description: 'All boats are safety-certified and regularly inspected to ensure secure travel.',
              },
              {
                icon: Smartphone,
                title: 'E-Tickets',
                description: 'Receive instant QR-code tickets on your phone — skip the queues and embrace digital travel.',
              },
              {
                icon: Clock,
                title: 'Real-Time Info',
                description: 'Get live updates on ferry schedules, delays, and availability to plan your trip with confidence.',
              },
            ].map((feature, i) => (
              <div key={i} className="text-center">
                <div className="mx-auto mb-4 w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
                  <feature.icon className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="mb-2">{feature.title}</h3>
                <p className="text-muted-foreground text-sm">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Popular Destinations with Real Images */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl mb-4">
              Popular Destinations
            </h2>
            <p className="text-lg text-muted-foreground">
              Discover the beauty of the Andaman Islands
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                name: 'Ross Island',
                price: '₹470',
                description: 'Historic ruins and colonial architecture',
                image: 'https://images.unsplash.com/photo-1609676002449-fcccf2e90f4f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxSb3NzJTIwSXNsYW5kJTIwQW5kYW1hbiUyMHJ1aW5zJTIwaGlzdG9yaWN8ZW58MXx8fHwxNzYwMjk4NTgxfDA&ixlib=rb-4.1.0&q=80&w=1080',
              },
              {
                name: 'North Bay',
                price: '₹670',
                description: 'Crystal clear waters and coral reefs',
                image: 'https://images.unsplash.com/photo-1660151186907-8cdf0a347d1f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxOb3J0aCUyMEJheSUyMElzbGFuZCUyMEFuZGFtYW4lMjBjb3JhbCUyMHJlZWYlMjBibHVlJTIwd2F0ZXJ8ZW58MXx8fHwxNzYwMjk4NTgyfDA&ixlib=rb-4.1.0&q=80&w=1080',
              },
              {
                name: 'Ross Island & North Bay',
                price: '₹870',
                description: "Experience both islands in one trip",
                image: 'https://images.unsplash.com/photo-1715940093974-8836926f3f41?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxBbmRhbWFuJTIwaXNsYW5kcyUyMGJlYWNoJTIwdHJvcGljYWwlMjBwYXJhZGlzZXxlbnwxfHx8fDE3NjAyOTg1ODJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
              },
            ].map((dest, i) => (
              <Card key={i} className="overflow-hidden hover:shadow-xl transition-shadow">
                <div className="h-56 overflow-hidden">
                  <ImageWithFallback 
                    src={dest.image} 
                    alt={dest.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <CardTitle>{dest.name}</CardTitle>
                    <span className="text-2xl text-blue-600">{dest.price}</span>
                  </div>
                  <CardDescription>{dest.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700" onClick={onBookNow}>
                    Book Now
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Experience Section with Image */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h2 className="text-4xl">
                Experience Premium Maritime Travel
              </h2>
              <p className="text-lg text-muted-foreground">
                Our modern fleet of boats ensures a safe, comfortable, and memorable journey across the pristine waters of the Andaman Islands.
              </p>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <CheckCircle className="h-6 w-6 text-green-600 flex-shrink-0 mt-0.5" />
                  <span>Safety-certified vessels with experienced crew members</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="h-6 w-6 text-green-600 flex-shrink-0 mt-0.5" />
                  <span>Comfortable seating and life jacket provisions for all passengers</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="h-6 w-6 text-green-600 flex-shrink-0 mt-0.5" />
                  <span>Hassle-free digital booking and instant confirmation</span>
                </li>
              </ul>
              <Button size="lg" onClick={onBookNow} className="bg-blue-600 hover:bg-blue-700">
                Start Your Journey
              </Button>
            </div>
            <div className="rounded-2xl overflow-hidden shadow-2xl">
              <ImageWithFallback 
                src="https://images.unsplash.com/photo-1633775362322-4784126ae819?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmZXJyeSUyMGJvYXQlMjBvY2VhbiUyMHRyYXZlbHxlbnwxfHx8fDE3NjAzNjc5Njd8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Ferry Boat Travel"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Feedback & Refund Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="text-3xl mb-3">
              We Value Your Experience
            </h2>
            <p className="text-muted-foreground">
              Share feedback or request refunds
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="mx-auto mb-4 w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                  <MessageSquare className="h-8 w-8 text-green-600" />
                </div>
                <CardTitle className="text-center">Give Feedback</CardTitle>
              </CardHeader>
              <CardContent className="text-center space-y-4">
                <p className="text-muted-foreground text-sm">
                  Share your travel experience to help us improve
                </p>
                <Button variant="outline" className="w-full" onClick={() => setShowFeedback(true)}>
                  Submit Feedback
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="mx-auto mb-4 w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center">
                  <RefreshCw className="h-8 w-8 text-orange-600" />
                </div>
                <CardTitle className="text-center">Request Refund</CardTitle>
              </CardHeader>
              <CardContent className="text-center space-y-4">
                <p className="text-muted-foreground text-sm">
                  Submit refund requests for cancellations
                </p>
                <Button variant="outline" className="w-full" onClick={() => setShowRefund(true)}>
                  Request Refund
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Ship className="h-8 w-8 text-blue-400" />
                <span className="text-lg">Andaman Boat Booking</span>
              </div>
              <p className="text-gray-400 text-sm">
                Your trusted partner for seamless ferry bookings across the Andaman Islands.
              </p>
            </div>
            <div>
              <h4 className="mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="#" className="hover:text-white">About Us</a></li>
                <li><a href="#" className="hover:text-white">Our Fleet</a></li>
                <li><a href="#" className="hover:text-white">Safety Guidelines</a></li>
                <li><a href="#" className="hover:text-white">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="#" className="hover:text-white">Help Center</a></li>
                <li><a href="#" className="hover:text-white">Booking Policy</a></li>
                <li><a href="#" className="hover:text-white">Cancellation</a></li>
                <li><a href="#" className="hover:text-white">Refunds</a></li>
              </ul>
            </div>
            <div>
              <h4 className="mb-4">Contact Us</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>Email: info@andamanboats.com</li>
                <li>Phone: +91 XXXXX XXXXX</li>
                <li>24/7 Support Available</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
            <p>&copy; 2025 Andaman Boat Booking. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Feedback and Refund Modals */}
      {showFeedback && <FeedbackRefundPage type="feedback" onClose={() => setShowFeedback(false)} />}
      {showRefund && <FeedbackRefundPage type="refund" onClose={() => setShowRefund(false)} />}
    </div>
  );
}
