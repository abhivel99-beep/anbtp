import { useState, useEffect } from 'react';
import { Calendar, Users, CreditCard, CheckCircle, Ship, MapPin, QrCode, AlertCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Checkbox } from './ui/checkbox';
import { api } from '../utils/api';

// Fare Structure (as per exact requirements):
// Base Fare: ₹450
// Passenger Service Fee (PMB): ₹20
// Development Fee: ₹20
// GST @18% on Development Fee: ₹3.60
// Total: ₹493.60

const ROUTES = [
  { value: 'ross', label: 'Ross Island', displayFare: 470, baseFare: 450, cutoff: '14:00', advanceBooking: 3, agentCommission: 50 },
  { value: 'northbay', label: 'North Bay', displayFare: 693.60, baseFare: 650, cutoff: '14:00', advanceBooking: 3, agentCommission: 50 },
  { value: 'combined', label: 'Ross & North Bay', displayFare: 893.60, baseFare: 850, cutoff: '11:30', advanceBooking: 3, agentCommission: 100 },
];

const PMB_FEE = 20; // Passenger Service Fee (PMB)
const DEV_FEE = 20; // Development Fee
const GST_RATE = 0.18; // 18% GST on Development Fee
const GST_AMOUNT = DEV_FEE * GST_RATE; // ₹3.60

export function BookingFlow() {
  const [step, setStep] = useState(1);
  const [date, setDate] = useState('');
  const [route, setRoute] = useState('');
  const [passengers, setPassengers] = useState([{ name: '', age: '', gender: '', address: '', phone: '', email: '', idType: '', idNumber: '', isInfant: false }]);
  const [contactEmail, setContactEmail] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [schedules, setSchedules] = useState<any[]>([]);
  const [selectedSchedule, setSelectedSchedule] = useState('');
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [loading, setLoading] = useState(false);
  const [bookingResult, setBookingResult] = useState<any>(null);
  const [paymentMethod, setPaymentMethod] = useState('upi');

  useEffect(() => {
    // Set default date to today
    const today = new Date().toISOString().split('T')[0];
    setDate(today);
  }, []);

  // Generate time slots dynamically based on route
  const generateTimeSlots = () => {
    if (route === 'combined') {
      // Combined trips: 09:00-09:30, 09:30-10:00, 10:00-10:30, 10:30-11:00, 11:00-11:30
      return [
        '09:00-09:30',
        '09:30-10:00',
        '10:00-10:30',
        '10:30-11:00',
        '11:00-11:30',
      ];
    } else {
      // Individual trips: Extended slots till 14:00
      return [
        '09:00-09:30',
        '09:30-10:00',
        '10:00-10:30',
        '10:30-11:00',
        '11:00-11:30',
        '11:30-12:00',
        '12:00-12:30',
        '12:30-13:00',
        '13:00-13:30',
        '13:30-14:00',
      ];
    }
  };

  const addPassenger = () => {
    if (passengers.length < 10) {
      setPassengers([...passengers, { name: '', age: '', gender: '', address: '', phone: '', email: '', idType: '', idNumber: '', isInfant: false }]);
    }
  };

  const removePassenger = (index: number) => {
    if (passengers.length > 1) {
      setPassengers(passengers.filter((_, i) => i !== index));
    }
  };

  const updatePassenger = (index: number, field: string, value: any) => {
    const updated = [...passengers];
    updated[index] = { ...updated[index], [field]: value };
    setPassengers(updated);
  };

  const payingPassengers = passengers.filter(p => !p.isInfant);
  const selectedRoute = ROUTES.find(r => r.value === route);
  
  // Calculate fare breakdown per exact requirements
  const baseFare = selectedRoute ? payingPassengers.length * selectedRoute.baseFare : 0;
  const totalPMBFee = payingPassengers.length * PMB_FEE;
  const totalDevFee = payingPassengers.length * DEV_FEE;
  const totalGST = payingPassengers.length * GST_AMOUNT;
  const totalFare = baseFare + totalPMBFee + totalDevFee + totalGST;

  // Calculate min and max date based on route
  const getMinDate = () => {
    const now = new Date();
    const today = new Date().toISOString().split('T')[0];
    const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    
    if (!selectedRoute) return today;
    
    // For same day booking, check cutoff time
    if (selectedRoute.cutoff && currentTime >= selectedRoute.cutoff) {
      // Past cutoff, minimum is tomorrow
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      return tomorrow.toISOString().split('T')[0];
    }
    
    return today;
  };

  const getMaxDate = () => {
    const maxDays = selectedRoute?.advanceBooking || 3;
    const maxDate = new Date();
    maxDate.setDate(maxDate.getDate() + maxDays);
    return maxDate.toISOString().split('T')[0];
  };

  const canProceed = () => {
    if (step === 1) return date && route;
    // Step 2: All passengers need name, age, phone; non-infants need gender, idType, idNumber
    if (step === 2) return passengers.every(p => p.name && p.age && p.phone && (p.isInfant || (p.gender && p.idType && p.idNumber)));
    if (step === 3) return selectedSchedule;
    if (step === 4) return acceptedTerms && contactPhone; // Phone is mandatory, email is optional
    return false;
  };

  const handleSubmit = async () => {
    if (step === 5) {
      // Process payment
      setLoading(true);
      try {
        const transactionId = `${paymentMethod.toUpperCase()}_${Date.now()}`;
        const paymentResult = await api.processPayment(bookingResult.bookingId, paymentMethod, transactionId);
        if (paymentResult && paymentResult.booking) {
          setBookingResult({ ...bookingResult, ...paymentResult.booking });
          setStep(6);
        } else {
          console.error('Payment result missing booking data:', paymentResult);
          alert('Payment completed but confirmation failed. Please contact support with Booking ID: ' + bookingResult.bookingId);
        }
      } catch (error: any) {
        console.error('Payment failed:', error);
        alert('Payment processing failed: ' + (error.message || 'Please try again.'));
      } finally {
        setLoading(false);
      }
      return;
    }

    if (step === 4) {
      // Create booking
      setLoading(true);
      try {
        console.log('Creating booking with:', { selectedSchedule, route, date, passengers: passengers.length });
        const result = await api.createBooking(
          selectedSchedule, // This is the time slot now (e.g., "09:00-09:30")
          passengers, 
          contactEmail, 
          contactPhone, 
          route,
          selectedSchedule, // Pass time slot as departureTime
          date // Pass the selected date
        );
        console.log('Booking created successfully:', result);
        if (result && result.bookingId) {
          setBookingResult(result);
          setStep(5);
        } else {
          console.error('Booking result missing bookingId:', result);
          alert('Booking created but confirmation failed. Please contact support.');
        }
      } catch (error: any) {
        console.error('Booking failed:', error);
        alert('Booking failed: ' + (error.message || 'Please try again.'));
      } finally {
        setLoading(false);
      }
      return;
    }

    setStep(step + 1);
  };

  if (step === 6) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white py-12">
        <div className="max-w-3xl mx-auto px-4">
          <Card>
            <CardHeader className="text-center">
              <div className="mx-auto mb-4 w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                <CheckCircle className="h-10 w-10 text-green-600" />
              </div>
              <CardTitle>Booking Confirmed!</CardTitle>
              <CardDescription>Your tickets have been booked successfully</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* QR Code and Booking ID */}
              <div className="bg-blue-50 p-6 rounded-lg space-y-4">
                <div className="text-center">
                  <div className="inline-block bg-white p-4 rounded-lg shadow-sm mb-3">
                    <QrCode className="h-32 w-32 mx-auto text-blue-600" />
                    <p className="text-xs text-muted-foreground mt-2">Scan at Boarding</p>
                  </div>
                  <p className="text-sm text-muted-foreground">Booking ID</p>
                  <p className="text-3xl tracking-wider text-blue-600">{bookingResult.bookingId}</p>
                </div>
                <div className="grid grid-cols-2 gap-4 pt-4 border-t">
                  <div>
                    <p className="text-sm text-muted-foreground">Date</p>
                    <p>{bookingResult.booking?.date}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Departure</p>
                    <p>{selectedSchedule}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Route</p>
                    <p className="capitalize">{selectedRoute?.label}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Total Passengers</p>
                    <p>{passengers.length}</p>
                  </div>
                </div>
              </div>

              {/* Passenger Details */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="mb-3">Passenger List</h4>
                <div className="space-y-3">
                  {passengers.map((passenger, index) => (
                    <div key={index} className="bg-white p-3 rounded-lg border">
                      <p className="text-sm"><strong>{index + 1}. {passenger.name}</strong> {passenger.isInfant && <span className="text-green-600 text-xs">(Infant - Free)</span>}</p>
                      <div className="grid grid-cols-2 gap-2 mt-2 text-xs text-muted-foreground">
                        <div>Age: {passenger.age}</div>
                        {!passenger.isInfant && passenger.gender && <div>Gender: {passenger.gender}</div>}
                        {!passenger.isInfant && passenger.idType && <div>ID: {passenger.idType}</div>}
                        {!passenger.isInfant && passenger.idNumber && <div>ID Number: {passenger.idNumber}</div>}
                        {passenger.phone && <div className="col-span-2">Phone: {passenger.phone}</div>}
                        {passenger.email && <div className="col-span-2">Email: {passenger.email}</div>}
                        {passenger.address && <div className="col-span-2">Address: {passenger.address}</div>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Fare Breakdown */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="mb-3">Payment Summary</h4>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Base Fare ({payingPassengers.length} × ₹{selectedRoute?.baseFare})</span>
                    <span>₹{baseFare.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>PMB Fee ({payingPassengers.length} × ₹{PMB_FEE})</span>
                    <span>₹{totalPMBFee.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Development Fee ({payingPassengers.length} × ₹{DEV_FEE})</span>
                    <span>₹{totalDevFee.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>GST @18% ({payingPassengers.length} × ₹{GST_AMOUNT.toFixed(2)})</span>
                    <span>₹{totalGST.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t">
                    <strong>Total Amount Paid</strong>
                    <strong className="text-green-600 text-lg">₹{totalFare.toFixed(2)}</strong>
                  </div>
                  <p className="text-xs text-muted-foreground text-center pt-2">Payment Status: ✓ Confirmed</p>
                </div>
              </div>

              {/* Important Instructions */}
              <div className="bg-amber-50 p-4 rounded-lg space-y-3 border border-amber-200">
                <h4 className="text-amber-900 flex items-center gap-2">
                  <AlertCircle className="h-5 w-5" />
                  Important Instructions - Please Read
                </h4>
                <div className="space-y-2 text-sm text-amber-900">
                  <p><strong>✓ Arrive 30 Minutes Early:</strong> Report to the boarding point at least 30 minutes before your departure time ({selectedSchedule}).</p>
                  <p><strong>✓ Carry Valid ID:</strong> Original government-issued photo ID is mandatory for all passengers (Aadhaar, Passport, Driving License, Voter ID).</p>
                  <p><strong>✓ Show Booking ID:</strong> Present your Booking ID ({bookingResult.bookingId}) or scan the QR code at the boarding counter.</p>
                  <p><strong>✓ E-Ticket Sent:</strong> Confirmation email sent to {contactEmail} and SMS to {contactPhone}.</p>
                  <p><strong>✓ Boarding Point:</strong> Rajiv Gandhi Water Sports Complex, Port Blair.</p>
                  <p><strong>✓ Contact:</strong> For queries, call +91-3192-233444 or email support@andamanboats.com</p>
                  <p><strong>✓ Weather Advisory:</strong> Trips may be cancelled due to bad weather. You'll be notified via email/SMS.</p>
                  <p><strong>✓ No-Show Policy:</strong> If you miss your boat, no refund will be provided.</p>
                </div>
              </div>

              <div className="text-center space-y-2 text-sm text-muted-foreground">
                <p>Save this page or take a screenshot for reference</p>
                <p>Have a wonderful journey! 🌊 ⛵</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <Button variant="outline" onClick={() => window.print()}>
                  Print Ticket
                </Button>
                <Button onClick={() => window.location.reload()}>
                  Book Another Trip
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white py-8">
      <div className="max-w-4xl mx-auto px-4">
        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            {['Journey', 'Passengers', 'Schedule', 'Payment', 'Confirm'].map((label, i) => (
              <div key={i} className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  step > i + 1 ? 'bg-green-500 text-white' : step === i + 1 ? 'bg-blue-600 text-white' : 'bg-gray-200'
                }`}>
                  {step > i + 1 ? '✓' : i + 1}
                </div>
                <span className="ml-2 text-sm hidden sm:inline">{label}</span>
                {i < 4 && <div className={`w-12 h-1 mx-2 ${step > i + 1 ? 'bg-green-500' : 'bg-gray-200'}`} />}
              </div>
            ))}
          </div>
        </div>

        {/* Step 1: Journey Selection */}
        {step === 1 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                Select Your Journey
              </CardTitle>
              <CardDescription>Choose your travel date and destination</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label>Select Route</Label>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-2">
                  {ROUTES.map((r) => (
                    <div
                      key={r.value}
                      onClick={() => setRoute(r.value)}
                      className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                        route === r.value ? 'border-blue-600 bg-blue-50' : 'border-gray-200 hover:border-blue-300'
                      }`}
                    >
                      <Ship className="h-6 w-6 mb-2 text-blue-600" />
                      <h4>{r.label}</h4>
                      <p className="text-2xl text-blue-600 mt-2">₹{r.displayFare}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <Label htmlFor="date">Travel Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  min={getMinDate()}
                  max={getMaxDate()}
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Book up to 3 days in advance
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step 2: Passenger Details */}
        {step === 2 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Passenger Details
              </CardTitle>
              <CardDescription>Add up to 10 paying passengers + infants</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {passengers.map((p, i) => (
                <div key={i} className="p-4 border rounded-lg space-y-4">
                  <div className="flex justify-between items-center">
                    <h4>Passenger {i + 1}</h4>
                    {passengers.length > 1 && (
                      <Button variant="destructive" size="sm" onClick={() => removePassenger(i)}>
                        Remove
                      </Button>
                    )}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Full Name *</Label>
                      <Input
                        value={p.name}
                        onChange={(e) => updatePassenger(i, 'name', e.target.value)}
                        placeholder="As per ID"
                      />
                    </div>
                    <div>
                      <Label>Age *</Label>
                      <Input
                        type="number"
                        value={p.age}
                        onChange={(e) => updatePassenger(i, 'age', e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Checkbox
                      checked={p.isInfant}
                      onCheckedChange={(checked) => updatePassenger(i, 'isInfant', checked)}
                    />
                    <label className="text-sm">Infant (under 2 years, free)</label>
                  </div>

                  {!p.isInfant && (
                    <>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label>Gender *</Label>
                          <Select value={p.gender} onValueChange={(v) => updatePassenger(i, 'gender', v)}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="male">Male</SelectItem>
                              <SelectItem value="female">Female</SelectItem>
                              <SelectItem value="other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label>ID Type *</Label>
                          <Select value={p.idType} onValueChange={(v) => updatePassenger(i, 'idType', v)}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="aadhar">Aadhar Card</SelectItem>
                              <SelectItem value="passport">Passport</SelectItem>
                              <SelectItem value="islander">Islander ID</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div>
                        <Label>ID Number *</Label>
                        <Input
                          value={p.idNumber}
                          onChange={(e) => updatePassenger(i, 'idNumber', e.target.value)}
                        />
                      </div>
                    </>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Phone Number *</Label>
                      <div className="flex gap-2">
                        <Input
                          value={p.phone}
                          onChange={(e) => updatePassenger(i, 'phone', e.target.value)}
                          placeholder="Contact number"
                          required
                        />
                        {i > 0 && passengers[0].phone && (
                          <Button 
                            type="button" 
                            variant="outline" 
                            size="sm"
                            onClick={() => updatePassenger(i, 'phone', passengers[0].phone)}
                          >
                            Same
                          </Button>
                        )}
                      </div>
                    </div>
                    <div>
                      <Label>Email (Optional)</Label>
                      <div className="flex gap-2">
                        <Input
                          type="email"
                          value={p.email}
                          onChange={(e) => updatePassenger(i, 'email', e.target.value)}
                          placeholder="Email address"
                        />
                        {i > 0 && passengers[0].email && (
                          <Button 
                            type="button" 
                            variant="outline" 
                            size="sm"
                            onClick={() => updatePassenger(i, 'email', passengers[0].email)}
                          >
                            Same
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>

                  <div>
                    <Label>Address (Optional)</Label>
                    <div className="flex gap-2">
                      <Input
                        value={p.address}
                        onChange={(e) => updatePassenger(i, 'address', e.target.value)}
                        placeholder="Full address"
                      />
                      {i > 0 && passengers[0].address && (
                        <Button 
                          type="button" 
                          variant="outline" 
                          size="sm"
                          onClick={() => updatePassenger(i, 'address', passengers[0].address)}
                        >
                          Same
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}

              {passengers.length < 10 && (
                <Button variant="outline" onClick={addPassenger} className="w-full">
                  + Add Another Passenger
                </Button>
              )}
            </CardContent>
          </Card>
        )}

        {/* Step 3: Departure Time Selection */}
        {step === 3 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Select Departure Time
              </CardTitle>
              <CardDescription>Choose your preferred departure time slot</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-blue-50 p-3 rounded-lg mb-4">
                <p className="text-sm text-blue-800">
                  <strong>Route:</strong> {selectedRoute?.label} — Available time slots:
                </p>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {generateTimeSlots().map((timeSlot) => (
                  <div
                    key={timeSlot}
                    onClick={() => setSelectedSchedule(timeSlot)}
                    className={`p-4 border-2 rounded-lg cursor-pointer transition-all text-center ${
                      selectedSchedule === timeSlot ? 'border-blue-600 bg-blue-50' : 'border-gray-200 hover:border-blue-300'
                    }`}
                  >
                    <div className="text-lg">{timeSlot}</div>
                    <div className="text-xs text-muted-foreground mt-1">Available</div>
                  </div>
                ))}
              </div>
              <div className="bg-blue-50 p-4 rounded-lg mt-4">
                <p className="text-sm text-blue-800">
                  <strong>Important:</strong> Please arrive at the boarding point at least 30 minutes before your selected departure time.
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step 4: Contact & Terms */}
        {step === 4 && (
          <Card>
            <CardHeader>
              <CardTitle>Contact Information</CardTitle>
              <CardDescription>We'll send your e-ticket here</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Phone Number *</Label>
                  <Input
                    value={contactPhone}
                    onChange={(e) => setContactPhone(e.target.value)}
                    placeholder="+91 XXXXX XXXXX"
                    required
                  />
                  <p className="text-xs text-muted-foreground mt-1">Required for booking confirmation</p>
                </div>
                <div>
                  <Label>Email (Optional)</Label>
                  <Input
                    type="email"
                    value={contactEmail}
                    onChange={(e) => setContactEmail(e.target.value)}
                    placeholder="your@email.com"
                  />
                  <p className="text-xs text-muted-foreground mt-1">For e-ticket delivery</p>
                </div>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg space-y-2">
                <h4>Fare Summary</h4>
                <div className="flex justify-between text-sm">
                  <span>Base Fare ({payingPassengers.length} × ₹{selectedRoute?.baseFare})</span>
                  <span>₹{baseFare.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Passenger Service Fee (PMB) ({payingPassengers.length} × ₹{PMB_FEE})</span>
                  <span>₹{totalPMBFee.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Development Fee ({payingPassengers.length} × ₹{DEV_FEE})</span>
                  <span>₹{totalDevFee.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>GST @18% on Development Fee ({payingPassengers.length} × ₹{GST_AMOUNT.toFixed(2)})</span>
                  <span>₹{totalGST.toFixed(2)}</span>
                </div>
                <div className="flex justify-between pt-2 border-t">
                  <span>Grand Total</span>
                  <span className="text-lg">₹{totalFare.toFixed(2)}</span>
                </div>
                <div className="bg-blue-50 p-3 rounded mt-3 text-xs text-blue-800">
                  <strong>Organization:</strong> Water Sports Tourist Fiber Boat Owners Association<br />
                  <strong>GSTIN:</strong> 35XXXXX1234Z1A<br />
                  <strong>Reg. no.:</strong> AN/123/2023 (Under Societies Registration Act, 1860)
                </div>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg space-y-3">
                <h4 className="text-blue-900">Important Terms & Conditions</h4>
                <div className="space-y-2 text-sm text-blue-800">
                  <p><strong>⏰ Arrival Time:</strong> Passengers must arrive at the boarding point at least 30 minutes before the selected departure time slot.</p>
                  <p><strong>🆔 ID Proof:</strong> Valid government-issued photo ID is mandatory for all passengers. Please carry original documents.</p>
                  <p><strong>💰 Refund Policy:</strong></p>
                  <ul className="list-disc list-inside ml-4 space-y-1">
                    <li>Cancellation 24+ hours before departure: 90% refund</li>
                    <li>Cancellation 12-24 hours before: 50% refund</li>
                    <li>Cancellation less than 12 hours: No refund</li>
                    <li>No-shows: No refund</li>
                  </ul>
                  <p><strong>👶 Infants:</strong> Children under 2 years travel free (no separate seat).</p>
                  <p><strong>🌊 Weather:</strong> Trips may be cancelled due to adverse weather. Full refund provided in such cases.</p>
                  <p><strong>📱 E-Ticket:</strong> Carry your booking confirmation (email or SMS) and Booking ID to the boarding point.</p>
                </div>
              </div>

              <div className="flex items-start gap-2">
                <Checkbox
                  checked={acceptedTerms}
                  onCheckedChange={(checked) => setAcceptedTerms(!!checked)}
                />
                <label className="text-sm">
                  I have read and accept the above terms & conditions, cancellation policy, and refund policy. I understand that I must carry valid ID proof and arrive 30 minutes before departure.
                </label>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step 5: Payment */}
        {step === 5 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                Complete Payment
              </CardTitle>
              <CardDescription>Choose your preferred payment method</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="text-sm text-muted-foreground">Amount to Pay</p>
                <p className="text-3xl">₹{totalFare.toFixed(2)}</p>
                <p className="text-xs text-muted-foreground mt-2">
                  Base: ₹{baseFare.toFixed(2)} + PMB: ₹{totalPMBFee.toFixed(2)} + Dev: ₹{totalDevFee.toFixed(2)} + GST: ₹{totalGST.toFixed(2)}
                </p>
              </div>

              <div className="space-y-4">
                <Label>Select Payment Method</Label>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div
                    onClick={() => setPaymentMethod('upi')}
                    className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                      paymentMethod === 'upi' ? 'border-blue-600 bg-blue-50' : 'border-gray-200 hover:border-blue-300'
                    }`}
                  >
                    <div className="text-center">
                      <div className="text-2xl mb-2">📱</div>
                      <h4>UPI</h4>
                      <p className="text-xs text-muted-foreground mt-1">GPay, PhonePe, Paytm</p>
                    </div>
                  </div>

                  <div
                    onClick={() => setPaymentMethod('card')}
                    className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                      paymentMethod === 'card' ? 'border-blue-600 bg-blue-50' : 'border-gray-200 hover:border-blue-300'
                    }`}
                  >
                    <div className="text-center">
                      <div className="text-2xl mb-2">💳</div>
                      <h4>Card</h4>
                      <p className="text-xs text-muted-foreground mt-1">Credit/Debit Card</p>
                    </div>
                  </div>

                  <div
                    onClick={() => setPaymentMethod('netbanking')}
                    className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                      paymentMethod === 'netbanking' ? 'border-blue-600 bg-blue-50' : 'border-gray-200 hover:border-blue-300'
                    }`}
                  >
                    <div className="text-center">
                      <div className="text-2xl mb-2">🏦</div>
                      <h4>Net Banking</h4>
                      <p className="text-xs text-muted-foreground mt-1">All Major Banks</p>
                    </div>
                  </div>
                </div>
              </div>

              {paymentMethod === 'upi' && (
                <div className="bg-gray-50 p-4 rounded-lg space-y-3">
                  <Label>Enter UPI ID</Label>
                  <Input placeholder="yourname@upi" />
                  <p className="text-xs text-muted-foreground">
                    Enter your UPI ID to receive payment request
                  </p>
                </div>
              )}

              {paymentMethod === 'card' && (
                <div className="bg-gray-50 p-4 rounded-lg space-y-3">
                  <div>
                    <Label>Card Number</Label>
                    <Input placeholder="1234 5678 9012 3456" maxLength={19} />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Expiry Date</Label>
                      <Input placeholder="MM/YY" maxLength={5} />
                    </div>
                    <div>
                      <Label>CVV</Label>
                      <Input placeholder="123" maxLength={3} type="password" />
                    </div>
                  </div>
                  <div>
                    <Label>Cardholder Name</Label>
                    <Input placeholder="Name on card" />
                  </div>
                </div>
              )}

              {paymentMethod === 'netbanking' && (
                <div className="bg-gray-50 p-4 rounded-lg space-y-3">
                  <Label>Select Your Bank</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose your bank" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sbi">State Bank of India</SelectItem>
                      <SelectItem value="hdfc">HDFC Bank</SelectItem>
                      <SelectItem value="icici">ICICI Bank</SelectItem>
                      <SelectItem value="axis">Axis Bank</SelectItem>
                      <SelectItem value="pnb">Punjab National Bank</SelectItem>
                      <SelectItem value="other">Other Banks</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    You will be redirected to your bank's secure payment page
                  </p>
                </div>
              )}

              <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg">
                <p className="text-sm">
                  <strong>🔒 Demo Mode:</strong> This is a mock payment gateway for demonstration. In production, this will integrate with secure payment providers like Razorpay or Stripe.
                </p>
              </div>

              <div className="bg-green-50 p-4 rounded-lg">
                <p className="text-sm text-green-800">
                  <strong>✓ 100% Secure:</strong> Your payment information is encrypted and secured using industry-standard SSL technology.
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Navigation */}
        <div className="flex justify-between mt-6">
          {step > 1 && step < 6 && (
            <Button variant="outline" onClick={() => setStep(step - 1)}>
              Back
            </Button>
          )}
          {step < 5 && (
            <Button onClick={handleSubmit} disabled={!canProceed()} className="ml-auto">
              Continue
            </Button>
          )}
          {step === 5 && (
            <Button onClick={handleSubmit} disabled={loading} className="ml-auto">
              {loading ? 'Processing...' : 'Process Payment'}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
