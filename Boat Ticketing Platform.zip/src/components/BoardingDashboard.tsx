import { useState, useEffect } from 'react';
import { QrCode, UserCheck, Printer, Search, Calendar, Ship, CheckCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { api } from '../utils/api';

export function BoardingDashboard() {
  const [boats, setBoats] = useState<any[]>([]);
  const [selectedBoat, setSelectedBoat] = useState<string>('');
  const [bookings, setBookings] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [boardingPassData, setBoardingPassData] = useState<any>(null);
  
  // Verification state
  const [qrInput, setQrInput] = useState('');
  const [verifiedBooking, setVerifiedBooking] = useState<any>(null);

  useEffect(() => {
    loadData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedDate]);

  const loadData = async () => {
    setLoading(true);
    try {
      const boatsData = await api.getBoats();
      setBoats(boatsData.boats.filter((b: any) => b.status === 'active' || b.status === 'approved' || !b.status));
    } catch (error) {
      console.error('Failed to load data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLoadBookings = async () => {
    setLoading(true);
    try {
      const { bookings: data } = await api.searchBookings({
        date: selectedDate,
      });
      
      // Filter confirmed bookings only
      const confirmedBookings = data.filter((b: any) => 
        b.status === 'confirmed' || b.status === 'paid'
      );
      
      setBookings(confirmedBookings);
      
      // Also reload boats to get updated capacity
      const boatsData = await api.getBoats();
      setBoats(boatsData.boats.filter((b: any) => b.status === 'active' || b.status === 'approved' || !b.status));
      
      alert(`Loaded ${confirmedBookings.length} bookings for ${selectedDate}`);
    } catch (error) {
      console.error('Failed to load bookings:', error);
      alert('Failed to load bookings');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyPassenger = async () => {
    if (!qrInput) {
      alert('Please enter Booking ID or scan QR code');
      return;
    }

    setLoading(true);
    try {
      // Search for booking by ID (with or without BOOKING- prefix)
      const searchId = qrInput.replace('BOOKING-', '');
      
      // Try to find in loaded bookings first
      let booking = bookings.find(b => 
        b.id === searchId || 
        b.id === qrInput || 
        `BOOKING-${b.id}` === qrInput
      );
      
      // If not found in loaded bookings, search directly
      if (!booking) {
        const { bookings: searchResults } = await api.searchBookings({ bookingId: searchId });
        if (searchResults && searchResults.length > 0) {
          booking = searchResults[0];
        }
      }
      
      if (booking) {
        setVerifiedBooking(booking);
        alert('✓ Passenger verified successfully!');
      } else {
        alert('❌ Booking not found or invalid. Please check the Booking ID.');
        setVerifiedBooking(null);
      }
    } catch (error) {
      console.error('Failed to verify passenger:', error);
      alert('❌ Verification failed. Please try again.');
      setVerifiedBooking(null);
    } finally {
      setLoading(false);
    }
  };

  const handleAllotBoat = async () => {
    if (!verifiedBooking) {
      alert('Please verify a passenger first');
      return;
    }

    if (!selectedBoat) {
      alert('Please select a boat first');
      return;
    }

    setLoading(true);
    try {
      await api.assignBoat(verifiedBooking.id, selectedBoat);
      alert('Boat allotted successfully! Boarding complete.');
      
      // Generate boarding pass
      handleGenerateBoardingPass(verifiedBooking);
      
      // Reset verification
      setQrInput('');
      setVerifiedBooking(null);
      handleLoadBookings(); // Reload bookings
    } catch (error) {
      console.error('Failed to allot boat:', error);
      alert('Failed to allot boat');
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateBoardingPass = (booking: any) => {
    const boat = boats.find(b => b.id === selectedBoat || b.id === booking.assignedBoat);
    
    setBoardingPassData({
      bookingId: booking.id,
      passengerName: booking.passengers?.[0]?.name || '-',
      age: booking.passengers?.[0]?.age || '-',
      contact: booking.contactPhone,
      boatName: boat?.name || 'Not Assigned',
      departureTime: booking.departureTime || '-',
      islands: booking.route === 'ross' ? 'Ross Island' : 
               booking.route === 'northbay' ? 'North Bay' : 
               'Ross Island & North Bay',
      date: booking.date,
      totalPassengers: booking.totalPassengers,
      qrCode: `BOOKING-${booking.id}`,
      passengers: booking.passengers || [],
    });
  };

  const handlePrintBoardingPass = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1>Boarding Team Dashboard</h1>
          <p className="text-muted-foreground">Verify passengers, allot boats, and issue boarding passes</p>
        </div>

        {/* Date Selection */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Date Selection
            </CardTitle>
            <CardDescription>
              Select date to view bookings
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="date">Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                />
              </div>
              <div className="flex items-end">
                <Button onClick={handleLoadBookings} className="w-full">
                  <Search className="h-4 w-4 mr-2" />
                  Load Bookings
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Workflow: Verify Passenger */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UserCheck className="h-5 w-5" />
              Step 1: Verify Passenger
            </CardTitle>
            <CardDescription>
              Enter Booking ID or scan QR code to verify passenger
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="md:col-span-2">
                <Label htmlFor="qr">Booking ID / QR Code</Label>
                <Input
                  id="qr"
                  value={qrInput}
                  onChange={(e) => setQrInput(e.target.value)}
                  placeholder="Enter booking ID or scan QR"
                  onKeyPress={(e) => e.key === 'Enter' && handleVerifyPassenger()}
                />
              </div>
              <div className="flex items-end">
                <Button onClick={handleVerifyPassenger} className="w-full">
                  <QrCode className="h-4 w-4 mr-2" />
                  Verify
                </Button>
              </div>
            </div>

            {verifiedBooking && (
              <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-center gap-2 mb-3">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <h4 className="text-green-800">Passenger Verified</h4>
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">Booking ID</p>
                    <p>{verifiedBooking.id}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Passenger Name</p>
                    <p>{verifiedBooking.passengers?.[0]?.name || '-'}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Total Passengers</p>
                    <p>{verifiedBooking.totalPassengers}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Route</p>
                    <p className="capitalize">{verifiedBooking.route}</p>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Workflow: Allot Boat */}
        {verifiedBooking && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Ship className="h-5 w-5" />
                Step 2: Allot Boat & Complete Boarding
              </CardTitle>
              <CardDescription>
                Select boat based on today's schedule (Vacant seats shown)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <Label htmlFor="boat">Select Boat</Label>
                  <Select value={selectedBoat} onValueChange={setSelectedBoat}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select boat from schedule" />
                    </SelectTrigger>
                    <SelectContent>
                      {boats.map(boat => {
                        // Calculate booked seats for this boat
                        const bookedSeats = bookings
                          .filter(b => b.assignedBoat === boat.id)
                          .reduce((sum, b) => sum + (b.totalPassengers || 0), 0);
                        const vacantSeats = boat.capacity - bookedSeats;
                        const canBook = vacantSeats >= (verifiedBooking.totalPassengers || 0);
                        
                        return (
                          <SelectItem 
                            key={boat.id} 
                            value={boat.id}
                            disabled={!canBook}
                          >
                            {boat.name} - {vacantSeats} vacant ({boat.capacity} total)
                            {!canBook && ' - FULL'}
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-end">
                  <Button onClick={handleAllotBoat} className="w-full" disabled={loading}>
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Complete Boarding
                  </Button>
                </div>
              </div>
              
              {selectedBoat && (() => {
                const boat = boats.find(b => b.id === selectedBoat);
                if (!boat) return null;
                const bookedSeats = bookings
                  .filter(b => b.assignedBoat === boat.id)
                  .reduce((sum, b) => sum + (b.totalPassengers || 0), 0);
                const vacantSeats = boat.capacity - bookedSeats;
                
                return (
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <p className="text-sm">
                      <strong>Selected Boat Capacity:</strong><br />
                      Total: {boat.capacity} | Booked: {bookedSeats} | <span className="text-green-600">Vacant: {vacantSeats}</span>
                    </p>
                    <p className="text-sm mt-2">
                      This booking has {verifiedBooking.totalPassengers} passenger(s)
                    </p>
                  </div>
                );
              })()}
            </CardContent>
          </Card>
        )}

        {/* All Passengers List for Reference */}
        <Card>
          <CardHeader>
            <CardTitle>All Passengers for Selected Date</CardTitle>
            <CardDescription>
              Complete passenger list with all details from each booking
            </CardDescription>
          </CardHeader>
          <CardContent>
            {bookings.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <Ship className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <p>No bookings found for selected date</p>
                <p className="text-sm mt-2">Select a date to view passenger list</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs">#</th>
                      <th className="px-4 py-3 text-left text-xs">Booking ID</th>
                      <th className="px-4 py-3 text-left text-xs">Passenger Name</th>
                      <th className="px-4 py-3 text-left text-xs">Age</th>
                      <th className="px-4 py-3 text-left text-xs">Phone</th>
                      <th className="px-4 py-3 text-left text-xs">ID Type</th>
                      <th className="px-4 py-3 text-left text-xs">Route</th>
                      <th className="px-4 py-3 text-left text-xs">Boat Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {bookings.flatMap((booking, bookingIdx) => {
                      const boatInfo = booking.assignedBoat 
                        ? boats.find(b => b.id === booking.assignedBoat)?.name || 'Assigned'
                        : 'Pending';
                      
                      return (booking.passengers || []).map((passenger: any, passengerIdx: number) => (
                        <tr key={`${booking.id}-${passengerIdx}`}>
                          <td className="px-4 py-3 text-sm">{bookingIdx + 1}.{passengerIdx + 1}</td>
                          <td className="px-4 py-3 text-sm text-blue-600">{booking.id}</td>
                          <td className="px-4 py-3 text-sm">
                            {passenger.name || '-'}
                            {passenger.isInfant && <span className="ml-2 text-xs text-green-600">(Infant)</span>}
                          </td>
                          <td className="px-4 py-3 text-sm">{passenger.age || '-'}</td>
                          <td className="px-4 py-3 text-sm">{passenger.phone || booking.contactPhone}</td>
                          <td className="px-4 py-3 text-sm">{passenger.isInfant ? '-' : (passenger.idType || '-')}</td>
                          <td className="px-4 py-3 text-sm capitalize">{booking.route}</td>
                          <td className="px-4 py-3 text-sm">
                            {booking.assignedBoat ? (
                              <span className="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs">
                                {boatInfo}
                              </span>
                            ) : (
                              <span className="px-2 py-1 bg-yellow-100 text-yellow-700 rounded-full text-xs">
                                Pending
                              </span>
                            )}
                          </td>
                        </tr>
                      ));
                    })}
                  </tbody>
                </table>
                {bookings.length > 0 && (
                  <div className="mt-4 text-sm text-muted-foreground text-center">
                    Total: {bookings.flatMap(b => b.passengers || []).length} passenger(s) from {bookings.length} booking(s)
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Boarding Pass Preview/Print */}
        {boardingPassData && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <Card className="w-full max-w-3xl bg-white max-h-[90vh] overflow-y-auto">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Boarding Pass</CardTitle>
                  <div className="flex gap-2">
                    <Button onClick={handlePrintBoardingPass}>
                      <Printer className="h-4 w-4 mr-2" />
                      Print
                    </Button>
                    <Button variant="outline" onClick={() => setBoardingPassData(null)}>
                      Close
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 print:border-solid print:border-gray-800">
                  {/* Boarding Pass Content */}
                  <div className="text-center mb-6">
                    <h2 className="text-2xl mb-2">Andaman Boat Booking</h2>
                    <p className="text-sm text-muted-foreground">Boarding Pass</p>
                  </div>

                  <div className="grid grid-cols-2 gap-6 mb-6">
                    <div>
                      <h4 className="mb-4">Trip Details</h4>
                      <div className="space-y-3 text-sm">
                        <div>
                          <p className="text-muted-foreground">Booking ID</p>
                          <p className="text-lg">{boardingPassData.bookingId}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Boat Name</p>
                          <p>{boardingPassData.boatName}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Date of Travel</p>
                          <p>{boardingPassData.date}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Island(s) of Visit</p>
                          <p>{boardingPassData.islands}</p>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="mb-4">Passenger Information</h4>
                      <div className="space-y-3 text-sm">
                        <div>
                          <p className="text-muted-foreground">Lead Passenger</p>
                          <p>{boardingPassData.passengerName}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Total Passengers</p>
                          <p>{boardingPassData.totalPassengers}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Contact</p>
                          <p>{boardingPassData.contact}</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* All Passengers Table */}
                  <div className="border-t pt-6 mb-6">
                    <h4 className="mb-3">All Passengers</h4>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-3 py-2 text-left">#</th>
                            <th className="px-3 py-2 text-left">Name</th>
                            <th className="px-3 py-2 text-left">Age</th>
                            <th className="px-3 py-2 text-left">ID Type</th>
                            <th className="px-3 py-2 text-left">ID Number</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y">
                          {boardingPassData.passengers.map((passenger: any, idx: number) => (
                            <tr key={idx}>
                              <td className="px-3 py-2">{idx + 1}</td>
                              <td className="px-3 py-2">
                                {passenger.name}
                                {passenger.isInfant && <span className="ml-2 text-xs text-green-600">(Infant)</span>}
                              </td>
                              <td className="px-3 py-2">{passenger.age}</td>
                              <td className="px-3 py-2">{passenger.isInfant ? '-' : (passenger.idType || '-')}</td>
                              <td className="px-3 py-2">{passenger.isInfant ? '-' : (passenger.idNumber || '-')}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* QR Code */}
                  <div className="border-t pt-6 text-center">
                    <div className="inline-block p-4 bg-white border-2 border-gray-800">
                      <QrCode className="h-32 w-32 mx-auto" />
                      <p className="text-xs mt-2 text-muted-foreground">{boardingPassData.qrCode}</p>
                    </div>
                    <p className="text-xs text-muted-foreground mt-4">
                      Please present this boarding pass at the boarding gate
                    </p>
                  </div>

                  <div className="mt-6 text-center text-xs text-muted-foreground border-t pt-4">
                    <p>Andaman Boat Booking • Sri Vijayapuram Port</p>
                    <p className="mt-1">For assistance: +91 XXXXX XXXXX</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
