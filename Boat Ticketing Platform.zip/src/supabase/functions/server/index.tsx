import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';
import { nanoid } from 'npm:nanoid';

const app = new Hono();

app.use('*', cors());
app.use('*', logger(console.log));

// Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

// Helper function to verify user token
async function verifyToken(authHeader: string | null) {
  if (!authHeader) return null;
  const token = authHeader.split(' ')[1];
  const { data: { user }, error } = await supabase.auth.getUser(token);
  if (error || !user) return null;
  return user;
}

// ==================== AUTHENTICATION ====================

// Sign up (for dashboard users: Admin, Operator, Agent, Boarding, T-Shirt)
app.post('/make-server-d9983cbe/auth/signup', async (c) => {
  try {
    const { email, password, name, role } = await c.req.json();
    
    // Check if user already exists
    const { data: existingUsers } = await supabase.auth.admin.listUsers();
    const existingUser = existingUsers?.users?.find(u => u.email === email);
    
    if (existingUser) {
      console.log(`User ${email} already exists with ID: ${existingUser.id}`);
      
      // Check if profile exists, if not create it
      let profile = await kv.get(`user:${existingUser.id}`);
      if (!profile) {
        profile = {
          id: existingUser.id,
          email,
          name,
          role,
          status: 'approved', // Auto-approve existing users
          createdAt: new Date().toISOString()
        };
        await kv.set(`user:${existingUser.id}`, profile);
        console.log(`Created missing profile for existing user ${email}`);
      } else if (!profile.status) {
        // Add status to existing profiles that don't have it
        profile.status = 'approved';
        await kv.set(`user:${existingUser.id}`, profile);
        console.log(`Updated status for existing user ${email}`);
      }
      
      // Return success with existing user
      return c.json({ success: true, user: existingUser, message: 'User already exists' });
    }
    
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: true, // Auto-confirm since email server not configured
      user_metadata: { name, role }
    });
    
    if (error) {
      console.log(`Signup error for ${email}: ${error.message}`);
      return c.json({ error: error.message }, 400);
    }
    
    // Store user profile
    await kv.set(`user:${data.user.id}`, {
      id: data.user.id,
      email,
      name,
      role,
      status: 'approved', // All signups through this endpoint are auto-approved (demo accounts)
      createdAt: new Date().toISOString()
    });
    
    console.log(`Successfully created user ${email} with role ${role}`);
    return c.json({ success: true, user: data.user });
  } catch (error) {
    console.log(`Signup exception: ${error.message}`);
    return c.json({ error: 'Signup failed' }, 500);
  }
});

// Public Registration (for Tourist, Operator, Agent with approval flow)
app.post('/make-server-d9983cbe/auth/register', async (c) => {
  try {
    const registrationData = await c.req.json();
    const { email, password, name, role, status = 'pending' } = registrationData;
    
    // Check if user already exists
    const { data: existingUsers } = await supabase.auth.admin.listUsers();
    const existingUser = existingUsers?.users?.find(u => u.email === email);
    
    if (existingUser) {
      console.log(`Registration: User ${email} already exists`);
      return c.json({ error: 'Email already registered' }, 400);
    }
    
    // Create user account
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { name, role }
    });
    
    if (error) {
      console.log(`Registration error for ${email}: ${error.message}`);
      return c.json({ error: error.message }, 400);
    }
    
    // Store comprehensive user profile
    const profile = {
      id: data.user.id,
      email,
      name,
      role,
      status: status, // 'pending' for operator/agent, 'approved' for tourist
      phone: registrationData.phone || '',
      address: registrationData.address || '',
      createdAt: new Date().toISOString(),
      
      // Operator specific fields
      ...(role === 'operator' && {
        companyName: registrationData.companyName || '',
        registrationNumber: registrationData.registrationNumber || '',
        boatDetails: registrationData.boatDetails || '',
        numberOfBoats: registrationData.numberOfBoats || '',
      }),
      
      // Agent specific fields
      ...(role === 'agent' && {
        agencyName: registrationData.agencyName || '',
        agencyLicense: registrationData.agencyLicense || '',
        experience: registrationData.experience || '',
      }),
    };
    
    await kv.set(`user:${data.user.id}`, profile);
    
    console.log(`Successfully registered ${email} with role ${role} and status ${status}`);
    return c.json({ 
      success: true, 
      user: data.user,
      status: status,
      message: status === 'pending' 
        ? 'Registration submitted. Awaiting admin approval.' 
        : 'Registration successful!'
    });
  } catch (error) {
    console.log(`Registration exception: ${error.message}`);
    return c.json({ error: 'Registration failed' }, 500);
  }
});

// Get pending registrations (Admin only)
app.get('/make-server-d9983cbe/auth/registrations/pending', async (c) => {
  try {
    const user = await verifyToken(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const profile = await kv.get(`user:${user.id}`);
    if (!profile || profile.role !== 'admin') {
      return c.json({ error: 'Forbidden - Admin only' }, 403);
    }
    
    const allUsers = await kv.getByPrefix('user:');
    const pending = allUsers.filter(u => u.status === 'pending');
    
    return c.json({ registrations: pending });
  } catch (error) {
    console.log(`Get pending registrations error: ${error.message}`);
    return c.json({ error: 'Failed to get pending registrations' }, 500);
  }
});

// Approve/Reject registration (Admin only)
app.post('/make-server-d9983cbe/auth/registrations/:userId/approve', async (c) => {
  try {
    const user = await verifyToken(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const profile = await kv.get(`user:${user.id}`);
    if (!profile || profile.role !== 'admin') {
      return c.json({ error: 'Forbidden - Admin only' }, 403);
    }
    
    const userId = c.req.param('userId');
    const { approved, comments } = await c.req.json();
    
    const userProfile = await kv.get(`user:${userId}`);
    if (!userProfile) {
      return c.json({ error: 'User not found' }, 404);
    }
    
    userProfile.status = approved ? 'approved' : 'rejected';
    userProfile.adminComments = comments || '';
    userProfile.reviewedAt = new Date().toISOString();
    userProfile.reviewedBy = user.id;
    
    await kv.set(`user:${userId}`, userProfile);
    
    console.log(`Admin ${user.email} ${approved ? 'approved' : 'rejected'} registration for ${userProfile.email}`);
    return c.json({ success: true, message: `Registration ${approved ? 'approved' : 'rejected'}` });
  } catch (error) {
    console.log(`Approve registration error: ${error.message}`);
    return c.json({ error: 'Failed to process approval' }, 500);
  }
});

// Sign in
app.post('/make-server-d9983cbe/auth/signin', async (c) => {
  try {
    const { email, password } = await c.req.json();
    
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });
    
    if (error) {
      console.log(`Signin error: ${error.message}`);
      return c.json({ error: 'Invalid credentials' }, 401);
    }
    
    // Get user profile
    let profile = await kv.get(`user:${data.user.id}`);
    
    // If no profile exists, create a default one
    if (!profile) {
      console.log(`No profile found for ${email}, creating default profile`);
      profile = {
        id: data.user.id,
        email: data.user.email,
        name: data.user.user_metadata?.name || 'User',
        role: data.user.user_metadata?.role || 'tourist',
        status: 'approved',
        createdAt: new Date().toISOString()
      };
      await kv.set(`user:${data.user.id}`, profile);
    }
    
    // Check if account is approved (for operator/agent)
    if (profile && profile.status === 'pending') {
      console.log(`Signin blocked: ${email} account pending approval`);
      return c.json({ 
        error: 'Your account is awaiting admin approval. Please check back later.' 
      }, 403);
    }
    
    if (profile && profile.status === 'rejected') {
      console.log(`Signin blocked: ${email} account was rejected`);
      return c.json({ 
        error: 'Your account registration was not approved. Please contact support.' 
      }, 403);
    }
    
    console.log(`Successful signin: ${email} with role ${profile?.role}`);
    return c.json({
      success: true,
      session: data.session,
      profile
    });
  } catch (error) {
    console.log(`Signin exception: ${error.message}`);
    return c.json({ error: 'Signin failed' }, 500);
  }
});

// Get current user
app.get('/make-server-d9983cbe/auth/me', async (c) => {
  try {
    const user = await verifyToken(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    let profile = await kv.get(`user:${user.id}`);
    
    // If no profile exists, create a default one
    if (!profile) {
      console.log(`No profile found for user ${user.id}, creating default profile`);
      profile = {
        id: user.id,
        email: user.email,
        name: user.user_metadata?.name || 'User',
        role: user.user_metadata?.role || 'tourist',
        status: 'approved',
        createdAt: new Date().toISOString()
      };
      await kv.set(`user:${user.id}`, profile);
    }
    
    return c.json({ profile });
  } catch (error) {
    console.log(`Get me error: ${error.message}`);
    return c.json({ error: 'Failed to get user' }, 500);
  }
});

// Get current user
app.get('/make-server-d9983cbe/auth/me', async (c) => {
  try {
    const user = await verifyToken(c.req.header('Authorization'));
    if (!user) {
      console.log('Auth/me: No valid user token');
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const profile = await kv.get(`user:${user.id}`);
    if (!profile) {
      console.log(`Auth/me: No profile found for user ${user.id} (${user.email})`);
    } else {
      console.log(`Auth/me: User ${user.email} with role ${profile.role}`);
    }
    return c.json({ user, profile });
  } catch (error) {
    console.log(`Get user error: ${error.message}`);
    return c.json({ error: 'Failed to get user' }, 500);
  }
});

// Update profile
app.put('/make-server-d9983cbe/auth/profile', async (c) => {
  try {
    const user = await verifyToken(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const { name, phone } = await c.req.json();
    const profile = await kv.get(`user:${user.id}`) || {};
    
    const updatedProfile = {
      ...profile,
      name: name || profile.name,
      phone: phone || profile.phone,
      updatedAt: new Date().toISOString()
    };
    
    await kv.set(`user:${user.id}`, updatedProfile);
    
    return c.json({ success: true, profile: updatedProfile });
  } catch (error) {
    console.log(`Profile update error: ${error.message}`);
    return c.json({ error: 'Profile update failed' }, 500);
  }
});

// Change password
app.post('/make-server-d9983cbe/auth/change-password', async (c) => {
  try {
    const user = await verifyToken(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const { newPassword } = await c.req.json();
    
    const { error } = await supabase.auth.admin.updateUserById(
      user.id,
      { password: newPassword }
    );
    
    if (error) {
      console.log(`Password change error: ${error.message}`);
      return c.json({ error: error.message }, 400);
    }
    
    return c.json({ success: true });
  } catch (error) {
    console.log(`Password change exception: ${error.message}`);
    return c.json({ error: 'Password change failed' }, 500);
  }
});

// ==================== BOAT MANAGEMENT ====================

// Get all boats
app.get('/make-server-d9983cbe/boats', async (c) => {
  try {
    const boats = await kv.getByPrefix('boat:');
    return c.json({ boats });
  } catch (error) {
    console.log(`Get boats error: ${error.message}`);
    return c.json({ error: 'Failed to get boats' }, 500);
  }
});

// Create boat (Admin/Operator only)
app.post('/make-server-d9983cbe/boats', async (c) => {
  try {
    const user = await verifyToken(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const profile = await kv.get(`user:${user.id}`);
    if (!profile || !['admin', 'operator'].includes(profile.role)) {
      return c.json({ error: 'Forbidden' }, 403);
    }
    
    const { name, capacity, registrationNumber, type, status } = await c.req.json();
    
    // Check for duplicate registration number to prevent duplicate boats
    const existingBoats = await kv.getByPrefix('boat:');
    const duplicateBoat = existingBoats.find(b => b.registrationNumber === registrationNumber);
    
    if (duplicateBoat) {
      console.log(`Boat with registration ${registrationNumber} already exists`);
      return c.json({ 
        success: true, 
        boat: duplicateBoat, 
        message: 'Boat already registered' 
      });
    }
    
    const boatId = nanoid();
    
    const boat = {
      id: boatId,
      name,
      capacity,
      registrationNumber,
      type: type || 'Ferry',
      status: status || 'active',
      createdAt: new Date().toISOString(),
      createdBy: user.id
    };
    
    await kv.set(`boat:${boatId}`, boat);
    
    return c.json({ success: true, boat });
  } catch (error) {
    console.log(`Create boat error: ${error.message}`);
    return c.json({ error: 'Failed to create boat' }, 500);
  }
});

// Update boat
app.put('/make-server-d9983cbe/boats/:id', async (c) => {
  try {
    const user = await verifyToken(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const profile = await kv.get(`user:${user.id}`);
    if (!profile || !['admin', 'operator'].includes(profile.role)) {
      return c.json({ error: 'Forbidden' }, 403);
    }
    
    const boatId = c.req.param('id');
    const boat = await kv.get(`boat:${boatId}`);
    
    if (!boat) {
      return c.json({ error: 'Boat not found' }, 404);
    }
    
    const updates = await c.req.json();
    const updatedBoat = {
      ...boat,
      ...updates,
      updatedAt: new Date().toISOString(),
      updatedBy: user.id
    };
    
    await kv.set(`boat:${boatId}`, updatedBoat);
    
    return c.json({ success: true, boat: updatedBoat });
  } catch (error) {
    console.log(`Update boat error: ${error.message}`);
    return c.json({ error: 'Failed to update boat' }, 500);
  }
});

// ==================== SCHEDULE MANAGEMENT ====================

// Get schedules
app.get('/make-server-d9983cbe/schedules', async (c) => {
  try {
    const { date, route } = c.req.query();
    
    let schedules = await kv.getByPrefix('schedule:');
    
    // Filter by date and route
    if (date) {
      schedules = schedules.filter(s => s.date === date);
    }
    if (route) {
      schedules = schedules.filter(s => s.route === route);
    }
    
    // Sort by time
    schedules.sort((a, b) => a.departureTime.localeCompare(b.departureTime));
    
    return c.json({ schedules });
  } catch (error) {
    console.log(`Get schedules error: ${error.message}`);
    return c.json({ error: 'Failed to get schedules' }, 500);
  }
});

// Create schedule
app.post('/make-server-d9983cbe/schedules', async (c) => {
  try {
    const user = await verifyToken(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const profile = await kv.get(`user:${user.id}`);
    if (!profile || !['admin', 'operator'].includes(profile.role)) {
      return c.json({ error: 'Forbidden' }, 403);
    }
    
    const { boatId, date, route, departureTime, returnTime } = await c.req.json();
    
    const boat = await kv.get(`boat:${boatId}`);
    if (!boat) {
      return c.json({ error: 'Boat not found' }, 404);
    }
    
    const scheduleId = nanoid();
    
    const schedule = {
      id: scheduleId,
      boatId,
      boatName: boat.name,
      date,
      route,
      departureTime,
      returnTime,
      capacity: boat.capacity,
      seatsBooked: 0,
      seatsAvailable: boat.capacity,
      status: 'active',
      createdAt: new Date().toISOString(),
      createdBy: user.id
    };
    
    await kv.set(`schedule:${scheduleId}`, schedule);
    
    return c.json({ success: true, schedule });
  } catch (error) {
    console.log(`Create schedule error: ${error.message}`);
    return c.json({ error: 'Failed to create schedule' }, 500);
  }
});

// Update schedule
app.put('/make-server-d9983cbe/schedules/:id', async (c) => {
  try {
    const user = await verifyToken(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const profile = await kv.get(`user:${user.id}`);
    if (!profile || !['admin', 'operator'].includes(profile.role)) {
      return c.json({ error: 'Forbidden' }, 403);
    }
    
    const scheduleId = c.req.param('id');
    const schedule = await kv.get(`schedule:${scheduleId}`);
    
    if (!schedule) {
      return c.json({ error: 'Schedule not found' }, 404);
    }
    
    const updates = await c.req.json();
    const updatedSchedule = {
      ...schedule,
      ...updates,
      updatedAt: new Date().toISOString(),
      updatedBy: user.id
    };
    
    await kv.set(`schedule:${scheduleId}`, updatedSchedule);
    
    return c.json({ success: true, schedule: updatedSchedule });
  } catch (error) {
    console.log(`Update schedule error: ${error.message}`);
    return c.json({ error: 'Failed to update schedule' }, 500);
  }
});

// ==================== BOOKING MANAGEMENT ====================

// Create booking (no auth required)
app.post('/make-server-d9983cbe/bookings', async (c) => {
  try {
    const { scheduleId, passengers, contactEmail, contactPhone, route, departureTime, date } = await c.req.json();
    
    // Check if booking is made by an agent
    let agentId = null;
    const authHeader = c.req.header('Authorization');
    if (authHeader) {
      const user = await verifyToken(authHeader);
      if (user) {
        const profile = await kv.get(`user:${user.id}`);
        if (profile && profile.role === 'agent') {
          agentId = user.id;
        }
      }
    }
    
    console.log('Received booking request:', { scheduleId, route, date, passengersCount: passengers.length, agentId });
    
    // scheduleId is now the time slot (e.g., "09:00-09:30"), departureTime is passed separately
    const timeSlot = scheduleId; // Time slot from user selection
    const actualDepartureTime = departureTime || timeSlot;
    
    // Get all boats to find an available one (in production, this would be based on actual schedules)
    const boats = await kv.getByPrefix('boat:');
    const activeBoats = boats.filter(b => b.status === 'active' || b.status === 'approved');
    
    console.log('Active boats found:', activeBoats.length);
    
    if (activeBoats.length === 0) {
      console.log('No boats available');
      return c.json({ error: 'No boats available for booking' }, 400);
    }
    
    // Use the first available boat (in production, this would be based on schedule and availability)
    const boat = activeBoats[0];
    
    // Check seat availability
    const payingPassengers = passengers.filter(p => !p.isInfant);
    if (boat.capacity < payingPassengers.length) {
      console.log('Not enough capacity:', boat.capacity, 'vs', payingPassengers.length);
      return c.json({ error: 'Not enough seats available' }, 400);
    }
    
    // Calculate fare (Ross: ₹493.60, North Bay: ₹693.60, Combined: ₹893.60)
    // Base fare + ₹20 PMB + ₹20 development + ₹3.60 GST
    const fareRates = {
      'ross': 450,
      'ross island': 450,
      'northbay': 650,
      'north bay': 650,
      'combined': 850
    };
    
    const baseFare = fareRates[route.toLowerCase()] || 450;
    const pmbFee = 20;
    const devFee = 20;
    const gst = 3.60;
    const totalPerPassenger = baseFare + pmbFee + devFee + gst; // ₹493.60
    const totalAmount = totalPerPassenger * payingPassengers.length;
    
    const bookingId = nanoid(10).toUpperCase();
    
    // Get the booking date from the request or use today
    const bookingDate = date || new Date().toISOString().split('T')[0];
    
    const booking = {
      id: bookingId,
      scheduleId: timeSlot,
      route,
      date: bookingDate,
      departureTime: actualDepartureTime,
      boatName: boat.name || 'TBA',
      assignedBoat: boat.id,
      agentId: agentId, // Track which agent made the booking
      contactEmail,
      contactPhone,
      passengers: passengers,
      totalPassengers: passengers.length,
      payingPassengers: payingPassengers.length,
      baseFare: baseFare * payingPassengers.length,
      pmbFee: pmbFee * payingPassengers.length,
      devFee: devFee * payingPassengers.length,
      gst: gst * payingPassengers.length,
      totalAmount,
      status: 'pending',
      paymentStatus: 'pending',
      boardingStatus: 'pending',
      createdAt: new Date().toISOString(),
      qrCode: bookingId
    };
    
    await kv.set(`booking:${bookingId}`, booking);
    
    // Save passengers
    for (let i = 0; i < passengers.length; i++) {
      const passenger = passengers[i];
      const passengerId = `${bookingId}-P${i + 1}`;
      
      await kv.set(`passenger:${passengerId}`, {
        id: passengerId,
        bookingId,
        name: passenger.name,
        age: passenger.age,
        gender: passenger.gender,
        address: passenger.address || '',
        phone: passenger.phone || '',
        email: passenger.email || '',
        idType: passenger.idType,
        idNumber: passenger.idNumber,
        isInfant: passenger.isInfant || false,
        createdAt: new Date().toISOString()
      });
    }
    
    console.log(`Successfully created booking ${bookingId} for ${passengers.length} passengers on ${bookingDate}`);
    return c.json({ success: true, booking, bookingId });
  } catch (error) {
    console.log(`Create booking error: ${error.message}`);
    return c.json({ error: 'Failed to create booking: ' + error.message }, 500);
  }
});

// Process payment
app.post('/make-server-d9983cbe/payments', async (c) => {
  try {
    const { bookingId, method, transactionId } = await c.req.json();
    
    const booking = await kv.get(`booking:${bookingId}`);
    if (!booking) {
      return c.json({ error: 'Booking not found' }, 404);
    }
    
    const paymentId = nanoid();
    
    // Mock payment processing
    const payment = {
      id: paymentId,
      bookingId,
      amount: booking.totalAmount,
      method,
      transactionId: transactionId || nanoid(),
      status: 'completed',
      processedAt: new Date().toISOString()
    };
    
    await kv.set(`payment:${paymentId}`, payment);
    
    // Update booking status
    booking.status = 'confirmed';
    booking.paymentStatus = 'paid';
    booking.paymentId = paymentId;
    booking.confirmedAt = new Date().toISOString();
    
    await kv.set(`booking:${bookingId}`, booking);
    
    // Update schedule seat count if schedule exists
    const schedule = await kv.get(`schedule:${booking.scheduleId}`);
    if (schedule && schedule.capacity) {
      schedule.seatsBooked = (schedule.seatsBooked || 0) + booking.payingPassengers;
      schedule.seatsAvailable = schedule.capacity - schedule.seatsBooked;
      await kv.set(`schedule:${booking.scheduleId}`, schedule);
      console.log(`Updated schedule ${booking.scheduleId}: ${schedule.seatsBooked}/${schedule.capacity} seats booked`);
    } else {
      console.log(`No schedule found for ${booking.scheduleId}, skipping seat count update`);
    }
    
    console.log(`Payment processed successfully for booking ${bookingId}`);
    return c.json({ success: true, payment, booking });
  } catch (error) {
    console.log(`Payment processing error: ${error.message}`);
    return c.json({ error: 'Payment processing failed' }, 500);
  }
});

// Get booking by ID
app.get('/make-server-d9983cbe/bookings/:id', async (c) => {
  try {
    const bookingId = c.req.param('id');
    const booking = await kv.get(`booking:${bookingId}`);
    
    if (!booking) {
      return c.json({ error: 'Booking not found' }, 404);
    }
    
    // Get passengers
    const allPassengers = await kv.getByPrefix(`passenger:${bookingId}`);
    
    return c.json({ booking, passengers: allPassengers });
  } catch (error) {
    console.log(`Get booking error: ${error.message}`);
    return c.json({ error: 'Failed to get booking' }, 500);
  }
});

// Search bookings
app.get('/make-server-d9983cbe/bookings', async (c) => {
  try {
    const { email, phone, date, status } = c.req.query();
    
    let bookings = await kv.getByPrefix('booking:');
    
    if (email) {
      bookings = bookings.filter(b => b.contactEmail === email);
    }
    if (phone) {
      bookings = bookings.filter(b => b.contactPhone === phone);
    }
    if (date) {
      bookings = bookings.filter(b => b.date === date);
    }
    if (status) {
      bookings = bookings.filter(b => b.status === status);
    }
    
    // Sort by creation date (newest first)
    bookings.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    
    return c.json({ bookings });
  } catch (error) {
    console.log(`Search bookings error: ${error.message}`);
    return c.json({ error: 'Failed to search bookings' }, 500);
  }
});

// ==================== REFUND MANAGEMENT ====================

// Request refund
app.post('/make-server-d9983cbe/refunds', async (c) => {
  try {
    const { bookingId, reason } = await c.req.json();
    
    const booking = await kv.get(`booking:${bookingId}`);
    if (!booking) {
      return c.json({ error: 'Booking not found' }, 404);
    }
    
    if (booking.status === 'refunded') {
      return c.json({ error: 'Booking already refunded' }, 400);
    }
    
    // Calculate refund amount based on timing
    const tripDate = new Date(booking.date);
    const now = new Date();
    const hoursUntilTrip = (tripDate.getTime() - now.getTime()) / (1000 * 60 * 60);
    
    let refundPercentage = 0;
    let refundReason = reason;
    
    if (reason === 'operator_cancelled') {
      refundPercentage = 100;
    } else if (hoursUntilTrip >= 24) {
      refundPercentage = 100;
    } else if (hoursUntilTrip >= 12) {
      refundPercentage = 50;
    } else {
      return c.json({ error: 'No refund available for cancellations within 12 hours' }, 400);
    }
    
    // Dev fee is non-refundable for user cancellations
    const refundableAmount = reason === 'operator_cancelled' 
      ? booking.totalAmount 
      : booking.baseFare;
    
    const refundAmount = (refundableAmount * refundPercentage) / 100;
    
    const refundId = nanoid();
    
    const refund = {
      id: refundId,
      bookingId,
      requestedAmount: refundAmount,
      approvedAmount: refundAmount,
      reason: refundReason,
      status: 'pending',
      requestedAt: new Date().toISOString()
    };
    
    await kv.set(`refund:${refundId}`, refund);
    
    // Update booking
    booking.refundId = refundId;
    booking.status = 'refund_requested';
    await kv.set(`booking:${bookingId}`, booking);
    
    return c.json({ success: true, refund });
  } catch (error) {
    console.log(`Refund request error: ${error.message}`);
    return c.json({ error: 'Failed to request refund' }, 500);
  }
});

// Process refund (Admin only)
app.post('/make-server-d9983cbe/refunds/:id/process', async (c) => {
  try {
    const user = await verifyToken(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const profile = await kv.get(`user:${user.id}`);
    if (!profile || profile.role !== 'admin') {
      return c.json({ error: 'Forbidden - Admin only' }, 403);
    }
    
    const refundId = c.req.param('id');
    const refund = await kv.get(`refund:${refundId}`);
    
    if (!refund) {
      return c.json({ error: 'Refund not found' }, 404);
    }
    
    const { status, approvedAmount } = await c.req.json();
    
    refund.status = status;
    refund.approvedAmount = approvedAmount || refund.requestedAmount;
    refund.processedAt = new Date().toISOString();
    refund.processedBy = user.id;
    
    await kv.set(`refund:${refundId}`, refund);
    
    // Update booking
    const booking = await kv.get(`booking:${refund.bookingId}`);
    if (status === 'approved') {
      booking.status = 'refunded';
      booking.refundedAmount = refund.approvedAmount;
      
      // Release seats
      const schedule = await kv.get(`schedule:${booking.scheduleId}`);
      schedule.seatsBooked -= booking.payingPassengers;
      schedule.seatsAvailable = schedule.capacity - schedule.seatsBooked;
      await kv.set(`schedule:${booking.scheduleId}`, schedule);
    } else {
      booking.status = 'refund_rejected';
    }
    
    await kv.set(`booking:${booking.id}`, booking);
    
    return c.json({ success: true, refund });
  } catch (error) {
    console.log(`Process refund error: ${error.message}`);
    return c.json({ error: 'Failed to process refund' }, 500);
  }
});

// Get all refunds (Admin only)
app.get('/make-server-d9983cbe/refunds', async (c) => {
  try {
    const user = await verifyToken(c.req.header('Authorization'));
    if (!user) {
      console.log('Refunds: No valid user token');
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const profile = await kv.get(`user:${user.id}`);
    console.log(`Refunds: User ${user.email}, Profile:`, profile);
    if (!profile || profile.role !== 'admin') {
      console.log(`Refunds: Access denied - User role is ${profile?.role || 'undefined'}, expected admin`);
      return c.json({ error: 'Forbidden - Admin only' }, 403);
    }
    
    const refunds = await kv.getByPrefix('refund:');
    
    // Populate refunds with booking information
    const refundsWithBookings = await Promise.all(
      refunds.map(async (refund) => {
        const booking = await kv.get(`booking:${refund.bookingId}`);
        if (booking) {
          return {
            ...refund,
            booking: {
              id: booking.id,
              date: booking.date,
              route: booking.route,
              contactEmail: booking.contactEmail,
              contactPhone: booking.contactPhone,
              totalAmount: booking.totalAmount,
              totalPassengers: booking.totalPassengers,
            }
          };
        }
        return refund;
      })
    );
    
    // Sort by request date (newest first)
    refundsWithBookings.sort((a, b) => new Date(b.requestedAt).getTime() - new Date(a.requestedAt).getTime());
    
    return c.json({ refunds: refundsWithBookings });
  } catch (error) {
    console.log(`Get refunds error: ${error.message}`);
    return c.json({ error: 'Failed to get refunds' }, 500);
  }
});

// ==================== BOARDING MANAGEMENT ====================

// Verify booking for boarding
app.post('/make-server-d9983cbe/boarding/verify', async (c) => {
  try {
    const user = await verifyToken(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const profile = await kv.get(`user:${user.id}`);
    if (!profile || !['admin', 'boarding'].includes(profile.role)) {
      return c.json({ error: 'Forbidden - Boarding team only' }, 403);
    }
    
    const { bookingId } = await c.req.json();
    
    const booking = await kv.get(`booking:${bookingId}`);
    if (!booking) {
      return c.json({ error: 'Booking not found or invalid QR code' }, 404);
    }
    
    if (booking.status !== 'confirmed') {
      return c.json({ error: `Booking status: ${booking.status}. Cannot board.` }, 400);
    }
    
    // Check if already boarded
    const existingAssignment = await kv.getByPrefix(`boarding:${bookingId}`);
    if (existingAssignment.length > 0 && existingAssignment[0].status === 'boarded') {
      return c.json({ error: 'Passenger already boarded' }, 400);
    }
    
    // Get passengers
    const passengers = await kv.getByPrefix(`passenger:${bookingId}`);
    
    return c.json({
      success: true,
      booking,
      passengers,
      canBoard: true
    });
  } catch (error) {
    console.log(`Boarding verification error: ${error.message}`);
    return c.json({ error: 'Verification failed' }, 500);
  }
});

// Assign boat and board passengers
app.post('/make-server-d9983cbe/boarding/assign', async (c) => {
  try {
    const user = await verifyToken(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const profile = await kv.get(`user:${user.id}`);
    if (!profile || !['admin', 'boarding'].includes(profile.role)) {
      return c.json({ error: 'Forbidden - Boarding team only' }, 403);
    }
    
    const { bookingId, assignedBoat } = await c.req.json();
    
    const booking = await kv.get(`booking:${bookingId}`);
    if (!booking) {
      return c.json({ error: 'Booking not found' }, 404);
    }
    
    const assignmentId = nanoid();
    
    const assignment = {
      id: assignmentId,
      bookingId,
      scheduleId: booking.scheduleId,
      assignedBoat,
      assignedBy: user.id,
      assignedAt: new Date().toISOString(),
      status: 'boarded'
    };
    
    await kv.set(`boarding:${assignmentId}`, assignment);
    
    // Update booking
    booking.boardingStatus = 'boarded';
    booking.assignedBoat = assignedBoat;
    booking.boardedAt = new Date().toISOString();
    await kv.set(`booking:${booking.id}`, booking);
    
    return c.json({ success: true, assignment });
  } catch (error) {
    console.log(`Boarding assignment error: ${error.message}`);
    return c.json({ error: 'Assignment failed' }, 500);
  }
});

// Get boarding manifest
app.get('/make-server-d9983cbe/boarding/manifest', async (c) => {
  try {
    const user = await verifyToken(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const { date, scheduleId } = c.req.query();
    
    let bookings = await kv.getByPrefix('booking:');
    
    // Filter confirmed bookings
    bookings = bookings.filter(b => b.status === 'confirmed' || b.boardingStatus === 'boarded');
    
    if (date) {
      bookings = bookings.filter(b => b.date === date);
    }
    if (scheduleId) {
      bookings = bookings.filter(b => b.scheduleId === scheduleId);
    }
    
    // Get passenger details for each booking
    const manifest = [];
    for (const booking of bookings) {
      const passengers = await kv.getByPrefix(`passenger:${booking.id}`);
      manifest.push({
        booking,
        passengers
      });
    }
    
    return c.json({ manifest });
  } catch (error) {
    console.log(`Get manifest error: ${error.message}`);
    return c.json({ error: 'Failed to get manifest' }, 500);
  }
});

// ==================== T-SHIRT MANAGEMENT ====================

// Get T-shirt manifest
app.get('/make-server-d9983cbe/tshirt/manifest', async (c) => {
  try {
    const user = await verifyToken(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const profile = await kv.get(`user:${user.id}`);
    if (!profile || !['admin', 'tshirt'].includes(profile.role)) {
      return c.json({ error: 'Forbidden - T-shirt team only' }, 403);
    }
    
    const { date, route } = c.req.query();
    
    let bookings = await kv.getByPrefix('booking:');
    
    // Filter boarded bookings
    bookings = bookings.filter(b => b.boardingStatus === 'boarded');
    
    if (date) {
      bookings = bookings.filter(b => b.date === date);
    }
    if (route) {
      bookings = bookings.filter(b => b.route === route);
    }
    
    // Get passenger and t-shirt details
    const manifest = [];
    for (const booking of bookings) {
      const passengers = await kv.getByPrefix(`passenger:${booking.id}`);
      
      for (const passenger of passengers) {
        const tshirtOrders = await kv.getByPrefix(`tshirt:${passenger.id}`);
        const tshirtStatus = tshirtOrders.length > 0 ? tshirtOrders[0] : null;
        
        manifest.push({
          bookingId: booking.id,
          passengerId: passenger.id,
          passengerName: passenger.name,
          boat: booking.assignedBoat,
          route: booking.route,
          tshirtStatus: tshirtStatus?.status || 'pending',
          tshirtId: tshirtStatus?.id
        });
      }
    }
    
    return c.json({ manifest });
  } catch (error) {
    console.log(`Get T-shirt manifest error: ${error.message}`);
    return c.json({ error: 'Failed to get manifest' }, 500);
  }
});

// Update T-shirt status
app.post('/make-server-d9983cbe/tshirt/update', async (c) => {
  try {
    const user = await verifyToken(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const profile = await kv.get(`user:${user.id}`);
    if (!profile || !['admin', 'tshirt'].includes(profile.role)) {
      return c.json({ error: 'Forbidden - T-shirt team only' }, 403);
    }
    
    const { passengerId, status, size } = await c.req.json();
    
    const tshirtId = `tshirt:${passengerId}`;
    
    const tshirt = {
      id: tshirtId,
      passengerId,
      size,
      status,
      updatedBy: user.id,
      updatedAt: new Date().toISOString()
    };
    
    await kv.set(tshirtId, tshirt);
    
    return c.json({ success: true, tshirt });
  } catch (error) {
    console.log(`Update T-shirt status error: ${error.message}`);
    return c.json({ error: 'Failed to update status' }, 500);
  }
});

// ==================== PAYMENT APPROVALS ====================

// Approve agent commission
app.post('/make-server-d9983cbe/payments/approve-agent-commission', async (c) => {
  try {
    const { bookingIds } = await c.req.json();
    
    for (const bookingId of bookingIds) {
      const booking = await kv.get(`booking:${bookingId}`);
      if (booking) {
        booking.commissionPaid = true;
        booking.commissionPaidAt = new Date().toISOString();
        await kv.set(`booking:${bookingId}`, booking);
      }
    }
    
    console.log(`Approved agent commission for ${bookingIds.length} bookings`);
    return c.json({ success: true });
  } catch (error) {
    console.log(`Approve agent commission error: ${error.message}`);
    return c.json({ error: 'Failed to approve commission' }, 500);
  }
});

// Approve operator payment
app.post('/make-server-d9983cbe/payments/approve-operator-payment', async (c) => {
  try {
    const { bookingIds, boatId } = await c.req.json();
    
    for (const bookingId of bookingIds) {
      const booking = await kv.get(`booking:${bookingId}`);
      if (booking) {
        booking.operatorPaid = true;
        booking.operatorPaidAt = new Date().toISOString();
        await kv.set(`booking:${bookingId}`, booking);
      }
    }
    
    console.log(`Approved operator payment for ${bookingIds.length} bookings on boat ${boatId}`);
    return c.json({ success: true });
  } catch (error) {
    console.log(`Approve operator payment error: ${error.message}`);
    return c.json({ error: 'Failed to approve payment' }, 500);
  }
});

// ==================== EMERGENCY & SOS MANAGEMENT ====================

// Get all emergencies
app.get('/make-server-d9983cbe/emergencies', async (c) => {
  try {
    const emergencies = await kv.getByPrefix('emergency:');
    // Sort by creation date (newest first)
    emergencies.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return c.json({ emergencies });
  } catch (error) {
    console.log(`Get emergencies error: ${error.message}`);
    return c.json({ error: 'Failed to get emergencies' }, 500);
  }
});

// Create emergency SOS
app.post('/make-server-d9983cbe/emergencies', async (c) => {
  try {
    const { callerName, callerPhone, bookingId, location, emergencyType, description } = await c.req.json();
    
    const emergencyId = nanoid(8).toUpperCase();
    const emergency = {
      id: emergencyId,
      callerName,
      callerPhone,
      bookingId: bookingId || null,
      location: location || 'Not specified',
      emergencyType,
      description,
      status: 'active',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    await kv.set(`emergency:${emergencyId}`, emergency);
    console.log(`Emergency SOS logged: ${emergencyId} - ${emergencyType}`);
    
    return c.json({ success: true, emergency });
  } catch (error) {
    console.log(`Create emergency error: ${error.message}`);
    return c.json({ error: 'Failed to create emergency' }, 500);
  }
});

// Update emergency status
app.put('/make-server-d9983cbe/emergencies/:id/status', async (c) => {
  try {
    const emergencyId = c.req.param('id');
    const { status } = await c.req.json();
    
    const emergency = await kv.get(`emergency:${emergencyId}`);
    if (!emergency) {
      return c.json({ error: 'Emergency not found' }, 404);
    }
    
    emergency.status = status;
    emergency.updatedAt = new Date().toISOString();
    if (status === 'resolved' || status === 'closed') {
      emergency.resolvedAt = new Date().toISOString();
    }
    
    await kv.set(`emergency:${emergencyId}`, emergency);
    console.log(`Emergency ${emergencyId} status updated to ${status}`);
    
    return c.json({ success: true, emergency });
  } catch (error) {
    console.log(`Update emergency status error: ${error.message}`);
    return c.json({ error: 'Failed to update status' }, 500);
  }
});

// ==================== ANALYTICS & REPORTS ====================

// Get dashboard stats (Admin only)
app.get('/make-server-d9983cbe/analytics/dashboard', async (c) => {
  try {
    const user = await verifyToken(c.req.header('Authorization'));
    if (!user) {
      console.log('Analytics: No valid user token');
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    const profile = await kv.get(`user:${user.id}`);
    console.log(`Analytics: User ${user.email}, Profile:`, profile);
    if (!profile || profile.role !== 'admin') {
      console.log(`Analytics: Access denied - User role is ${profile?.role || 'undefined'}, expected admin`);
      return c.json({ error: 'Forbidden - Admin only' }, 403);
    }
    
    const bookings = await kv.getByPrefix('booking:');
    const passengers = await kv.getByPrefix('passenger:');
    const payments = await kv.getByPrefix('payment:');
    const refunds = await kv.getByPrefix('refund:');
    
    const totalBookings = bookings.length;
    const confirmedBookings = bookings.filter(b => b.status === 'confirmed').length;
    const totalPassengers = passengers.filter(p => !p.isInfant).length;
    const totalRevenue = payments
      .filter(p => p.status === 'completed')
      .reduce((sum, p) => sum + p.amount, 0);
    const totalRefunds = refunds
      .filter(r => r.status === 'approved')
      .reduce((sum, r) => sum + r.approvedAmount, 0);
    const pendingRefunds = refunds.filter(r => r.status === 'pending').length;
    
    return c.json({
      totalBookings,
      confirmedBookings,
      totalPassengers,
      totalRevenue,
      totalRefunds,
      pendingRefunds,
      netRevenue: totalRevenue - totalRefunds
    });
  } catch (error) {
    console.log(`Get dashboard stats error: ${error.message}`);
    return c.json({ error: 'Failed to get stats' }, 500);
  }
});

// ==================== DATABASE SEEDING ====================

// Seed database with demo data
app.post('/make-server-d9983cbe/seed', async (c) => {
  try {
    console.log('Starting database seed...');
    
    // Create demo users
    const demoUsers = [
      { email: 'admin@andaman.com', password: 'demo123', name: 'Admin User', role: 'admin' },
      { email: 'operator@andaman.com', password: 'demo123', name: 'Boat Operator', role: 'operator' },
      { email: 'agent@andaman.com', password: 'demo123', name: 'Travel Agent', role: 'agent' },
      { email: 'boarding@andaman.com', password: 'demo123', name: 'Boarding Team', role: 'boarding' },
      { email: 'pcu@andaman.com', password: 'demo123', name: 'PCU Officer', role: 'pcu' },
    ];
    
    for (const user of demoUsers) {
      try {
        // Check if user already exists
        const { data: existingUsers } = await supabase.auth.admin.listUsers();
        const existing = existingUsers?.users?.find(u => u.email === user.email);
        
        if (!existing) {
          const { data, error } = await supabase.auth.admin.createUser({
            email: user.email,
            password: user.password,
            email_confirm: true,
            user_metadata: { name: user.name, role: user.role }
          });
          
          if (error) {
            console.log(`Failed to create user ${user.email}: ${error.message}`);
          } else {
            await kv.set(`user:${data.user.id}`, {
              id: data.user.id,
              email: user.email,
              name: user.name,
              role: user.role,
              status: 'approved',
              phone: '+91 98765 43210',
              createdAt: new Date().toISOString()
            });
            console.log(`Created user: ${user.email}`);
          }
        } else {
          // Ensure profile exists
          let profile = await kv.get(`user:${existing.id}`);
          if (!profile) {
            await kv.set(`user:${existing.id}`, {
              id: existing.id,
              email: user.email,
              name: user.name,
              role: user.role,
              status: 'approved',
              phone: '+91 98765 43210',
              createdAt: new Date().toISOString()
            });
            console.log(`Created profile for existing user: ${user.email}`);
          }
        }
      } catch (err) {
        console.log(`Error processing user ${user.email}: ${err.message}`);
      }
    }
    
    // Create demo boats
    const demoBoats = [
      {
        id: 'boat-002',
        name: 'MV Green Ocean',
        registrationNumber: 'AN-002-2023',
        type: 'ferry',
        capacity: 80,
        ownerName: 'Boat Operator',
        status: 'approved',
        createdAt: new Date().toISOString()
      },
      {
        id: 'boat-003',
        name: 'MV Island Explorer',
        registrationNumber: 'AN-003-2023',
        type: 'ferry',
        capacity: 60,
        ownerName: 'Boat Operator',
        status: 'approved',
        createdAt: new Date().toISOString()
      },
    ];
    
    for (const boat of demoBoats) {
      await kv.set(`boat:${boat.id}`, boat);
      console.log(`Created boat: ${boat.name}`);
    }
    
    // Create schedules for next 7 days
    const routes = ['ross', 'northbay', 'combined'];
    const today = new Date();
    
    for (let dayOffset = 0; dayOffset < 7; dayOffset++) {
      const date = new Date(today);
      date.setDate(date.getDate() + dayOffset);
      const dateStr = date.toISOString().split('T')[0];
      
      for (const route of routes) {
        for (const boat of demoBoats) {
          const scheduleId = `schedule-${boat.id}-${route}-${dateStr}`;
          await kv.set(`schedule:${scheduleId}`, {
            id: scheduleId,
            boatId: boat.id,
            route: route,
            date: dateStr,
            departureTime: route === 'ross' ? '09:00' : route === 'northbay' ? '11:00' : '08:00',
            returnTime: route === 'ross' ? '14:00' : route === 'northbay' ? '16:00' : '17:00',
            capacity: boat.capacity,
            seatsBooked: 0,
            seatsAvailable: boat.capacity,
            status: 'active',
            createdAt: new Date().toISOString()
          });
        }
      }
      console.log(`Created schedules for ${dateStr}`);
    }
    
    console.log('Database seed completed successfully!');
    return c.json({ 
      success: true, 
      message: 'Database seeded successfully',
      users: demoUsers.length,
      boats: demoBoats.length,
      days: 7
    });
  } catch (error) {
    console.log(`Seed error: ${error.message}`);
    return c.json({ error: 'Failed to seed database' }, 500);
  }
});

// Health check
app.get('/make-server-d9983cbe/health', (c) => {
  return c.json({ status: 'ok', timestamp: new Date().toISOString() });
});

Deno.serve(app.fetch);
