# 🚀 Andaman Boat Ticketing - Quick Start Guide

## 🎬 Getting Started (First Launch)

### Step 1: Initialize the System

1. Open the application in your browser
2. You'll see the **"Initialize System"** screen
3. Click **"Initialize System"** button
4. Wait 10-20 seconds while demo data is created
5. System creates:
   - ✅ 5 demo user accounts
   - ✅ 3 boats with schedules
   - ✅ Schedules for next 3 days

### Step 2: Test Public Booking (No Login Required)

1. Click **"Skip"** or wait for redirect to home page
2. You'll see the booking flow
3. Select:
   - **Date**: Today or tomorrow
   - **Route**: Ross Island / North Bay / Combined
4. Add passenger details (min 1, max 10)
5. Choose a time slot
6. Enter contact email and phone
7. Accept terms
8. Click **"Process Payment"** (mock payment)
9. **Note down your Booking ID** (e.g., `ABC123XYZ`)

---

## 👥 User Roles & Access

### 🔵 Public (No Account Needed)
**What you can do:**
- Book tickets
- View booking confirmation
- No registration required

**How to access:**
- Just visit the homepage
- Start booking immediately

---

### 🔴 Admin Dashboard
**What you can do:**
- Manage boats and schedules
- View all bookings and analytics
- Process refund requests
- Full system control

**How to access:**
1. Click **"Dashboard Sign In"**
2. Email: `admin@andaman.com`
3. Password: `demo123`
4. Click **"Sign In"**

**Main Features:**
- **Boats Tab**: Add/edit boats
- **Schedules Tab**: Create schedules
- **Bookings Tab**: View all bookings
- **Refunds Tab**: Approve/reject refunds

---

### 🟢 Boarding Team Dashboard
**What you can do:**
- Verify passenger bookings
- Assign boats
- Mark passengers as boarded
- Print boarding passes

**How to access:**
1. Click **"Dashboard Sign In"**
2. Email: `boarding@andaman.com`
3. Password: `demo123`

**Workflow:**
1. Enter Booking ID (from passenger's ticket)
2. Click **"Verify"**
3. Review passenger details
4. Enter boat assignment (e.g., "Makruzz Gold")
5. Click **"Assign & Board"**
6. Click **"Print Pass"** to print boarding passes

---

### 🟡 T-Shirt Team Dashboard
**What you can do:**
- View passengers who have boarded
- Track T-shirt distribution
- Mark items as packed/ready/delivered
- Flag issues

**How to access:**
1. Click **"Dashboard Sign In"**
2. Email: `tshirt@andaman.com`
3. Password: `demo123`

**Workflow:**
1. Select date to view manifest
2. For each passenger:
   - Select T-shirt size
   - Click status buttons:
     - 📦 Packed
     - ✓ Ready
     - ✓ Done (Delivered)
     - ⚠️ Flag (if issue)
3. Use bulk actions to mark all at once

---

### 🟠 Operator Dashboard
**What you can do:**
- Same as Admin (manage boats and schedules)
- View manifests

**How to access:**
- Email: `operator@andaman.com`
- Password: `demo123`

---

### 🟣 Agent Dashboard
**What you can do:**
- Book tickets for customers
- Track commission

**How to access:**
- Email: `agent@andaman.com`
- Password: `demo123`

---

## 📋 Common Workflows

### Complete Booking-to-Boarding Flow

```
1. PUBLIC BOOKING
   ↓ Passenger books online
   ↓ Receives Booking ID: ABC123XYZ
   ↓
2. ARRIVAL AT DOCK
   ↓ Passenger shows Booking ID
   ↓
3. BOARDING VERIFICATION (boarding@andaman.com)
   ↓ Enter ABC123XYZ
   ↓ Click "Verify"
   ↓ Assign boat: "Makruzz Gold"
   ↓ Click "Assign & Board"
   ↓ Print 2 boarding passes
   ↓
4. T-SHIRT DISTRIBUTION (tshirt@andaman.com)
   ↓ View manifest
   ↓ Find passenger
   ↓ Select size: M
   ↓ Mark as: Packed → Ready → Delivered
   ↓
5. TRIP COMPLETION
   ✅ Passenger boards boat
   ✅ Receives T-shirt
   ✅ Enjoys trip
```

### Refund Process

```
1. REFUND REQUEST
   ↓ Customer requests refund
   ↓ System calculates eligible amount
   ↓
2. ADMIN REVIEW (admin@andaman.com)
   ↓ Go to Refunds tab
   ↓ Review request
   ↓ Click "Approve" or "Reject"
   ↓
3. PROCESSING
   ✅ If approved: Amount refunded
   ✅ Seats released back to schedule
   ✅ Customer notified
```

---

## 🎯 Demo Scenarios to Test

### Scenario 1: Full Booking Flow
1. Book a ticket (any route)
2. Complete payment
3. Sign in as boarding team
4. Verify and board the booking
5. Sign in as T-shirt team
6. Process T-shirt delivery

### Scenario 2: Multiple Passengers
1. Book with 5 passengers (including 1 infant)
2. Verify infant is marked as free
3. Check total fare calculation
4. Complete booking

### Scenario 3: Refund Processing
1. Book a ticket for tomorrow
2. Request refund (use Tourist Dashboard or manually)
3. Sign in as admin
4. Approve refund
5. Verify seats are released

### Scenario 4: Schedule Management
1. Sign in as admin
2. Add a new boat
3. Create schedules for next week
4. Book tickets on new schedule

---

## ⚙️ Configuration

### Change Fare Prices
Edit `/components/BookingFlow.tsx`:
```typescript
const ROUTES = [
  { value: 'ross', label: 'Ross Island Only', fare: 470, cutoff: '14:00' },
  { value: 'northbay', label: 'North Bay Only', fare: 670, cutoff: '11:30' },
  { value: 'combined', label: 'Ross + North Bay', fare: 870, cutoff: '14:00' },
];

const DEV_FEE = 20;
```

### Add More Demo Accounts
Edit `/utils/seedData.ts`:
```typescript
const demoAccounts = [
  { email: 'newuser@andaman.com', password: 'demo123', name: 'New User', role: 'agent' },
  // Add more accounts
];
```

---

## 🔧 Troubleshooting

### "System already initialized"
- Click **"Skip (Use Existing Data)"**
- System detects previous initialization

### Booking ID not found
- Check spelling (case-sensitive)
- Ensure booking status is "confirmed"
- Verify payment was completed

### Can't sign in
- Verify email is correct
- Password is: `demo123` (all lowercase)
- Try refreshing the page

### Manifest is empty
- Check selected date
- Ensure bookings are confirmed
- For T-shirt: passengers must be boarded first

### Schedule shows no seats
- Check if schedule is for future date
- Verify boat capacity
- See if bookings have filled capacity

---

## 📊 Key Metrics to Monitor (Admin)

Dashboard shows:
- **Total Bookings**: All time
- **Confirmed Bookings**: Paid tickets
- **Total Passengers**: Paying passengers only
- **Total Revenue**: All payments received
- **Net Revenue**: Revenue minus refunds
- **Pending Refunds**: Awaiting approval

---

## 🎨 UI Tips

### For Mobile Users
- All screens are mobile-responsive
- Use horizontal scroll on tables if needed
- Pinch to zoom on booking confirmation

### For Desktop Users
- Use keyboard shortcuts where available
- Print boarding passes directly
- Export manifests (future feature)

---

## 🚨 Important Notes

### Before Production Launch:

1. **Replace Mock Payment**
   - Integrate Razorpay or Stripe
   - Test with real payment flow
   - Add webhook handlers

2. **Email/SMS Integration**
   - Connect Twilio for SMS
   - Setup email service (SendGrid/AWS SES)
   - Test notification delivery

3. **Security Audit**
   - Review all API endpoints
   - Test role permissions
   - Add rate limiting
   - Enable 2FA for admin

4. **Database Migration**
   - Move from KV store to PostgreSQL
   - Create proper indexes
   - Enable Row Level Security
   - Backup strategy

5. **Legal & Compliance**
   - Terms & Conditions
   - Privacy Policy
   - Refund Policy (legal review)
   - Data retention compliance

---

## 📞 Support

### For Development Issues:
- Check browser console for errors
- Review API logs in Supabase dashboard
- Test with different browsers

### For Business Logic:
- Refer to `DEPLOYMENT_GUIDE.md`
- Check `SYSTEM_ARCHITECTURE.md`
- Review PRD for requirements

---

## ✅ Pre-Launch Checklist

- [ ] Tested complete booking flow
- [ ] Verified boarding process
- [ ] Tested T-shirt workflow
- [ ] Processed sample refunds
- [ ] Created test schedules
- [ ] Verified all user roles work
- [ ] Tested on mobile devices
- [ ] Checked fare calculations
- [ ] Reviewed refund policy logic
- [ ] Integrated payment gateway
- [ ] Setup email/SMS notifications
- [ ] Configured production domain
- [ ] Backed up database
- [ ] Trained staff on each dashboard
- [ ] Created user documentation

---

## 🎉 You're Ready!

The system is fully functional and ready for testing. Start with the demo data, test all workflows, and when confident, proceed with production setup.

**Happy Sailing! ⛵**

---

**Quick Access Summary:**

| Role | Email | Password | Primary Function |
|------|-------|----------|------------------|
| Public | - | - | Book tickets |
| Admin | admin@andaman.com | demo123 | Full management |
| Boarding | boarding@andaman.com | demo123 | Passenger verification |
| T-Shirt | tshirt@andaman.com | demo123 | Merchandise tracking |
| Operator | operator@andaman.com | demo123 | Boat/schedule management |
| Agent | agent@andaman.com | demo123 | Book for customers |
