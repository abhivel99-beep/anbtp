# 🧪 Testing Guide - Error Fixes Verification

## 🎯 **Quick Test Scenarios**

### **Scenario 1: Fresh Start (Recommended First Test)**

1. **Clear Everything:**
   ```
   - Open DevTools (F12)
   - Go to Application tab
   - Clear all Local Storage
   - Clear all Session Storage
   - Close and reopen browser
   ```

2. **Initialize System:**
   ```
   - Reload page
   - Should see "Initialize System" screen
   - Click "Initialize System"
   - Watch console for logs
   - Should see: ✅ Created admin: admin@andaman.com
   - Should see: ✅ Created boat: Makruzz Gold
   - Should see: ✅ Created schedule: ...
   - Should see "System Ready!" message
   - Should auto-redirect to landing page
   ```

3. **Expected Console Output:**
   ```
   🌱 Seeding demo data...
   ✅ Created admin: admin@andaman.com
   ✅ Created operator: operator@andaman.com
   ✅ Created agent: agent@andaman.com
   ✅ Created boarding: boarding@andaman.com
   ✅ Created tshirt: tshirt@andaman.com
   🔐 Signed in as admin
   🚢 Created boat: Makruzz Gold
   🚢 Created boat: Sea Hawk
   🚢 Created boat: Island Express
   📅 Created schedule: Makruzz Gold - ross - 2025-01-12
   ...
   ✅ Demo data seeded successfully!
   ```

---

### **Scenario 2: Repeat Initialization (Tests Duplicate Handling)**

1. **Clear Storage Again:**
   ```
   - Clear localStorage
   - Reload page
   ```

2. **Initialize Again:**
   ```
   - Click "Initialize System"
   - Should NOT see any errors
   - Should see: ⏭️ Account already exists: admin@andaman.com
   - Should still complete successfully
   - Should redirect to landing page
   ```

3. **Expected Console Output:**
   ```
   🌱 Seeding demo data...
   ⏭️ Account already exists: admin@andaman.com
   ⏭️ Account already exists: operator@andaman.com
   ...
   🔐 Signed in as admin
   ✅ Demo data seeded successfully!
   ```

---

### **Scenario 3: Admin Sign In & Dashboard Access**

1. **Navigate to Sign In:**
   ```
   - From landing page, click "Sign In"
   - Or click "Dashboard Sign In" from any page
   ```

2. **Sign In as Admin:**
   ```
   Email: admin@andaman.com
   Password: demo123
   ```

3. **Verify Dashboard Access:**
   ```
   - Should redirect to Admin Dashboard
   - Should see dashboard tabs
   - Should NOT see "Forbidden - Admin only" errors
   - Open DevTools → Network tab
   - Should see successful responses (200) for:
     - /auth/me
     - /analytics/dashboard
     - /refunds
     - /schedules
     - /boats
   ```

4. **Check Console Logs:**
   ```
   Expected logs:
   - Successful signin: admin@andaman.com with role admin
   - Auth/me: User admin@andaman.com with role admin
   - Analytics: User admin@andaman.com, Profile: { role: 'admin', status: 'approved', ... }
   ```

---

### **Scenario 4: Operator Dashboard (Separate from Admin)**

1. **Sign Out:**
   ```
   - Click user menu → Sign Out
   ```

2. **Sign In as Operator:**
   ```
   Email: operator@andaman.com
   Password: demo123
   ```

3. **Verify Operator Dashboard:**
   ```
   - Should redirect to OPERATOR Dashboard (not Admin)
   - Should see tabs: My Boats, Approved Schedules, Today's Trips
   - Should NOT see admin-only features
   - Can register new boats
   - Can view schedules
   ```

---

### **Scenario 5: Tourist Registration (Instant Approval)**

1. **Go to Register:**
   ```
   - From landing page, click "Register"
   - Or from sign-in page, click "Register here"
   ```

2. **Register as Tourist:**
   ```
   Step 1: Select "Tourist"
   Step 2: Fill in:
     - Name: Test Tourist
     - Email: tourist@test.com
     - Phone: 1234567890
     - Password: test123
     - Confirm Password: test123
   Click "Complete Registration"
   ```

3. **Verify Success:**
   ```
   - Should see "Registration successful!" alert
   - Should redirect to Sign In page
   ```

4. **Sign In Immediately:**
   ```
   Email: tourist@test.com
   Password: test123
   
   - Should work immediately (no approval needed)
   - Should redirect to Tourist Dashboard
   ```

---

### **Scenario 6: Operator Registration (Requires Approval)**

1. **Register as Operator:**
   ```
   Step 1: Select "Boat Operator"
   Step 2: Fill basic info
     - Name: Test Operator
     - Email: testop@test.com
     - Password: test123
   Step 3: Fill operator details
     - Company Name: Test Boats Ltd
     - Registration Number: AN-2025-999
     - Number of Boats: 2
   Click "Complete Registration"
   ```

2. **Verify Pending Status:**
   ```
   - Should see "Awaiting admin approval" message
   - Should redirect to Sign In
   ```

3. **Try to Sign In (Should Fail):**
   ```
   Email: testop@test.com
   Password: test123
   
   - Should see error: "Your account is awaiting admin approval"
   - Should NOT be able to access dashboard
   ```

4. **Approve as Admin:**
   ```
   - Sign out
   - Sign in as admin@andaman.com
   - (When approval panel is added to admin dashboard)
   - Or use API directly for now:
     - Check console for user ID
     - Call approval endpoint manually
   ```

5. **Sign In as Operator (After Approval):**
   ```
   - Should now work
   - Should access Operator Dashboard
   ```

---

### **Scenario 7: Agent Registration (Similar to Operator)**

1. **Register as Agent:**
   ```
   Step 1: Select "Travel Agent"
   Step 2: Fill basic info
   Step 3: Fill agent details
     - Agency Name: Test Travel Agency
     - License Number: AG-2025-888
     - Years of Experience: 5
   ```

2. **Follow same approval flow as Operator**

---

## 🔍 **What to Look For**

### ✅ **Success Indicators:**

**In Browser:**
- No red error messages
- Smooth navigation between pages
- Dashboards load correctly
- Role-appropriate features visible

**In Console:**
- Descriptive log messages
- "Successful signin" messages
- No 403 Forbidden errors
- No 401 Unauthorized errors (when signed in)

**In Network Tab:**
- API calls return 200 OK
- `/auth/me` returns user and profile
- Profile includes `role` and `status` fields
- Admin endpoints accessible by admin

---

### ❌ **Error Indicators (Should NOT See):**

**These should be FIXED:**
- ❌ "A user with this email address has already been registered" (during init)
- ❌ "Forbidden - Admin only" (when signed in as admin)
- ❌ "Failed to load dashboard data" (when signed in)
- ❌ Duplicate user creation errors breaking initialization

**These are expected:**
- ✅ "Invalid credentials" (with wrong password)
- ✅ "Unauthorized" (when not signed in)
- ✅ "Awaiting admin approval" (for pending accounts)
- ✅ "Forbidden" (when wrong role tries to access endpoint)

---

## 📊 **Data Validation**

### Check User Profile Structure:

**Via Network Tab:**
1. Sign in
2. Check `/auth/me` response
3. Should see:
   ```json
   {
     "user": { "id": "...", "email": "..." },
     "profile": {
       "id": "...",
       "email": "admin@andaman.com",
       "name": "Admin User",
       "role": "admin",
       "status": "approved",
       "createdAt": "2025-01-12T..."
     }
   }
   ```

**Required fields:**
- ✅ id
- ✅ email
- ✅ name
- ✅ role
- ✅ status (NEW - must be present)
- ✅ createdAt

---

## 🐛 **If You Still See Errors**

### Error: "Forbidden - Admin only"

**Check:**
1. Are you signed in?
2. Network → Check `/auth/me` response
3. Does profile have `role: 'admin'`?
4. Does profile have `status: 'approved'`?
5. Is auth token in localStorage?

**Fix:**
- Clear localStorage
- Re-initialize system
- Sign in again

### Error: "Unauthorized"

**Check:**
1. Is auth_token in localStorage?
2. Try signing out and in again
3. Check if session expired

### Error: Initialization Fails

**Check:**
1. Console logs for specific error
2. Network tab for failed requests
3. Check if Supabase is accessible
4. Try "Skip (Use Existing Data)" button

---

## ✅ **All Tests Pass Checklist**

- [ ] Fresh initialization completes
- [ ] Repeat initialization doesn't error
- [ ] Admin can sign in
- [ ] Admin dashboard loads without errors
- [ ] Admin can access analytics
- [ ] Admin can access refunds
- [ ] Operator sees Operator Dashboard (not Admin)
- [ ] Agent sees Agent Dashboard
- [ ] Boarding sees Boarding Dashboard
- [ ] T-shirt sees T-shirt Dashboard
- [ ] Tourist registration works (instant access)
- [ ] Operator registration creates pending account
- [ ] Agent registration creates pending account
- [ ] Pending accounts cannot sign in
- [ ] After approval, accounts can sign in
- [ ] Console shows descriptive logs
- [ ] No 403 errors for authorized users
- [ ] Navigation works smoothly
- [ ] Landing page displays correctly
- [ ] Registration flow is complete

---

## 📝 **Report Format**

If you find issues, report like this:

```
**Issue:** [Brief description]

**Steps to Reproduce:**
1. [Step 1]
2. [Step 2]
3. [Step 3]

**Expected:** [What should happen]

**Actual:** [What actually happened]

**Console Logs:**
[Paste relevant console output]

**Network Response:**
[Paste API response if relevant]

**Role:** [Which user role you were testing as]
```

---

## 🎯 **Next Phase Testing**

After confirming fixes work, test new features:
1. Approval Panel in Admin Dashboard
2. Enhanced Boarding Pass generation
3. T-shirt Dashboard improvements
4. Feedback & Refund forms
5. SOS/Emergency system
6. Daily/Monthly analytics

---

**Good luck with testing! 🚀**
