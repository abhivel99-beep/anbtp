# Andaman Boat Ticketing Platform - Quick Reference

## 🚀 Quick Start

### Access the Application
1. Visit the landing page
2. Choose to Sign In, Register, or Book as Guest
3. Select your role during registration:
   - **Tourist**: Immediate access
   - **Travel Agent**: Requires admin approval (3-7 days)
   - **Boat Operator**: Requires admin approval (3-7 days)

## 👥 User Roles & Access

### 🏖️ **Tourist**
- Browse destinations
- Book ferry tickets (up to 10 passengers + infants)
- View bookings
- Submit feedback
- Request refunds

### 🏢 **Travel Agent**
**Registration Requirements:**
- Agency Name & Address
- Contact Person Details
- GSTIN / Company Registration Number
- PAN Card
- Bank Account Details
- Documents: Business Registration, Address Proof, Identity Proof
- OTP Verification

**After Approval:**
- Book tickets for customers
- Access booking management
- View schedules

### 🚢 **Boat Operator**
**Registration Requirements:**
- Operator Name & Address
- Boat Details (Name, Type, Registration No., Expiry Date, Capacity)
- Master/Captain Details
- Specified Routes
- Documents: Insurance Certificates, Survey Reports (Form 2, Form 6), Boat Registration (Form 8)
- OTP Verification

**After Approval:**
- Register and manage boats
- View approved schedules
- View today's trips
- Access passenger lists

### 👔 **Admin**
**Dashboard Access:**
- Daily/Monthly analytics
- Boat fleet management
- Trip scheduling (with assigned & rescue boats)
- Approval portal (review agent/operator registrations)
- SOS & Emergency system
- Booking management
- Refund processing

### 🎫 **Boarding Team**
- Select date and schedule
- View confirmed bookings
- Allot boats to bookings
- Generate boarding passes with QR codes
- Print boarding passes

### 👕 **T-Shirt Team**
- View passenger manifest
- Filter by date and route
- Select t-shirt sizes
- Track status (Pending, Packed, Ready, Delivered, Flagged)
- Bulk actions

## 📋 Key Workflows

### **Booking Process**
1. Sign In → Select Route → Choose Date & Schedule
2. Add Passengers (Max 10 paying + infants)
3. Complete Payment
4. Receive Confirmation & QR Code Ticket

### **Registration Approval (Agent/Operator)**
1. Submit registration with documents
2. OTP verification (Email & Mobile)
3. Admin review (3-7 business days)
4. Automatic GSTIN verification
5. Manual document review
6. Email & SMS notification
7. Access granted upon approval

### **Boarding Process**
1. Passenger arrives with booking confirmation
2. Boarding team selects schedule
3. Loads confirmed bookings
4. Allots boat to booking
5. Generates boarding pass with QR code
6. Prints boarding pass
7. Passenger boards

### **Refund Process**
1. Submit refund request (within 24 hours)
2. Provide booking details & reason
3. Admin reviews
4. Approval/Rejection
5. Refund processed (3-7 business days)
6. Notification sent

## 💰 Pricing

| Route | Price |
|-------|-------|
| Ross Island | ₹470 |
| North Bay | ₹670 |
| Ross Island & North Bay (Combined) | ₹870 |

## 📅 Booking Rules

- **Advance Booking**: 3-day window
- **Maximum Passengers**: 10 paying passengers per booking
- **Infants**: Allowed (no specific limit)
- **Refund Window**: Within 24 hours of cancellation
- **Processing Time**: 3-7 business days

## 🎯 Key Features

### **Home Page Highlights**
- ✓ Instant Confirmation
- ✓ 3-Day Booking Window
- ✓ QR Code Tickets
- ✓ 99.8% Safety Record
- ✓ 24/7 Customer Support
- ✓ Verified Boats
- ✓ Real-Time Info

### **Admin Tools**
- Daily & Monthly Analytics
- Active/Inactive Boat Management
- Trip Scheduling with Rescue Boats
- Registration Approval Portal
- SOS & Emergency Monitoring
- Refund Management

### **Boarding Pass Includes**
- QR Code
- Passenger ID & Name
- Age & Contact
- Boat Name & Timing
- Island(s) of Visit
- Date of Travel
- Total Passengers

## 📞 Support

- **Email**: info@andamanboats.com
- **Phone**: +91 XXXXX XXXXX
- **Support**: 24/7 Available

## 🔐 Security

- OTP verification for registrations
- Role-based access control
- Document verification
- Government database cross-referencing
- Secure payment processing
- Data encryption

## 🎨 Design

- Responsive design (Mobile, Tablet, Desktop)
- Gradient blue theme
- Card-based layouts
- Modern typography
- Accessible UI
- Print-optimized boarding passes

## 📱 Pages & Dashboards

1. **Public Landing Page** - Browse & learn
2. **Sign In** - User authentication
3. **Register** - Multi-step registration
4. **Booking Flow** - Ticket booking
5. **Admin Dashboard** - Complete oversight
6. **Operator Dashboard** - Boat & schedule management
7. **Agent Dashboard** - Customer bookings
8. **Boarding Dashboard** - Check-in & boarding passes
9. **T-Shirt Dashboard** - Merchandise management
10. **Feedback/Refund Page** - Post-trip services

## ⚡ Quick Actions

### **For Tourists**
- Click "Book Now" on home page
- Sign in or continue as guest
- Select route and date
- Add passengers and pay

### **For Agents/Operators**
- Click "Register" on home page
- Select role (Agent or Operator)
- Complete multi-step form
- Upload required documents
- Verify OTP
- Wait for admin approval (3-7 days)

### **For Admin**
- Sign in with admin credentials
- View analytics on dashboard
- Navigate to Approvals tab
- Review pending registrations
- Approve or reject with comments

### **For Boarding Team**
- Sign in with boarding credentials
- Select date and schedule
- Load bookings
- Select boat for allotment
- Allot boats to bookings
- Generate and print boarding passes

### **For T-Shirt Team**
- Sign in with t-shirt team credentials
- Select date and route
- View passenger manifest
- Update t-shirt sizes and status
- Use bulk actions as needed

## 🚨 Emergency

- Admin dashboard has dedicated SOS & Emergency tab
- Real-time alert monitoring
- Quick response actions
- Crisis management tools

## ✅ Status Indicators

### **Booking Status**
- 🟡 Pending
- 🟢 Confirmed
- 🔴 Cancelled
- 🔵 Refunded

### **Registration Status**
- 🟡 Pending
- 🟢 Approved
- 🔴 Rejected

### **Boat Status**
- 🟢 Active
- 🔴 Inactive
- 🟡 Pending

### **T-Shirt Status**
- ⚪ Pending
- 🔵 Packed
- 🟢 Ready
- ✅ Delivered
- 🔴 Flagged

---

## 🎉 You're Ready to Go!

The platform is fully functional and production-ready. All features have been implemented as requested, including the beautiful homepage, detailed registration system, comprehensive dashboards, boarding pass generation, and feedback/refund system.

**Happy Sailing! 🚢🌊**
