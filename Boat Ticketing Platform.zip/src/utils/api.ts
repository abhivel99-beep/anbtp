import { projectId, publicAnonKey } from './supabase/info';

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-d9983cbe`;

export class ApiClient {
  private token: string | null = null;

  setToken(token: string | null) {
    this.token = token;
    try {
      if (token) {
        localStorage.setItem('auth_token', token);
      } else {
        localStorage.removeItem('auth_token');
      }
    } catch (error) {
      console.error('Failed to set token in localStorage:', error);
    }
  }

  getToken() {
    if (!this.token) {
      try {
        this.token = localStorage.getItem('auth_token');
      } catch (error) {
        console.error('Failed to get token from localStorage:', error);
        return null;
      }
    }
    return this.token;
  }

  private async request(endpoint: string, options: RequestInit = {}) {
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
      ...options.headers,
    };

    const token = this.getToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    } else {
      headers['Authorization'] = `Bearer ${publicAnonKey}`;
    }

    const response = await fetch(`${API_BASE}${endpoint}`, {
      ...options,
      headers,
    });

    const data = await response.json();

    if (!response.ok) {
      console.error(`API Error (${endpoint}):`, data);
      throw new Error(data.error || 'API request failed');
    }

    return data;
  }

  // Auth
  async signIn(email: string, password: string) {
    const data = await this.request('/auth/signin', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    if (data.session?.access_token) {
      this.setToken(data.session.access_token);
    }
    return data;
  }

  async signUp(email: string, password: string, name: string, role: string) {
    return this.request('/auth/signup', {
      method: 'POST',
      body: JSON.stringify({ email, password, name, role }),
    });
  }

  async register(data: any) {
    return this.request('/auth/register', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async getPendingRegistrations() {
    return this.request('/auth/registrations/pending');
  }

  async approveRegistration(userId: string, approved: boolean, comments?: string) {
    return this.request(`/auth/registrations/${userId}/approve`, {
      method: 'POST',
      body: JSON.stringify({ approved, comments }),
    });
  }

  async getMe() {
    return this.request('/auth/me');
  }

  async updateProfile(name: string, phone: string) {
    return this.request('/auth/profile', {
      method: 'PUT',
      body: JSON.stringify({ name, phone }),
    });
  }

  async changePassword(newPassword: string) {
    return this.request('/auth/change-password', {
      method: 'POST',
      body: JSON.stringify({ newPassword }),
    });
  }

  signOut() {
    this.setToken(null);
  }

  // Boats
  async getBoats() {
    return this.request('/boats');
  }

  async createBoat(boatData: { name: string; capacity: number; registrationNumber: string; type?: string; status?: string }) {
    return this.request('/boats', {
      method: 'POST',
      body: JSON.stringify(boatData),
    });
  }

  async updateBoat(id: string, updates: any) {
    return this.request(`/boats/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  }

  // Schedules
  async getSchedules(date?: string, route?: string) {
    const params = new URLSearchParams();
    if (date) params.append('date', date);
    if (route) params.append('route', route);
    return this.request(`/schedules?${params.toString()}`);
  }

  async createSchedule(scheduleData: { boatId: string; date: string; route: string; departureTime: string; returnTime: string }) {
    return this.request('/schedules', {
      method: 'POST',
      body: JSON.stringify(scheduleData),
    });
  }

  async updateSchedule(id: string, updates: any) {
    return this.request(`/schedules/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  }

  // Bookings
  async createBooking(scheduleId: string, passengers: any[], contactEmail: string, contactPhone: string, route: string, departureTime?: string, date?: string) {
    return this.request('/bookings', {
      method: 'POST',
      body: JSON.stringify({ scheduleId, passengers, contactEmail, contactPhone, route, departureTime, date }),
    });
  }

  async getBooking(id: string) {
    return this.request(`/bookings/${id}`);
  }

  async searchBookings(filters: { email?: string; phone?: string; date?: string; status?: string; bookingId?: string }) {
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value) params.append(key, value);
    });
    return this.request(`/bookings?${params.toString()}`);
  }

  async updateBoardingStatus(bookingId: string, status: string, notes?: string) {
    return this.request(`/boarding/status`, {
      method: 'POST',
      body: JSON.stringify({ bookingId, status, notes }),
    });
  }

  // Payments
  async processPayment(bookingId: string, method: string, transactionId?: string) {
    return this.request('/payments', {
      method: 'POST',
      body: JSON.stringify({ bookingId, method, transactionId }),
    });
  }

  // Refunds
  async requestRefund(bookingId: string, reason: string) {
    return this.request('/refunds', {
      method: 'POST',
      body: JSON.stringify({ bookingId, reason }),
    });
  }

  async processRefund(refundId: string, status: string, approvedAmount?: number) {
    return this.request(`/refunds/${refundId}/process`, {
      method: 'POST',
      body: JSON.stringify({ status, approvedAmount }),
    });
  }

  async getRefunds() {
    return this.request('/refunds');
  }

  // Boarding
  async verifyBooking(bookingId: string) {
    return this.request('/boarding/verify', {
      method: 'POST',
      body: JSON.stringify({ bookingId }),
    });
  }

  async assignBoat(bookingId: string, assignedBoat: string) {
    return this.request('/boarding/assign', {
      method: 'POST',
      body: JSON.stringify({ bookingId, assignedBoat }),
    });
  }

  async getBoardingManifest(date?: string, scheduleId?: string) {
    const params = new URLSearchParams();
    if (date) params.append('date', date);
    if (scheduleId) params.append('scheduleId', scheduleId);
    return this.request(`/boarding/manifest?${params.toString()}`);
  }

  // T-Shirt
  async getTShirtManifest(date?: string, route?: string) {
    const params = new URLSearchParams();
    if (date) params.append('date', date);
    if (route) params.append('route', route);
    return this.request(`/tshirt/manifest?${params.toString()}`);
  }

  async updateTShirtStatus(passengerId: string, status: string, size?: string) {
    return this.request('/tshirt/update', {
      method: 'POST',
      body: JSON.stringify({ passengerId, status, size }),
    });
  }

  // Analytics
  async getDashboardStats() {
    return this.request('/analytics/dashboard');
  }

  // Emergency & SOS
  async getEmergencies() {
    return this.request('/emergencies');
  }

  async createEmergency(data: any) {
    return this.request('/emergencies', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async updateEmergencyStatus(emergencyId: string, status: string) {
    return this.request(`/emergencies/${emergencyId}/status`, {
      method: 'PUT',
      body: JSON.stringify({ status }),
    });
  }

  // Payment Approvals
  async approveAgentCommission(bookingIds: string[]) {
    return this.request('/payments/approve-agent-commission', {
      method: 'POST',
      body: JSON.stringify({ bookingIds }),
    });
  }

  async approveOperatorPayment(bookingIds: string[], boatId: string) {
    return this.request('/payments/approve-operator-payment', {
      method: 'POST',
      body: JSON.stringify({ bookingIds, boatId }),
    });
  }

  // Database Seeding
  async seedDatabase() {
    return this.request('/seed', {
      method: 'POST',
    });
  }
}

export const api = new ApiClient();
