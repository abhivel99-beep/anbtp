import { api } from './api';

export async function seedDemoData() {
  try {
    console.log('🌱 Seeding system with operational data...');

    // STEP 1: Create demo user accounts
    console.log('\n📝 Creating demo user accounts...');
    const demoAccounts = [
      { email: 'admin@andaman.com', password: 'demo123', name: 'Admin User', role: 'admin' },
      { email: 'operator@andaman.com', password: 'demo123', name: 'Boat Operator', role: 'operator' },
      { email: 'agent@andaman.com', password: 'demo123', name: 'Agent User', role: 'agent' },
      { email: 'boarding@andaman.com', password: 'demo123', name: 'Boarding Staff', role: 'boarding' },
      { email: 'pcu@andaman.com', password: 'demo123', name: 'PCU Team', role: 'pcu' },
    ];

    const createdUsers: any = {};
    for (const account of demoAccounts) {
      try {
        const result = await api.signUp(account.email, account.password, account.name, account.role);
        if (result.message && result.message.includes('already exists')) {
          console.log(`⏭️  Account already exists: ${account.email}`);
        } else {
          console.log(`✅ Created ${account.role}: ${account.email}`);
        }
        createdUsers[account.role] = result.user;
      } catch (error: any) {
        if (error.message && (error.message.includes('already') || error.message.includes('registered'))) {
          console.log(`⏭️  Account already exists: ${account.email}`);
        } else {
          console.error(`❌ Failed to create ${account.email}:`, error.message);
        }
      }
    }

    // STEP 2: Sign in as operator to create boats and schedules
    console.log('\n🚢 Creating operational boats...');
    try {
      const operatorAuth = await api.signIn('operator@andaman.com', 'demo123');
      
      if (operatorAuth.session) {
        // Create 2 operational boats
        const boats = [
          {
            name: 'Sea Pearl',
            capacity: 30,
            type: 'Speed Boat',
            registrationNumber: 'AND-SP-002',
            status: 'active'
          },
          {
            name: 'Island Queen',
            capacity: 40,
            type: 'Ferry',
            registrationNumber: 'AND-IQ-003',
            status: 'active'
          }
        ];

        const createdBoats: any[] = [];
        for (const boat of boats) {
          try {
            const result = await api.createBoat(boat);
            console.log(`✅ Created boat: ${boat.name} (${boat.capacity} seats)`);
            createdBoats.push(result.boat);
          } catch (error: any) {
            console.error(`❌ Failed to create boat ${boat.name}:`, error.message);
          }
        }

        // STEP 3: Create schedules for the next 7 days
        console.log('\n📅 Creating schedules for the next 7 days...');
        const today = new Date();
        const routes = ['Ross Island', 'North Bay', 'Combined'];
        const timings = [
          { departure: '09:00', return: '10:30' },
          { departure: '11:00', return: '12:30' },
          { departure: '14:00', return: '15:30' },
          { departure: '16:00', return: '17:30' }
        ];

        let scheduleCount = 0;
        for (let dayOffset = 0; dayOffset < 7; dayOffset++) {
          const scheduleDate = new Date(today);
          scheduleDate.setDate(today.getDate() + dayOffset);
          const dateStr = scheduleDate.toISOString().split('T')[0];

          for (const route of routes) {
            for (const timing of timings) {
              // Rotate through boats
              const boat = createdBoats[scheduleCount % createdBoats.length];
              
              try {
                await api.createSchedule({
                  boatId: boat.id,
                  date: dateStr,
                  route,
                  departureTime: timing.departure,
                  returnTime: timing.return
                });
                scheduleCount++;
              } catch (error: any) {
                console.error(`❌ Failed to create schedule:`, error.message);
              }
            }
          }
        }
        console.log(`✅ Created ${scheduleCount} schedules across 7 days`);
      }
    } catch (error: any) {
      console.error('❌ Failed to create operational data:', error.message);
    }

    console.log('\n✅ System initialization complete!');
    console.log('');
    console.log('📊 System Status:');
    console.log('   ✓ Demo accounts created and approved');
    console.log('   ✓ 2 operational boats registered');
    console.log('   ✓ 7-day schedule created');
    console.log('   ✓ System ready for bookings');
    console.log('');
    console.log('🔐 Demo Login Credentials:');
    console.log('   Admin:    admin@andaman.com / demo123');
    console.log('   Operator: operator@andaman.com / demo123');
    console.log('   Agent:    agent@andaman.com / demo123');
    console.log('   Boarding: boarding@andaman.com / demo123');
    console.log('   PCU:      pcu@andaman.com / demo123');
    console.log('');
    console.log('💡 Quick Start:');
    console.log('   1. Public users can book tickets immediately');
    console.log('   2. Agents can create bookings via Agent Dashboard');
    console.log('   3. Operators can manage boats and schedules');
    console.log('   4. Admin can view all system data');
    console.log('');
  } catch (error: any) {
    console.error('❌ Seeding failed:', error);
  }
}
