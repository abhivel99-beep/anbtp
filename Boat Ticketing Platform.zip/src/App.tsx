import { useState, useEffect } from 'react';
import { LogIn } from 'lucide-react';
import { Navbar } from './components/Navbar';
import { PublicHomePage } from './components/PublicHomePage';
import { BookingFlow } from './components/BookingFlow';
import { SignIn } from './components/SignIn';
import { Register } from './components/Register';
import { AdminDashboard } from './components/AdminDashboard';
import { OperatorDashboard } from './components/OperatorDashboard';
import { BoardingDashboard } from './components/BoardingDashboard';
import { PCUDashboard } from './components/PCUDashboard';
import { AgentDashboard } from './components/AgentDashboard';
import { InitializeData } from './components/InitializeData';
import { Button } from './components/ui/button';
import { api } from './utils/api';

type Page = 'landing' | 'home' | 'signin' | 'register' | 'dashboard';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('landing');
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showInitialize, setShowInitialize] = useState(false);
  const [initialized, setInitialized] = useState(false);

  useEffect(() => {
    if (initialized) return;
    
    let mounted = true;
    
    async function init() {
      try {
        const isInitialized = localStorage.getItem('andaman_initialized');
        
        if (isInitialized !== 'true') {
          if (mounted) {
            setShowInitialize(true);
            setLoading(false);
            setInitialized(true);
          }
          return;
        }

        const token = api.getToken();
        if (token) {
          try {
            const userData = await api.getMe();
            if (mounted) {
              setUser(userData);
              setCurrentPage('dashboard');
            }
          } catch (error) {
            console.error('Auth check failed:', error);
            api.signOut();
          }
        }
      } catch (error) {
        console.error('Initialization error:', error);
      } finally {
        if (mounted) {
          setLoading(false);
          setInitialized(true);
        }
      }
    }

    init();

    return () => {
      mounted = false;
    };
  }, [initialized]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="h-8 w-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  if (showInitialize) {
    return (
      <InitializeData 
        onComplete={() => {
          setShowInitialize(false);
          setLoading(false);
        }} 
      />
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {(currentPage === 'home' || currentPage === 'dashboard') && (
        <Navbar 
          user={user} 
          onSignOut={() => {
            api.signOut();
            setUser(null);
            setCurrentPage('landing');
          }} 
        />
      )}

      {currentPage === 'landing' && !user && (
        <PublicHomePage
          onBookNow={() => setCurrentPage('home')}
          onSignIn={() => setCurrentPage('signin')}
          onRegister={() => setCurrentPage('register')}
        />
      )}

      {currentPage === 'home' && !user && (
        <div>
          <div className="bg-blue-50 border-b">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
              <div className="flex items-center justify-between">
                <Button variant="ghost" onClick={() => setCurrentPage('landing')}>
                  ← Back to Home
                </Button>
                <div className="flex gap-4">
                  <Button variant="outline" onClick={() => setCurrentPage('signin')}>
                    <LogIn className="h-4 w-4 mr-2" />
                    Sign In
                  </Button>
                  <Button onClick={() => setCurrentPage('register')}>
                    Register
                  </Button>
                </div>
              </div>
            </div>
          </div>
          <BookingFlow />
        </div>
      )}
      
      {currentPage === 'signin' && !user && (
        <SignIn 
          onSuccess={(userData) => {
            setUser(userData);
            setCurrentPage('dashboard');
          }}
          onRegister={() => setCurrentPage('register')}
        />
      )}

      {currentPage === 'register' && !user && (
        <Register
          onSuccess={() => setCurrentPage('signin')}
          onBackToSignIn={() => setCurrentPage('signin')}
        />
      )}

      {currentPage === 'dashboard' && user && (
        <DashboardRouter role={user?.profile?.role} />
      )}
    </div>
  );
}

function DashboardRouter({ role }: { role?: string }) {
  const dashboardMap: Record<string, JSX.Element> = {
    'admin': <AdminDashboard />,
    'operator': <OperatorDashboard />,
    'boarding': <BoardingDashboard />,
    'pcu': <PCUDashboard />,
    'tshirt': <PCUDashboard />, // Backward compatibility
    'agent': <AgentDashboard />,
  };

  return dashboardMap[role || ''] || <TouristDashboard />;
}

function TouristDashboard() {
  const [bookings, setBookings] = useState<any[]>([]);
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    if (!email) return;
    setLoading(true);
    try {
      const result = await api.searchBookings({ email });
      setBookings(result?.bookings || []);
    } catch (error) {
      console.error('Failed to search bookings:', error);
      setBookings([]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1>My Bookings</h1>
          <p className="text-muted-foreground">View and manage your tickets</p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow mb-6">
          <div className="flex gap-4">
            <input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              className="flex-1 px-4 py-2 border rounded-md"
            />
            <Button onClick={handleSearch} disabled={loading}>
              {loading ? 'Searching...' : 'Search Bookings'}
            </Button>
          </div>
        </div>

        {bookings.length > 0 && (
          <div className="space-y-4">
            {bookings.map((booking) => (
              <div key={booking.id} className="bg-white p-6 rounded-lg shadow">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3>Booking #{booking.id}</h3>
                    <p className="text-sm text-muted-foreground">
                      {booking.date} • {booking.departureTime}
                    </p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs ${
                    booking.status === 'confirmed' ? 'bg-green-100 text-green-800' :
                    booking.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-gray-100 text-gray-800'
                  }`}>
                    {booking.status}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">Route</p>
                    <p className="capitalize">{booking.route}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Passengers</p>
                    <p>{booking.totalPassengers}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Amount Paid</p>
                    <p>₹{booking.totalAmount}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Payment Status</p>
                    <p className="capitalize">{booking.paymentStatus}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
