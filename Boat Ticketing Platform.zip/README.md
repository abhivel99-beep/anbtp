
  # Boat Ticketing Platform

  This is a code bundle for Boat Ticketing Platform. The original project is available at https://www.figma.com/design/x8O0z9Z5dtjOSjZNBTkGVe/Boat-Ticketing-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  